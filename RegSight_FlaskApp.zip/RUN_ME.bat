@echo off
REM Double-click this on Windows to start RegSight
pip install flask pandas
python app.py
pause
