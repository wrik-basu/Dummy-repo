"""
HSBC RegSight — Flask app.

Run:   python app.py
Then:  open http://localhost:5000  (it opens automatically)

Data lives in ./data/  (the 6 CSVs). Change a CSV, refresh the browser — updated.
No regeneration step: the data is re-read live on every page load.
"""
import os, sys, threading, webbrowser
from flask import Flask, jsonify, render_template

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import derive

app = Flask(__name__)
app.json.compact = True
try:
    app.json.allow_nan = False  # emit strict, browser-valid JSON
except Exception:
    pass
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/data")
def api_data():
    # re-read + re-derive on every request → live updates when CSVs change
    d = derive.load(DATA_DIR)
    if not len(d["records"]):
        return jsonify({"error": "no records — put the 6 CSVs in the data/ folder"}), 500
    return jsonify(derive.build_payload(d))


def _open_browser():
    webbrowser.open_new("http://localhost:5000")


if __name__ == "__main__":
    # open the browser shortly after the server starts
    if os.environ.get("WERKZEUG_RUN_MAIN") != "true":
        threading.Timer(1.2, _open_browser).start()
    print("\n  HSBC RegSight running →  http://localhost:5000")
    print("  Data folder:", DATA_DIR)
    print("  (Change a CSV and refresh the browser to update. Ctrl+C to stop.)\n")
    app.run(host="127.0.0.1", port=5000, debug=False)
