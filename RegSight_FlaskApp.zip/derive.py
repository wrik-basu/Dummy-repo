"""
HSBC RegSight — rich standalone dashboard generator.
Reads the 6 pipeline CSVs, derives everything (incl. per-theme mind-map,
knowledge graph, recommendations, gap assessment), emits ONE self-contained HTML.
Real HTML/CSS/JS: hover animations, View-Details drill-down, working D3 visuals.

Run:  python gen.py
Out:  RegSight.html   (open in any browser, no server)
"""
import pandas as pd, numpy as np, json, ast, math
from pathlib import Path

RED="#DB0011"; RED_DK="#A50009"; INK="#1C1C1C"; MUTED="#6B7280"; LINE="#E3E6EA"
LEAD="#0B7A57"; COIN="#C67A00"; LAG="#B00020"
SIG_W={"Leading":1.0,"Coincident":0.5,"Lagging":0.15}
URG_W={"High":1.0,"Medium":0.6,"Low":0.3}; IMP_W=URG_W

def _lit(x):
    if isinstance(x,list): return x
    if pd.isna(x): return []
    s=str(x).strip()
    if s in ("","[]","nan"): return []
    try:
        v=ast.literal_eval(s); return v if isinstance(v,list) else [v]
    except Exception:
        return [t.strip(" '\"") for t in s.strip("[]").split(",") if t.strip()]

def _read(path):
    for enc in ("utf-8","utf-8-sig","cp1252","latin-1"):
        try: return pd.read_csv(path,encoding=enc)
        except UnicodeDecodeError: continue
        except FileNotFoundError: return pd.DataFrame()
    return pd.read_csv(path,encoding="latin-1",encoding_errors="replace")

def load(data_dir="data"):
    from pathlib import Path as _P
    files=dict(records="records_df.csv",controls="controls_df.csv",
        gaps="gaps_df.csv",jm="jurisdiction_master.csv",rm="regulator_master.csv",
        rc="record_cat_view.csv")
    d={k:_read(str(_P(data_dir)/f)) for k,f in files.items()}
    ALIASES=["Message_ID","record_id","RECORD_ID","RCID","message_id"]
    for k,df in d.items():
        if len(df) and "Message_ID" not in df.columns:
            for a in ALIASES:
                if a in df.columns: df.rename(columns={a:"Message_ID"},inplace=True); break
    r=d["records"]
    r["_sig"]=r["signal_type"].map(SIG_W).fillna(0.3)
    r["_urg"]=r["urgency"].map(URG_W).fillna(0.5)
    imp="estimated_business_impact" if "estimated_business_impact" in r else "urgency"
    r["_imp"]=r[imp].map(IMP_W).fillna(0.6)
    r["_nov"]=pd.to_numeric(r.get("novelty_score",0.5),errors="coerce").fillna(0.5)
    r["_conf"]=pd.to_numeric(r.get("confidence",0.9),errors="coerce").fillna(0.9)
    r["priority_score"]=(100*r["_conf"]*(0.40*r["_sig"]+0.25*r["_urg"]+0.20*r["_imp"]+0.15*r["_nov"])).round(1)
    dc="REC_START_DT" if "REC_START_DT" in r else None
    r["_date"]=pd.to_datetime(r[dc],errors="coerce") if dc else pd.NaT
    d["records"]=r
    return d

def exec_matrix(r):
    out=[]; hd=r["_date"].notna().any(); med=r.groupby("primary_theme").size().median()
    for theme,g in r.groupby("primary_theme"):
        row={"theme":theme,"records":int(len(g))}
        ap=g["priority_score"].mean()
        row["Severity"]="HIGH" if ap>=65 else "MEDIUM" if ap>=45 else "LOW"
        if hd and g["_date"].notna().sum()>=4:
            m=g.set_index("_date").resample("MS").size()
            v=m.tail(3).mean()/(m.head(max(len(m)-3,1)).mean() or 1) if len(m)>=2 else 0
            row["Theme Velocity"]="HIGH" if v>=2.5 else "MEDIUM" if v>=1 else "LOW"
        else:
            row["Theme Velocity"]="MEDIUM" if len(g)>=med else "LOW"
        jn=g["JURISDICTION"].nunique() if "JURISDICTION" in g else 0
        share=100*jn/(r["JURISDICTION"].nunique() or 1)
        row["X-Jurisdiction Overlap"]="HIGH" if share>66 else "MEDIUM" if share>=33 else "LOW"
        if "RECORD_CAT_CDE" in g and hd:
            piv=(g.assign(m=g["_date"].dt.to_period("M")).pivot_table(index="m",columns="RECORD_CAT_CDE",
                 values="Message_ID",aggfunc="count").fillna(0))
            if {"NEWS","REGDEV"}.issubset(piv.columns) and len(piv)>=3:
                c=piv["NEWS"].corr(piv["REGDEV"]); c=0 if (c is None or math.isnan(c)) else c
                row["News-RegDev Corr"]="HIGH" if c>=0.5 else "MEDIUM" if c>=0.2 else "LOW"
            else: row["News-RegDev Corr"]="LOW"
        else: row["News-RegDev Corr"]="LOW"
        fande=(g.get("RECORD_CAT_CDE",pd.Series(dtype=str))=="FANDE").mean()
        row["Enforcement Corr"]="HIGH" if fande>=0.15 else "MEDIUM" if fande>=0.05 else "LOW"
        out.append(row)
    return sorted(out,key=lambda x:-x["records"])

def per_theme(d):
    """For each theme: kpis, mindmap children, KG nodes/links, recommendations, gaps."""
    r=d["records"]; ctr=d["controls"]; gp=d["gaps"]
    themes={}
    for theme,g in r.groupby("primary_theme"):
        tc=ctr[ctr["primary_theme"]==theme] if "primary_theme" in ctr else ctr.iloc[0:0]
        tg=gp[gp["primary_theme"]==theme] if "primary_theme" in gp else gp.iloc[0:0]
        # mindmap: theme -> top key sub-topics (use control titles as sub-topics)
        subs=[]
        if "control_title" in tc:
            for t,c in tc["control_title"].value_counts().head(7).items():
                subs.append({"name":str(t)[:32],"value":int(c)})
        # knowledge graph: theme <-> jurisdictions <-> regulators
        # ids are used verbatim as both node id AND link endpoint — must match exactly
        nodes={}; links=[]
        def add(nid,typ):
            if nid not in nodes: nodes[nid]={"id":nid,"type":typ}
        theme_id=str(theme).split(",")[0]
        add(theme_id,"theme")
        for j in g["JURISDICTION"].value_counts().head(5).index:
            jid=str(j); add(jid,"jurisdiction"); links.append({"source":theme_id,"target":jid,"value":2})
        for rg in g["REGULATOR"].value_counts().head(4).index:
            rid=str(rg); add(rid,"regulator"); links.append({"source":theme_id,"target":rid,"value":1})
        # recommendations (grouped by control)
        recs=[]
        if len(tg):
            for cid,gg in list(tg.groupby("control_id"))[:6]:
                title=gg["control_title"].iloc[0] if "control_title" in gg else cid
                items=[{"text":str(row.get("recommendation","")),"sev":str(row.get("gap_severity",""))} for _,row in gg.head(4).iterrows()]
                recs.append({"control_id":str(cid),"title":str(title),"items":items})
        # gap assessment: regulation content (top record) + controls/gaps
        top=g.sort_values("priority_score",ascending=False).head(1)
        reg_content=""
        if len(top):
            row=top.iloc[0]
            reg_content=f"{row.get('TITLE',row['Message_ID'])}. {row.get('so_what_summary','')}"
        gap_controls=[]
        for _,cr in tc.head(5).iterrows():
            gc=tg[tg["control_id"]==cr["control_id"]] if len(tg) else tg.iloc[0:0]
            gaps=[{"gap":str(x.get("gap_description","")),"rec":str(x.get("recommendation","")),"sev":str(x.get("gap_severity",""))} for _,x in gc.iterrows()]
            gap_controls.append({"control_id":str(cr["control_id"]),"title":str(cr.get("control_title","")),
                "steward":str(cr.get("risk_steward_name","")),"eff":str(cr.get("control_effectiveness","")),
                "obligation":str(cr.get("obligation_addressed","")),"desc":str(cr.get("control_description","")),"gaps":gaps})
        themes[theme]={
            "news":int((g.get("RECORD_CAT_CDE",pd.Series(dtype=str))=="NEWS").sum()),
            "regdev":int((g.get("RECORD_CAT_CDE",pd.Series(dtype=str))=="REGDEV").sum()),
            "controls":int(len(tc)),
            "hi_gaps":int((tg.get("gap_severity",pd.Series(dtype=str))=="High").sum()),
            "med_gaps":int((tg.get("gap_severity",pd.Series(dtype=str))=="Medium").sum()),
            "mindmap":subs,"kg_nodes":list(nodes.values()),"kg_links":links,
            "recs":recs,"reg_content":reg_content,"gap_controls":gap_controls,
        }
    return themes

def _clean(obj):
    """Recursively replace NaN/inf with None so the JSON is browser-valid."""
    import math as _m
    if isinstance(obj, float):
        return None if (_m.isnan(obj) or _m.isinf(obj)) else obj
    if isinstance(obj, dict):
        return {k: _clean(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_clean(v) for v in obj]
    return obj

def priority_breakdown(row):
    """Explain the priority score for one record — the components, so the UI can show 'why'."""
    return {
        "signal": round(0.40*row.get("_sig",0.3)*100),
        "urgency": round(0.25*row.get("_urg",0.5)*100),
        "impact": round(0.20*row.get("_imp",0.6)*100),
        "novelty": round(0.15*row.get("_nov",0.5)*100),
        "confidence": round(row.get("_conf",0.9)*100),
    }

def time_sliced_graph(d):
    """Cumulative knowledge graph per time period — for the growing-graph slider.
    Returns ordered periods and, for each, the nodes/links that exist UP TO that period."""
    r=d["records"]
    if r["_date"].notna().sum()<3: return {"periods":[],"frames":{}}
    rr=r.dropna(subset=["_date"]).copy()
    rr["_period"]=rr["_date"].dt.to_period("Q").astype(str)
    periods=sorted(rr["_period"].unique())
    frames={}
    nodes={}; links={}
    def add(nid,typ):
        if nid not in nodes: nodes[nid]={"id":nid,"type":typ}
    for p in periods:
        sub=rr[rr["_period"]<=p]
        nodes={}; links={}
        for _,row in sub.iterrows():
            th=str(row["primary_theme"]).split(",")[0]; add(th,"theme")
            j=row.get("JURISDICTION")
            if pd.notna(j):
                add(str(j),"jurisdiction"); links[(th,str(j))]=links.get((th,str(j)),0)+1
            rg=row.get("REGULATOR")
            if pd.notna(rg):
                add(str(rg),"regulator"); links[(th,str(rg))]=links.get((th,str(rg)),0)+1
        # keep it readable: cap to strongest links
        top_links=sorted(links.items(),key=lambda x:-x[1])[:60]
        keep=set()
        for (a,b),w in top_links: keep.add(a); keep.add(b)
        frames[p]={
            "nodes":[n for k,n in nodes.items() if k in keep],
            "links":[{"source":a,"target":b,"value":w} for (a,b),w in top_links],
            "count":int(len(sub)),
        }
    return {"periods":periods,"frames":frames}

def ontology_tree(d):
    """Theme -> risk steward -> control -> gap hierarchy for the ontology view."""
    ctr=d["controls"]; gp=d["gaps"]
    if not len(ctr): return []
    gaps_by_ctrl={}
    for _,g in gp.iterrows():
        gaps_by_ctrl.setdefault(g.get("control_id"),[]).append(g)
    out=[]
    for theme,tc in ctr.groupby("primary_theme") if "primary_theme" in ctr else []:
        stewards=[]
        for stw,sc in tc.groupby("risk_steward_name") if "risk_steward_name" in tc else []:
            controls=[]
            for _,c in sc.head(8).iterrows():
                cg=gaps_by_ctrl.get(c.get("control_id"),[])
                controls.append({"id":str(c.get("control_id","")),"title":str(c.get("control_title","")),
                    "eff":str(c.get("control_effectiveness","")),
                    "gaps":[{"sev":str(x.get("gap_severity","")),"desc":str(x.get("gap_description",""))[:120]} for x in cg[:4]]})
            stewards.append({"steward":str(stw),"count":int(len(sc)),"controls":controls})
        out.append({"theme":str(theme).split(",")[0],"full":str(theme),"count":int(len(tc)),"stewards":stewards})
    return sorted(out,key=lambda x:-x["count"])

def impact_ripple(d):
    """For each theme: the cascade — records -> controls -> gaps -> follower jurisdictions.
    Powers the 'pick a theme, see what it touches' impact view."""
    r=d["records"]; ctr=d["controls"]; gp=d["gaps"]
    out={}
    for theme,g in r.groupby("primary_theme"):
        tc=ctr[ctr["primary_theme"]==theme] if "primary_theme" in ctr else ctr.iloc[0:0]
        tg=gp[gp["primary_theme"]==theme] if "primary_theme" in gp else gp.iloc[0:0]
        followers={}
        for _,row in g.iterrows():
            for f in _lit(row.get("likely_follower_jurisdictions")):
                if f: followers[f]=followers.get(f,0)+1
        out[str(theme)]={
            "records":int(len(g)),
            "controls":int(len(tc)),
            "hi_gaps":int((tg.get("gap_severity",pd.Series(dtype=str))=="High").sum()),
            "med_gaps":int((tg.get("gap_severity",pd.Series(dtype=str))=="Medium").sum()),
            "stewards":sorted(tc["risk_steward_name"].dropna().unique().tolist()) if "risk_steward_name" in tc else [],
            "jurisdictions":int(g["JURISDICTION"].nunique()) if "JURISDICTION" in g else 0,
            "followers":sorted(followers.items(),key=lambda x:-x[1])[:8],
            "business_lines":sorted({b for _,row in g.iterrows() for b in _lit(row.get("affected_business_lines"))}),
        }
    return out

def build_payload(d):
    r=d["records"]
    def recs(df,n=None):
        df=df.head(n) if n else df
        return df.where(pd.notna(df),None).to_dict("records")
    total=len(r); lead=int((r["signal_type"]=="Leading").sum())
    kpi=dict(total=total,leading=lead,leading_pct=round(100*lead/max(total,1)),
        near=int(r.get("expected_action_horizon",pd.Series(dtype=str)).isin(["Immediate","Near-Term"]).sum()),
        emerging=int(r["is_emerging"].sum()) if "is_emerging" in r else 0,
        contagion=int(r["cross_jurisdiction_watch"].sum()) if "cross_jurisdiction_watch" in r else 0,
        controls=len(d["controls"]),gaps=len(d["gaps"]),
        hi_gaps=int((d["gaps"].get("gap_severity",pd.Series(dtype=str))=="High").sum()),
        jurisdictions=r["JURISDICTION"].nunique(),regulators=r["REGULATOR"].nunique())
    # contagion edges
    edges={}
    for _,row in r.iterrows():
        o=row.get("JURISDICTION")
        if pd.isna(o): continue
        for f in _lit(row.get("likely_follower_jurisdictions")):
            if f and f!=o: edges[(o,f)]=edges.get((o,f),0)+1
    edge_list=sorted([{"source":a,"target":b,"weight":w} for (a,b),w in edges.items()],key=lambda x:-x["weight"])[:24]
    # timeline events
    events=[]
    if r["_date"].notna().sum()>=3:
        top=r.sort_values("priority_score",ascending=False).dropna(subset=["_date"]).head(24).sort_values("_date")
        events=[{"date":x["_date"].strftime("%Y-%m-%d"),"label":str(x.get("TITLE",x["Message_ID"]))[:38],
                 "type":x["signal_type"],"note":str(x.get("so_what_summary",""))[:130]} for _,x in top.iterrows()]
    rsorted=r.sort_values("priority_score",ascending=False).head(60)
    radar_cols=[c for c in ["Message_ID","primary_theme","JURISDICTION","REGULATOR","RECORD_CAT_CDE","signal_type",
        "urgency","expected_action_horizon","regulatory_direction","priority_score","so_what_summary",
        "recommended_action","is_emerging","emerging_theme_label","affected_business_lines"] if c in r.columns]
    radar=[]
    for _,row in rsorted.iterrows():
        rec={c:(None if pd.isna(row[c]) else row[c]) for c in radar_cols}
        rec["breakdown"]=priority_breakdown(row)
        radar.append(rec)
    return _clean(dict(
        kpi=kpi, matrix=exec_matrix(r), themes=per_theme(d),
        radar=radar, edges=edge_list, events=events,
        tgraph=time_sliced_graph(d), ontology=ontology_tree(d), impact=impact_ripple(d),
        jm=recs(d["jm"],30), rm=recs(d["rm"],30), rc=recs(d["rc"]),
        controls=recs(d["controls"],400), gaps=recs(d["gaps"],600),
        colors=dict(red=RED,red_dk=RED_DK,ink=INK,muted=MUTED,line=LINE,lead=LEAD,coin=COIN,lag=LAG),
    ))


