"""
HSBC RegSight — rich standalone dashboard generator.
Reads the 6 pipeline CSVs, derives everything (incl. per-theme mind-map,
knowledge graph, recommendations, gap assessment), emits ONE self-contained HTML.
Real HTML/CSS/JS: hover animations, View-Details drill-down, working D3 visuals.

Run:  python gen.py
Out:  RegSight.html   (open in any browser, no server)
"""
import pandas as pd, numpy as np, json, ast, math
from pathlib import Path

RED="#DB0011"; RED_DK="#A50009"; INK="#1C1C1C"; MUTED="#6B7280"; LINE="#E3E6EA"
LEAD="#0B7A57"; COIN="#C67A00"; LAG="#B00020"
SIG_W={"Leading":1.0,"Coincident":0.5,"Lagging":0.15}
URG_W={"High":1.0,"Medium":0.6,"Low":0.3}; IMP_W=URG_W

def _lit(x):
    if isinstance(x,list): return x
    if pd.isna(x): return []
    s=str(x).strip()
    if s in ("","[]","nan"): return []
    try:
        v=ast.literal_eval(s); return v if isinstance(v,list) else [v]
    except Exception:
        return [t.strip(" '\"") for t in s.strip("[]").split(",") if t.strip()]

def _read(path):
    for enc in ("utf-8","utf-8-sig","cp1252","latin-1"):
        try: return pd.read_csv(path,encoding=enc)
        except UnicodeDecodeError: continue
        except FileNotFoundError: return pd.DataFrame()
    return pd.read_csv(path,encoding="latin-1",encoding_errors="replace")

def load(data_dir="data"):
    from pathlib import Path as _P
    files=dict(records="records_df.csv",controls="controls_df.csv",
        gaps="gaps_df.csv",jm="jurisdiction_master.csv",rm="regulator_master.csv",
        rc="record_cat_view.csv")
    d={k:_read(str(_P(data_dir)/f)) for k,f in files.items()}
    ALIASES=["Message_ID","record_id","RECORD_ID","RCID","message_id"]
    for k,df in d.items():
        if len(df) and "Message_ID" not in df.columns:
            for a in ALIASES:
                if a in df.columns: df.rename(columns={a:"Message_ID"},inplace=True); break
    r=d["records"]
    r["_sig"]=r["signal_type"].map(SIG_W).fillna(0.3)
    r["_urg"]=r["urgency"].map(URG_W).fillna(0.5)
    imp="estimated_business_impact" if "estimated_business_impact" in r else "urgency"
    r["_imp"]=r[imp].map(IMP_W).fillna(0.6)
    r["_nov"]=pd.to_numeric(r.get("novelty_score",0.5),errors="coerce").fillna(0.5)
    r["_conf"]=pd.to_numeric(r.get("confidence",0.9),errors="coerce").fillna(0.9)
    r["priority_score"]=(100*r["_conf"]*(0.40*r["_sig"]+0.25*r["_urg"]+0.20*r["_imp"]+0.15*r["_nov"])).round(1)
    dc="REC_START_DT" if "REC_START_DT" in r else None
    r["_date"]=pd.to_datetime(r[dc],errors="coerce") if dc else pd.NaT
    d["records"]=r
    d["_data_dir"]=data_dir
    return d

def exec_matrix(r):
    """Each cell carries value + a 'reasons' dict with the actual numbers behind HIGH/MED/LOW."""
    out=[]; hd=r["_date"].notna().any(); med=r.groupby("primary_theme").size().median()
    tot_jur=r["JURISDICTION"].nunique() or 1
    for theme,g in r.groupby("primary_theme"):
        row={"theme":theme,"records":int(len(g))}; reasons={}
        ap=g["priority_score"].mean()
        row["Severity"]="HIGH" if ap>=65 else "MEDIUM" if ap>=45 else "LOW"
        reasons["Severity"]=f"Mean priority score for this theme is {ap:.0f}. Cutoffs: HIGH ≥65, MEDIUM ≥45, else LOW."
        if hd and g["_date"].notna().sum()>=4:
            m=g.set_index("_date").resample("MS").size()
            v=m.tail(3).mean()/(m.head(max(len(m)-3,1)).mean() or 1) if len(m)>=2 else 0
            row["Theme Velocity"]="HIGH" if v>=2.5 else "MEDIUM" if v>=1 else "LOW"
            reasons["Theme Velocity"]=f"Recent 3-month activity is {v:.1f}× the earlier baseline. HIGH ≥2.5×, MEDIUM ≥1×."
        else:
            row["Theme Velocity"]="MEDIUM" if len(g)>=med else "LOW"
            reasons["Theme Velocity"]=f"{len(g)} records vs median {med:.0f} across themes (insufficient dates for a trend)."
        jn=g["JURISDICTION"].nunique() if "JURISDICTION" in g else 0
        share=100*jn/tot_jur
        row["X-Jurisdiction Overlap"]="HIGH" if share>66 else "MEDIUM" if share>=33 else "LOW"
        reasons["X-Jurisdiction Overlap"]=f"Spans {jn} of {tot_jur} jurisdictions ({share:.0f}%). HIGH >66%, MEDIUM 33–66%."
        if "RECORD_CAT_CDE" in g and hd:
            piv=(g.assign(m=g["_date"].dt.to_period("M")).pivot_table(index="m",columns="RECORD_CAT_CDE",
                 values="Message_ID",aggfunc="count").fillna(0))
            if {"NEWS","REGDEV"}.issubset(piv.columns) and len(piv)>=3:
                c=piv["NEWS"].corr(piv["REGDEV"]); c=0 if (c is None or math.isnan(c)) else c
                row["News-RegDev Corr"]="HIGH" if c>=0.5 else "MEDIUM" if c>=0.2 else "LOW"
                reasons["News-RegDev Corr"]=f"Monthly NEWS↔REGDEV correlation is {c:.2f}. HIGH ≥0.5, MEDIUM ≥0.2. High means news reliably precedes rules here."
            else: row["News-RegDev Corr"]="LOW"; reasons["News-RegDev Corr"]="Not enough paired NEWS/REGDEV months to correlate."
        else: row["News-RegDev Corr"]="LOW"; reasons["News-RegDev Corr"]="No dated NEWS/REGDEV data for this theme."
        fande=(g.get("RECORD_CAT_CDE",pd.Series(dtype=str))=="FANDE").mean()
        row["Enforcement Corr"]="HIGH" if fande>=0.15 else "MEDIUM" if fande>=0.05 else "LOW"
        reasons["Enforcement Corr"]=f"{fande*100:.0f}% of records are enforcement actions (FANDE). HIGH ≥15%, MEDIUM ≥5%. High means you're already seeing penalties."
        row["reasons"]=reasons
        out.append(row)
    return sorted(out,key=lambda x:-x["records"])

def per_theme(d):
    """For each theme: kpis, hierarchical mindmap, KG nodes/links, recommendations, gaps."""
    r=d["records"]; ctr=d["controls"]; gp=d["gaps"]
    sev_rank={"High":0,"Medium":1,"Low":2}
    themes={}
    for theme,g in r.groupby("primary_theme"):
        tc=ctr[ctr["primary_theme"]==theme] if "primary_theme" in ctr else ctr.iloc[0:0]
        tg=gp[gp["primary_theme"]==theme] if "primary_theme" in gp else gp.iloc[0:0]
        theme_id=str(theme).split(",")[0]
        gaps_by_ctrl={}
        for _,x in tg.iterrows(): gaps_by_ctrl.setdefault(x.get("control_id"),[]).append(x)
        mm_children=[]
        if "risk_steward_name" in tc:
            for stw,sc in list(tc.groupby("risk_steward_name"))[:6]:
                ctrl_nodes=[]
                for _,c in sc.head(5).iterrows():
                    cid=c.get("control_id"); cg=gaps_by_ctrl.get(cid,[])
                    gap_nodes=[{"name":(str(x.get("gap_severity",""))+": "+str(x.get("gap_description",""))[:44]),
                                "leaf":True,"sev":str(x.get("gap_severity",""))} for x in cg[:3]]
                    ctrl_nodes.append({"name":str(c.get("control_title",""))[:34],"kind":"control","id":str(cid),"children":gap_nodes})
                mm_children.append({"name":str(stw),"kind":"steward","value":int(len(sc)),"children":ctrl_nodes})
        nodes={}; links=[]
        def add(nid,typ):
            if nid not in nodes: nodes[nid]={"id":nid,"type":typ}
        add(theme_id,"theme")
        for j in g["JURISDICTION"].value_counts().head(5).index:
            jid=str(j); add(jid,"jurisdiction"); links.append({"source":theme_id,"target":jid,"value":2})
        for rg in g["REGULATOR"].value_counts().head(4).index:
            rid=str(rg); add(rid,"regulator"); links.append({"source":theme_id,"target":rid,"value":1})
        recs=[]
        if len(tg):
            for cid,gg in list(tg.groupby("control_id"))[:8]:
                title=gg["control_title"].iloc[0] if "control_title" in gg else cid
                items=[{"action":str(row.get("recommendation","")),"addresses":str(row.get("gap_description",""))[:90],
                        "sev":str(row.get("gap_severity",""))} for _,row in gg.iterrows()]
                items.sort(key=lambda x:sev_rank.get(x["sev"],3))
                recs.append({"control_id":str(cid),"title":str(title),"items":items})
        top=g.sort_values("priority_score",ascending=False).head(1)
        reg_content=""
        if len(top):
            row=top.iloc[0]; reg_content=f"{row.get('TITLE',row['Message_ID'])}. {row.get('so_what_summary','')}"
        gap_controls=[]
        for _,cr in tc.head(10).iterrows():
            cg=gaps_by_ctrl.get(cr.get("control_id"),[])
            gaps=[{"gap":str(x.get("gap_description","")),"rec":str(x.get("recommendation","")),"sev":str(x.get("gap_severity",""))} for x in cg]
            gaps.sort(key=lambda x:sev_rank.get(x["sev"],3))
            worst=min([sev_rank.get(x["sev"],3) for x in gaps],default=3)
            gap_controls.append({"control_id":str(cr["control_id"]),"title":str(cr.get("control_title","")),
                "steward":str(cr.get("risk_steward_name","")),"eff":str(cr.get("control_effectiveness","")),
                "obligation":str(cr.get("obligation_addressed","")),"desc":str(cr.get("control_description","")),
                "gaps":gaps,"_worst":worst})
        gap_controls.sort(key=lambda c:c["_worst"])
        themes[theme]={
            "news":int((g.get("RECORD_CAT_CDE",pd.Series(dtype=str))=="NEWS").sum()),
            "regdev":int((g.get("RECORD_CAT_CDE",pd.Series(dtype=str))=="REGDEV").sum()),
            "controls":int(len(tc)),
            "hi_gaps":int((tg.get("gap_severity",pd.Series(dtype=str))=="High").sum()),
            "med_gaps":int((tg.get("gap_severity",pd.Series(dtype=str))=="Medium").sum()),
            "mm_children":mm_children,"kg_nodes":list(nodes.values()),"kg_links":links,
            "recs":recs,"reg_content":reg_content,"gap_controls":gap_controls,
        }
    return themes

def _clean(obj):
    """Recursively replace NaN/inf with None so the JSON is browser-valid."""
    import math as _m
    if isinstance(obj, float):
        return None if (_m.isnan(obj) or _m.isinf(obj)) else obj
    if isinstance(obj, dict):
        return {k: _clean(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_clean(v) for v in obj]
    return obj

def priority_breakdown(row):
    """Explain the priority score for one record — the components, so the UI can show 'why'."""
    return {
        "signal": round(0.40*row.get("_sig",0.3)*100),
        "urgency": round(0.25*row.get("_urg",0.5)*100),
        "impact": round(0.20*row.get("_imp",0.6)*100),
        "novelty": round(0.15*row.get("_nov",0.5)*100),
        "confidence": round(row.get("_conf",0.9)*100),
    }

def urgency_reason(row, today=None):
    """Explain WHY urgency is High/Med/Low. Uses a real target date if present, else a proxy."""
    import datetime as _dt
    u=row.get("urgency","Medium")
    tgt=row.get("TARGET_IMPL_DT")
    if tgt is not None and str(tgt) not in ("","nan","NaT"):
        try:
            td=pd.to_datetime(tgt,errors="coerce")
            if pd.notna(td):
                base=today or pd.Timestamp.now()
                weeks=int((td-base).days/7)
                if weeks<0: return {"basis":"deadline","text":f"Implementation deadline has passed ({abs(weeks)} weeks ago) — immediate action required."}
                return {"basis":"deadline","text":f"~{weeks} weeks to the implementation deadline ({td.strftime('%d %b %Y')})."}
        except Exception: pass
    # proxy from horizon + signal + direction
    hz=row.get("expected_action_horizon","Unclear")
    sig=row.get("signal_type","Coincident")
    dirn=row.get("regulatory_direction","Neutral")
    bits=[]
    hz_map={"Immediate":"action expected immediately","Near-Term":"action expected in the near term (weeks–months)",
            "Medium-Term":"action expected medium-term (months)","Long-Term":"longer runway (a year+)","Unclear":"timing not yet clear"}
    bits.append(hz_map.get(hz,"timing not yet clear"))
    if sig=="Lagging": bits.append("this is a lagging signal (enforcement already occurring)")
    elif sig=="Leading": bits.append("early leading signal, so lead time exists")
    if dirn=="Tightening": bits.append("regulatory direction is tightening")
    return {"basis":"proxy","text":"Derived from horizon & signal: "+"; ".join(bits)+"."}

def time_sliced_graph(d):
    """Story-driven growing network. Each period ADDS new nodes/edges (with relationship
    labels) and a narrative log entry explaining what happened. Nodes carry a 'born' period
    so the UI can animate new arrivals on the right and tell a story."""
    r=d["records"]
    if r["_date"].notna().sum()<3: return {"periods":[],"frames":{},"story":{}}
    rr=r.dropna(subset=["_date"]).copy()
    rr["_period"]=rr["_date"].dt.to_period("Q").astype(str)
    periods=sorted(rr["_period"].unique())
    # derive labelled relationships: regulator --issues--> theme; jurisdiction --adopts--> theme;
    # theme --spreads to--> follower jurisdiction
    born={}; frames={}; story={}
    seen_nodes=set(); seen_links=set()
    def rel_label(a_type,b_type):
        if a_type=="regulator" and b_type=="theme": return "issues guidance on"
        if a_type=="jurisdiction" and b_type=="theme": return "active in"
        if a_type=="theme" and b_type=="jurisdiction": return "may spread to"
        return "linked to"
    for pi,p in enumerate(periods):
        sub=rr[rr["_period"]<=p]           # cumulative graph
        new=rr[rr["_period"]==p]           # what's new THIS period (for the story)
        nodes={}; links={}
        def add(nid,typ):
            if nid not in nodes: nodes[nid]={"id":nid,"type":typ,"born":born.get(nid,p)}
            if nid not in born: born[nid]=p
        for _,row in sub.iterrows():
            th=str(row["primary_theme"]).split(",")[0]; add(th,"theme")
            j=row.get("JURISDICTION")
            if pd.notna(j):
                add(str(j),"jurisdiction")
                links[(str(j),th)]={"w":links.get((str(j),th),{}).get("w",0)+1,"label":rel_label("jurisdiction","theme")}
            rg=row.get("REGULATOR")
            if pd.notna(rg):
                add(str(rg),"regulator")
                links[(str(rg),th)]={"w":links.get((str(rg),th),{}).get("w",0)+1,"label":rel_label("regulator","theme")}
        top=sorted(links.items(),key=lambda x:-x[1]["w"])[:55]
        keep=set()
        for (a,b),m in top: keep.add(a); keep.add(b)
        frames[p]={
            "nodes":[n for k,n in nodes.items() if k in keep],
            "links":[{"source":a,"target":b,"value":m["w"],"label":m["label"]} for (a,b),m in top],
            "count":int(len(sub)),
        }
        # story log: what's new this period
        new_themes=sorted({str(x["primary_theme"]).split(",")[0] for _,x in new.iterrows()})
        new_regs=sorted({str(x["REGULATOR"]) for _,x in new.iterrows() if pd.notna(x.get("REGULATOR"))})
        new_jur=sorted({str(x["JURISDICTION"]) for _,x in new.iterrows() if pd.notna(x.get("JURISDICTION"))})
        # only report genuinely NEW-to-the-graph entities
        fresh_t=[t for t in new_themes if t not in seen_nodes]; seen_nodes|=set(new_themes)
        fresh_r=[t for t in new_regs if t not in seen_nodes]; seen_nodes|=set(new_regs)
        fresh_j=[t for t in new_jur if t not in seen_nodes]; seen_nodes|=set(new_jur)
        parts=[]
        if fresh_r: parts.append(f"<b>{', '.join(fresh_r[:3])}</b> begin{'s' if len(fresh_r)==1 else ''} issuing signals")
        if fresh_t: parts.append(f"new themes emerge: <b>{', '.join(fresh_t[:3])}</b>")
        if fresh_j: parts.append(f"activity spreads to <b>{', '.join(fresh_j[:3])}</b>")
        headline=f"{len(new)} new record{'s' if len(new)!=1 else ''} this quarter"
        story[p]={"headline":headline,"parts":parts or ["continued activity across existing themes"],
                  "total":int(len(sub))}
    return {"periods":periods,"frames":frames,"story":story}

def trends_series(d):
    """Google-Trends-style monthly counts per object (theme/regulator/jurisdiction/steward),
    optionally splittable by jurisdiction. Returns objects list + a month axis + series."""
    r=d["records"]
    if r["_date"].notna().sum()<3: return {"months":[],"objects":{}}
    rr=r.dropna(subset=["_date"]).copy()
    rr["_m"]=rr["_date"].dt.to_period("M").astype(str)
    months=sorted(rr["_m"].unique())
    mi={m:i for i,m in enumerate(months)}
    def series_for(col,topn=12):
        out={}
        if col not in rr: return out
        top=rr[col].value_counts().head(topn).index
        for v in top:
            vec=[0]*len(months)
            sub=rr[rr[col]==v]
            for m,c in sub["_m"].value_counts().items(): vec[mi[m]]=int(c)
            out[str(v)]=vec
        return out
    objs={
        "Theme":series_for("primary_theme"),
        "Regulator":series_for("REGULATOR"),
        "Jurisdiction":series_for("JURISDICTION"),
    }
    ctr=d["controls"]
    if "risk_steward_name" in ctr and "_date" not in ctr:
        # stewards don't have dates; approximate via their theme activity
        pass
    return {"months":months,"objects":objs}



def ontology_tree(d):
    """Theme -> risk steward -> control -> gap hierarchy for the ontology view."""
    ctr=d["controls"]; gp=d["gaps"]
    if not len(ctr): return []
    gaps_by_ctrl={}
    for _,g in gp.iterrows():
        gaps_by_ctrl.setdefault(g.get("control_id"),[]).append(g)
    out=[]
    for theme,tc in ctr.groupby("primary_theme") if "primary_theme" in ctr else []:
        stewards=[]
        for stw,sc in tc.groupby("risk_steward_name") if "risk_steward_name" in tc else []:
            controls=[]
            for _,c in sc.head(8).iterrows():
                cg=gaps_by_ctrl.get(c.get("control_id"),[])
                controls.append({"id":str(c.get("control_id","")),"title":str(c.get("control_title","")),
                    "eff":str(c.get("control_effectiveness","")),
                    "gaps":[{"sev":str(x.get("gap_severity","")),"desc":str(x.get("gap_description",""))[:120]} for x in cg[:4]]})
            stewards.append({"steward":str(stw),"count":int(len(sc)),"controls":controls})
        out.append({"theme":str(theme).split(",")[0],"full":str(theme),"count":int(len(tc)),"stewards":stewards})
    return sorted(out,key=lambda x:-x["count"])

def impact_ripple(d):
    """For each theme: the cascade — records -> controls -> gaps -> follower jurisdictions.
    Powers the 'pick a theme, see what it touches' impact view."""
    r=d["records"]; ctr=d["controls"]; gp=d["gaps"]
    out={}
    for theme,g in r.groupby("primary_theme"):
        tc=ctr[ctr["primary_theme"]==theme] if "primary_theme" in ctr else ctr.iloc[0:0]
        tg=gp[gp["primary_theme"]==theme] if "primary_theme" in gp else gp.iloc[0:0]
        followers={}
        for _,row in g.iterrows():
            for f in _lit(row.get("likely_follower_jurisdictions")):
                if f: followers[f]=followers.get(f,0)+1
        out[str(theme)]={
            "records":int(len(g)),
            "controls":int(len(tc)),
            "hi_gaps":int((tg.get("gap_severity",pd.Series(dtype=str))=="High").sum()),
            "med_gaps":int((tg.get("gap_severity",pd.Series(dtype=str))=="Medium").sum()),
            "stewards":sorted(tc["risk_steward_name"].dropna().unique().tolist()) if "risk_steward_name" in tc else [],
            "jurisdictions":int(g["JURISDICTION"].nunique()) if "JURISDICTION" in g else 0,
            "followers":sorted(followers.items(),key=lambda x:-x[1])[:8],
            "business_lines":sorted({b for _,row in g.iterrows() for b in _lit(row.get("affected_business_lines"))}),
        }
    return out

def story_graph(data_dir="data"):
    """Build the REAL labelled, timeline story graph from graph_nodes.csv + graph_edges.csv.
    Entities are typed nodes; relationships are labelled directional edges. Frames grow by date.
    Falls back to {} if the files aren't present (page then uses the auto-derived version)."""
    from pathlib import Path as _P
    nf=_P(data_dir)/"graph_nodes.csv"; ef=_P(data_dir)/"graph_edges.csv"
    if not nf.exists() or not ef.exists(): return {}
    nodes=_read(str(nf)); edges=_read(str(ef))
    if not len(nodes) or not len(edges): return {}
    # canonical node table: name -> type (+ first date)
    nodes=nodes.dropna(subset=["name"]).copy()
    nodes["_d"]=pd.to_datetime(nodes.get("date"),errors="coerce")
    ntype={}; ndate={}; nperiod={}
    for _,x in nodes.iterrows():
        nm=str(x["name"]).strip()
        if nm not in ntype:
            ntype[nm]=str(x.get("type","Concept")); ndate[nm]=x["_d"]; nperiod[nm]=x.get("period")
        else:
            if pd.notna(x["_d"]) and (pd.isna(ndate[nm]) or x["_d"]<ndate[nm]): ndate[nm]=x["_d"]
    edges=edges.dropna(subset=["source","target"]).copy()
    edges["_d"]=pd.to_datetime(edges.get("date"),errors="coerce")
    # quarter periods from all dates
    alld=pd.concat([nodes["_d"],edges["_d"]]).dropna()
    if not len(alld): return {}
    edges["_q"]=edges["_d"].dt.to_period("Q").astype(str)
    def qof(nm):
        d=ndate.get(nm)
        return d.to_period("Q").__str__() if pd.notna(d) else None
    periods=sorted(set([q for q in edges["_q"].dropna().unique()]))
    # legend colours by type (team-style)
    TYPE_COLORS={
      "Regulator":"#C1121F","Regulation":"#F59E1B","Industry Body":"#2D6BE0",
      "Concept":"#7C3AED","Jurisdiction":"#0B7A57","Risk":"#B00020",
      "Theme":"#DB0011","Initiative":"#0891B2","Consumer Group":"#DB2777",
      "Future Focus":"#059669","Regulators & Associations":"#C1121F",
    }
    frames={}; story={}
    seen_nodes=set(); seen_edges=set()
    for p in periods:
        cum=edges[edges["_q"]<=p]
        new=edges[edges["_q"]==p]
        node_ids=set(cum["source"].astype(str))|set(cum["target"].astype(str))
        nodes_out=[{"id":nm,"type":ntype.get(nm,"Concept"),
                    "color":TYPE_COLORS.get(ntype.get(nm,"Concept"),"#6B7280"),
                    "born_q":qof(nm)or p} for nm in node_ids]
        links_out=[]
        for _,e in cum.iterrows():
            links_out.append({"source":str(e["source"]),"target":str(e["target"]),
                "label":str(e.get("label","")),"value":int(e.get("weight",1)) if pd.notna(e.get("weight")) else 1,
                "new":(str(e["_q"])==p)})
        # story log — what entities/relationships are new this quarter
        new_nodes=[nm for nm in (set(new["source"].astype(str))|set(new["target"].astype(str))) if nm not in seen_nodes]
        for nm in new_nodes: seen_nodes.add(nm)
        # group new nodes by type for narration
        by_type={}
        for nm in new_nodes: by_type.setdefault(ntype.get(nm,"Concept"),[]).append(nm)
        parts=[]
        order=["Regulator","Regulation","Industry Body","Initiative","Concept","Risk","Jurisdiction","Theme","Future Focus"]
        for ty in order:
            if by_type.get(ty):
                verb={"Regulator":"begin acting","Regulation":"are introduced","Industry Body":"engage",
                      "Initiative":"launch","Concept":"emerge","Risk":"are flagged","Jurisdiction":"come into scope",
                      "Theme":"emerge","Future Focus":"appear on the horizon"}.get(ty,"appear")
                nm3=", ".join(by_type[ty][:3])
                parts.append(f"<b>{ty}</b>: {nm3} {verb}")
        new_rels=[(str(e['source']),str(e['label']),str(e['target'])) for _,e in new.iterrows()]
        rel_examples=[f"{s} <i>{l}</i> {t}" for s,l,t in new_rels[:3]]
        frames[p]={"nodes":nodes_out,"links":links_out,"count":int(len(cum))}
        story[p]={"headline":f"{len(new)} new relationship{'s' if len(new)!=1 else ''} this quarter",
                  "parts":parts or ["existing entities strengthen their connections"],
                  "relationships":rel_examples,"total":int(len(cum))}
    # type legend actually present
    present_types=sorted({ntype[n] for n in ntype})
    legend=[{"type":ty,"color":TYPE_COLORS.get(ty,"#6B7280")} for ty in present_types]
    # ---- focused-view data: catalogue of entities + every edge as an atom ----
    # so the frontend can pick one object and render its timeline/ego-graph.
    entities=[]
    for nm in sorted(ntype):
        entities.append({"name":nm,"type":ntype[nm],
            "color":TYPE_COLORS.get(ntype[nm],"#6B7280"),
            "date":(ndate[nm].strftime("%Y-%m-%d") if pd.notna(ndate[nm]) else None),
            "period":nperiod.get(nm)})
    edge_atoms=[]
    for _,e in edges.iterrows():
        s=str(e["source"]); t=str(e["target"])
        dd=e["_d"]
        edge_atoms.append({"source":s,"target":t,"label":str(e.get("label","")),
            "date":(dd.strftime("%Y-%m-%d") if pd.notna(dd) else None),
            "source_type":ntype.get(s,"Concept"),"target_type":ntype.get(t,"Concept"),
            "weight":int(e.get("weight",1)) if pd.notna(e.get("weight")) else 1})
    # object types available for the picker (only those with entities)
    obj_types=sorted({ntype[n] for n in ntype})
    return {"periods":periods,"frames":frames,"story":story,"legend":legend,
            "entities":entities,"edges":edge_atoms,"obj_types":obj_types,
            "type_colors":TYPE_COLORS}

def build_payload(d):
    r=d["records"]
    def recs(df,n=None):
        df=df.head(n) if n else df
        return df.where(pd.notna(df),None).to_dict("records")
    total=len(r); lead=int((r["signal_type"]=="Leading").sum())
    kpi=dict(total=total,leading=lead,leading_pct=round(100*lead/max(total,1)),
        near=int(r.get("expected_action_horizon",pd.Series(dtype=str)).isin(["Immediate","Near-Term"]).sum()),
        emerging=int(r["is_emerging"].sum()) if "is_emerging" in r else 0,
        contagion=int(r["cross_jurisdiction_watch"].sum()) if "cross_jurisdiction_watch" in r else 0,
        controls=len(d["controls"]),gaps=len(d["gaps"]),
        hi_gaps=int((d["gaps"].get("gap_severity",pd.Series(dtype=str))=="High").sum()),
        jurisdictions=r["JURISDICTION"].nunique(),regulators=r["REGULATOR"].nunique())
    # contagion edges
    edges={}
    for _,row in r.iterrows():
        o=row.get("JURISDICTION")
        if pd.isna(o): continue
        for f in _lit(row.get("likely_follower_jurisdictions")):
            if f and f!=o: edges[(o,f)]=edges.get((o,f),0)+1
    edge_list=sorted([{"source":a,"target":b,"weight":w} for (a,b),w in edges.items()],key=lambda x:-x["weight"])[:24]
    # timeline events
    events=[]
    if r["_date"].notna().sum()>=3:
        top=r.sort_values("priority_score",ascending=False).dropna(subset=["_date"]).head(24).sort_values("_date")
        events=[{"date":x["_date"].strftime("%Y-%m-%d"),"label":str(x.get("TITLE",x["Message_ID"]))[:38],
                 "type":x["signal_type"],"note":str(x.get("so_what_summary",""))[:130]} for _,x in top.iterrows()]
    rsorted=r.sort_values("priority_score",ascending=False).head(60)
    radar_cols=[c for c in ["Message_ID","primary_theme","JURISDICTION","REGULATOR","RECORD_CAT_CDE","signal_type",
        "urgency","expected_action_horizon","regulatory_direction","priority_score","so_what_summary",
        "recommended_action","is_emerging","emerging_theme_label","affected_business_lines"] if c in r.columns]
    radar=[]
    for _,row in rsorted.iterrows():
        rec={c:(None if pd.isna(row[c]) else row[c]) for c in radar_cols}
        rec["breakdown"]=priority_breakdown(row)
        rec["urgency_reason"]=urgency_reason(row)
        radar.append(rec)
    return _clean(dict(
        kpi=kpi, matrix=exec_matrix(r), themes=per_theme(d),
        radar=radar, edges=edge_list, events=events,
        tgraph=time_sliced_graph(d), ontology=ontology_tree(d), impact=impact_ripple(d),
        trends=trends_series(d), story_graph=story_graph(d.get("_data_dir","data")),
        jm=recs(d["jm"],30), rm=recs(d["rm"],30), rc=recs(d["rc"]),
        controls=recs(d["controls"],400), gaps=recs(d["gaps"],600),
        colors=dict(red=RED,red_dk=RED_DK,ink=INK,muted=MUTED,line=LINE,lead=LEAD,coin=COIN,lag=LAG),
    ))


