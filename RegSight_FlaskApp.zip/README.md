# HSBC RegSight — local web app (v3)

Run one command, browser opens, reads data live. Change a CSV → refresh → updated.

## Run
Windows: double-click **RUN_ME.bat**. Or:
```
pip install flask pandas
python app.py
```
Opens http://localhost:5000 automatically. Put your 6 CSVs in the **data/** folder.

## Pages
- **Alert Radar** — priority queue with Signal + Horizon toggles, jurisdiction/regulator
  filters, premium chart, structured brief per alert, "Why this score?" breakdown, and an
  (i) icon on Urgency explaining WHY (real deadline countdown if TARGET_IMPL_DT exists, else a labelled proxy).
- **Executive Summary** — themes ordered most→least severe, red→yellow gradient. **Click any
  cell** to see the exact numbers and cutoffs behind HIGH/MED/LOW.
- **Risk Network** — knowledge graph + timeline merged into a story: press Play, new entities
  arrive (highlighted), and a story panel narrates what each quarter added.
- **Trends** (new) — Google-Trends-style line charts; pick object type (theme/regulator/
  jurisdiction) and compare multiple values month by month.
- **Cross-Jurisdiction** — proactive-market ranking + contagion flows, animated.
- **Controls & Gaps** — click any gap chip to open a full remediation detail (the gap + the fix, structured).
- **Regulators** — league table + source validation.
- **Impact & Ontology** — animated impact ripple + ontology tree (Theme → Steward → Control →
  Action, actions ordered High→Low and labelled "ACTION").
- **Options** (new) — hide pages you don't need, change accent colour. Saved in your browser.

## Theme drawer (View Details)
- Mind-map is now a **4-level zoomable/pannable** ownership map: Theme → Steward → Control →
  Gap, with a legend explaining the flow and why it's actionable.
- Recommendations shown as a **table**: Priority · Action to take · Fixes this gap.
- Gap Assessment: controls **ordered by worst severity**; click a control to expand a clean
  Sev / Gap / Fix table.

## Priority score
Transparent: 100 × confidence × (0.40·signal + 0.25·urgency + 0.20·impact + 0.15·novelty).
Shown per-alert. No black box.


## Risk Network — the real story graph (NEW)
Drop **graph_nodes.csv** and **graph_edges.csv** (from the entity-extraction LLM run)
into the data/ folder. The Risk Network page then builds the real labelled, timeline
story graph:
- nodes are typed entities, colour-coded (Regulator, Regulation, Concept, Jurisdiction,
  Industry Body, Risk, Initiative, Theme, Future Focus)
- edges are the actual relationships (Issues, Adopted by, Mandates, Enforces, Promotes…)
- the time slider grows the graph by relationship date; new nodes pulse in
- the story panel narrates each quarter's new entities and relationships

graph_nodes.csv columns: Message_ID, record_id, name, type, date, period
graph_edges.csv columns: source, target, label, date, source_type, target_type, weight

If these two files are absent, the page falls back to the auto-derived network.
