# HSBC RegSight — local web app (enhanced)

Run one command, browser opens, reads your data live. Change a CSV → refresh → updated.

## Run
Windows: double-click **RUN_ME.bat**. Or:
```
pip install flask pandas
python app.py
```
Opens http://localhost:5000 automatically.

## Data
Put your 6 CSVs in the **data/** folder (records_df, controls_df, gaps_df,
jurisdiction_master, regulator_master, record_cat_view). Refresh to update — no restart.

## Pages & what's new
- **Alert Radar** (landing) — priority queue with Signal + Horizon toggle groups,
  jurisdiction/regulator filters, a premium stacked chart, and every alert shows a
  structured brief (What happened / Recommended action) plus a "Why this score?"
  breakdown of the priority calculation. Help (?) explains the score.
- **Executive Summary** — themes ordered most→least severe, colour graded red→yellow.
  Help (?) defines every dimension and its HIGH/MED/LOW cutoffs. View Details per theme.
- **Risk Network** — knowledge graph + timeline merged: a time slider (Play button)
  grows the network quarter by quarter so you watch risk build up.
- **Cross-Jurisdiction** — animated proactive-market ranking + contagion flows, with
  Help explaining how to read and use it.
- **Controls & Gaps** — searchable/filterable; Help explains the signal→control→gap→fix chain.
- **Regulators** — league table + source validation; Help explains both.
- **Impact & Ontology** (new) — Impact ripple (theme → controls → gaps → who's affected →
  who follows) and an Ontology tree (Theme → Steward → Control → Gap, drill-down).

Every page has a consistent **?** help button. Theme drawer has a bigger,
zoomable 2-layer mind-map, cleaner recommendations, and a gap assessment where you
click a control to expand its gaps + fixes.

## Note on the priority score
Transparent, auditable: 100 × confidence × (0.40·signal + 0.25·urgency + 0.20·impact + 0.15·novelty).
Shown per-alert in the expandable brief. No black box.
