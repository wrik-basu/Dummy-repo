# HSBC RegSight — local web app

A proper local web app: run one command, a browser opens, and it reads your
data live. Change a CSV and refresh the page — no regeneration step.

## Folder layout
```
regsight_app/
  app.py            <- the Flask server (run this)
  derive.py         <- reads CSVs + computes everything
  RUN_ME.bat        <- Windows: double-click to start
  requirements.txt
  data/             <- PUT YOUR 6 CSVs HERE
    records_df.csv
    controls_df.csv
    gaps_df.csv
    jurisdiction_master.csv
    regulator_master.csv
    record_cat_view.csv
  templates/index.html
  static/           <- app.js + D3 + Chart.js (all local, no internet needed)
```

## Run it
Windows: double-click **RUN_ME.bat**.
Or from a terminal in this folder:
```
pip install flask pandas
python app.py
```
It prints `http://localhost:5000` and opens your browser automatically.

## Update the data
Replace any CSV in the **data/** folder, then just **refresh the browser**.
The server re-reads the CSVs on every page load — no restart, no regeneration.
(Confirmed: swapping records_df.csv from 250→120 rows updated the app live.)

## Pages
Proactive Radar · Executive Summary (animated matrix + View Details per theme) ·
Mind-Map · Knowledge Graph · Timeline · Cross-Jurisdiction · Controls & Gaps · Regulators

Click any theme's **View Details →** to open its workspace: Mind-Map,
Knowledge Graph, Recommendations, and Gap Assessment for that theme.

## Why a server instead of a single HTML file
The single-file version worked but had to be regenerated on every data change.
This reads data live, matches your "data folder → run → localhost → auto-update"
workflow, and keeps D3/Chart.js local so it runs on a locked-down network.

## Note on the ID column
The app auto-detects your record id (Message_ID / record_id / RECORD_ID / RCID).
If a page is empty, check that records_df.csv has one of those columns.
