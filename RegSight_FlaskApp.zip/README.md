# HSBC RegSight — local web app (v3)

Run one command, browser opens, reads data live. Change a CSV → refresh → updated.

## Run
Windows: double-click **RUN_ME.bat**. Or:
```
pip install flask pandas
python app.py
```
Opens http://localhost:5000 automatically. Put your 6 CSVs in the **data/** folder.

## Pages
- **Alert Radar** — priority queue with Signal + Horizon toggles, jurisdiction/regulator
  filters, premium chart, structured brief per alert, "Why this score?" breakdown, and an
  (i) icon on Urgency explaining WHY (real deadline countdown if TARGET_IMPL_DT exists, else a labelled proxy).
- **Executive Summary** — themes ordered most→least severe, red→yellow gradient. **Click any
  cell** to see the exact numbers and cutoffs behind HIGH/MED/LOW.
- **Risk Network** — knowledge graph + timeline merged into a story: press Play, new entities
  arrive (highlighted), and a story panel narrates what each quarter added.
- **Trends** (new) — Google-Trends-style line charts; pick object type (theme/regulator/
  jurisdiction) and compare multiple values month by month.
- **Cross-Jurisdiction** — proactive-market ranking + contagion flows, animated.
- **Controls & Gaps** — click any gap chip to open a full remediation detail (the gap + the fix, structured).
- **Regulators** — league table + source validation.
- **Impact & Ontology** — animated impact ripple + ontology tree (Theme → Steward → Control →
  Action, actions ordered High→Low and labelled "ACTION").
- **Options** (new) — hide pages you don't need, change accent colour. Saved in your browser.

## Theme drawer (View Details)
- Mind-map is now a **4-level zoomable/pannable** ownership map: Theme → Steward → Control →
  Gap, with a legend explaining the flow and why it's actionable.
- Recommendations shown as a **table**: Priority · Action to take · Fixes this gap.
- Gap Assessment: controls **ordered by worst severity**; click a control to expand a clean
  Sev / Gap / Fix table.

## Priority score
Transparent: 100 × confidence × (0.40·signal + 0.25·urgency + 0.20·impact + 0.15·novelty).
Shown per-alert. No black box.


## Risk Network — focused object tracking (NEW design)
Instead of one messy all-at-once graph, you focus on a single object and watch its story:
1. Pick an **object type** (Regulator, Regulation, Concept, Jurisdiction, Risk, Theme…)
2. Pick a specific **value** from the dropdown (e.g. HKMA)
3. See everything it connects to — on a **Timeline** (left→right chronological chain with
   labelled relationships) or an **Ego-network** (object centred, connections spoking out)
- **Show related types** toggles let you filter which connected entity types appear
- **Animate** plays the story building up quarter by quarter, or show All at once

Needs graph_nodes.csv + graph_edges.csv in the data/ folder.
graph_nodes.csv columns: Message_ID, record_id, name, type, date, period
graph_edges.csv columns: source, target, label, date, source_type, target_type, weight
