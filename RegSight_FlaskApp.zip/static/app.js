let DATA, C;
function initApp(data){
  DATA=data; C=DATA.colors;
  buildNav(); render();
}
window.initApp=initApp;
const $=(s,r=document)=>r.querySelector(s);
const el=(t,c,h)=>{const e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e;};
const esc=s=>(s==null?'':String(s)).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const num=n=>(n==null||isNaN(n))?'—':Number(n).toLocaleString();
const sig=s=>`<span class="chip sig-${esc(s)}"><span class="dot d-${esc(s)}"></span>${esc(s)}</span>`;
const sev=s=>`<span class="chip sev-${esc(s)}">${esc(s)}</span>`;
const sevColor=v=>({HIGH:'#E30613',MEDIUM:'#F5A623',LOW:'#F7D417'}[v]||'#F5A623');
function pri(v){const p=Math.max(0,Math.min(100,v||0));const c=p>=70?C.lag:p>=45?C.coin:C.lead;
  return `<div class="pri"><div class="bar"><div class="fill" style="width:${p}%;background:${c}"></div></div><b>${p.toFixed(0)}</b></div>`;}

const TABS=[['radar','🎯','Proactive Radar'],['exec','🗂','Executive Summary'],['mindmap','🧠','Mind-Map'],
['kg','🕸','Knowledge Graph'],['timeline','🕰','Timeline'],['contagion','🌐','Cross-Jurisdiction'],
['controls','🛡','Controls & Gaps'],['regs','🏛','Regulators']];
let current='radar';

function buildNav(){
  const nav=$('#nav');
  TABS.forEach(([id,ic,label],i)=>{
    const b=el('button',i===0?'active':'',`<span class="ic">${ic}</span>${label}`);
    b.onclick=()=>{document.querySelectorAll('.nav button').forEach(x=>x.classList.remove('active'));
      b.classList.add('active');go(id);};
    nav.appendChild(b);
  });
}
function go(id){current=id;render();}

function render(){
  const m=$('#main');m.innerHTML='';
  ({radar:pRadar,exec:pExec,mindmap:pMind,kg:pKG,timeline:pTime,contagion:pCont,controls:pCtrl,regs:pRegs}[current])(m);
}
const tt=$('#tt');
const showTT=(html,e)=>{tt.innerHTML=html;tt.style.opacity=1;tt.style.left=(e.clientX+14)+'px';tt.style.top=(e.clientY-10)+'px';};
const hideTT=()=>tt.style.opacity=0;
// measure a container's usable width AFTER it's in the DOM
const wOf=(node,fallback=980)=>{const w=node.getBoundingClientRect().width;return w>40?w:fallback;};

// ---------------- RADAR ----------------
function pRadar(m){
  const k=DATA.kpi;
  m.appendChild(el('div','pg',`<div class="eyebrow">Emerging-risk radar</div>
    <h1>What needs attention before it lands</h1>
    <p>Records ranked by a transparent priority score. Leading signals are surfaced ahead of formal rule-making — the earlier the signal, the more lead time.</p>`));
  m.insertAdjacentHTML('beforeend',`<div class="leg">
    <span><span class="dot" style="background:${C.lead}"></span><b>Leading</b> — early signal, before rules (news/consultation)</span>
    <span><span class="dot" style="background:${C.coin}"></span><b>Coincident</b> — the rule itself (RegDev)</span>
    <span><span class="dot" style="background:${C.lag}"></span><b>Lagging</b> — after the fact (enforcement/fines)</span></div>`);
  m.insertAdjacentHTML('beforeend',`<div class="kpis">
    <div class="kpi hot"><div class="lab">Leading signals</div><div class="val">${num(k.leading)}</div>
      <div class="sub">${k.leading_pct}% of ${num(k.total)} records — early warning</div><div class="spark">◗</div></div>
    <div class="kpi"><div class="lab">Near-term horizon</div><div class="val">${num(k.near)}</div><div class="sub">Immediate or near-term action</div></div>
    <div class="kpi"><div class="lab">Emerging themes</div><div class="val">${num(k.emerging)}</div><div class="sub">Novel topics beyond taxonomy</div></div>
    <div class="kpi"><div class="lab">Contagion watch</div><div class="val">${num(k.contagion)}</div><div class="sub">Likely follower jurisdictions</div></div></div>`);
  const g=el('div','grid g2');
  const left=el('div','panel');left.innerHTML=`<div class="ph"><div><h3>Priority queue</h3><small>Top ${DATA.radar.length} by score · click a row for the full brief</small></div></div><div id="queue"></div>`;
  const right=el('div','panel');right.innerHTML=`<div class="ph"><div><h3>Signal mix by source</h3><small>News breaks first; enforcement lags</small></div></div><canvas id="mixChart" height="220"></canvas>`;
  g.appendChild(left);g.appendChild(right);m.appendChild(g);
  // queue
  const q=$('#queue',left);
  DATA.radar.forEach(r=>{
    const row=el('div','qrow');
    const em=r.is_emerging?` <span class="emerging">NEW</span>`:'';
    row.innerHTML=`<div class="qhead">${pri(r.priority_score)}
      <div class="qmid"><div class="qt">${esc(String(r.primary_theme).split(',')[0])}${em}</div>
      <div class="qs"><span class="pill">${esc(r.Message_ID)}</span> · ${esc(r.JURISDICTION||'—')}</div></div>
      ${sig(r.signal_type)}</div>
      <div class="qbody"><div class="inner">
        <div><b>So what</b><br>${esc(r.so_what_summary||'—')}
        <div class="act"><div class="k">Recommended action</div>${esc(r.recommended_action||'Review with the risk steward.')}</div></div>
        <div><b>Regulator</b> ${esc(r.REGULATOR||'—')}<br><b>Horizon</b> ${esc(r.expected_action_horizon||'—')}<br>
        <b>Direction</b> ${esc(r.regulatory_direction||'—')}<br><b>Urgency</b> ${esc(r.urgency||'—')}</div>
      </div></div>`;
    row.querySelector('.qhead').onclick=()=>row.classList.toggle('open');
    q.appendChild(row);
  });
  // chart
  const rc=DATA.rc;
  new Chart($('#mixChart'),{type:'bar',data:{labels:rc.map(x=>x.record_cat_code),
    datasets:[{label:'Leading',data:rc.map(x=>x.leading_signals),backgroundColor:C.lead,stack:'s'},
    {label:'Coincident',data:rc.map(x=>x.coincident_signals),backgroundColor:C.coin,stack:'s'},
    {label:'Lagging',data:rc.map(x=>x.lagging_signals),backgroundColor:C.lag,stack:'s'}]},
    options:{plugins:{legend:{position:'bottom'}},scales:{x:{stacked:true,grid:{display:false}},y:{stacked:true}}}});
}

// ---------------- EXEC MATRIX (animated + View Details) ----------------
function pExec(m){
  m.appendChild(el('div','pg',`<div class="eyebrow">Executive summary</div>
    <h1>Theme × feature risk matrix</h1>
    <p>Every cell is computed live from the data — not hardcoded. Hover to inspect, click a theme header or its <b>View Details</b> button to open the full theme workspace.</p>`));
  const M=DATA.matrix;
  const feats=["Severity","Theme Velocity","X-Jurisdiction Overlap","News-RegDev Corr","Enforcement Corr"];
  const legends={"Severity":"HIGH &gt; MEDIUM &gt; LOW","Theme Velocity":"≥2.5 HIGH · 1–2.5 MED · &lt;1 LOW",
    "X-Jurisdiction Overlap":"&gt;66% HIGH · 33–66% MED","News-RegDev Corr":"corr ≥.5 HIGH · ≥.2 MED","Enforcement Corr":"FANDE ≥15% HIGH · ≥5% MED"};
  const n=M.length;
  const cols=`grid-template-columns:210px repeat(${n},minmax(150px,1fr))`;
  const wrap=el('div','matrix');
  const grid=el('div','mgrid');
  // header
  const head=el('div','mhead');head.style.cssText=cols;
  head.appendChild(el('div','corner','Features'));
  M.forEach((r,i)=>{const c=el('div','thcard',r.theme);c.style.background=`linear-gradient(135deg,${sevColor(r.Severity)},${sevColor(r.Severity)}cc)`;
    c.onclick=()=>openTheme(r.theme);grid.dataset;head.appendChild(c);});
  grid.appendChild(head);
  // feature rows
  feats.forEach(f=>{
    const row=el('div','mrow');row.style.cssText=cols;
    row.appendChild(el('div','mrlab',`<b>${f}</b><small>${legends[f]}</small>`));
    M.forEach(r=>{const v=r[f]||'MEDIUM';
      row.appendChild(el('div','mcell',`<div class="badge"><span class="dot ${v==='HIGH'?'d-Lagging':v==='MEDIUM'?'d-Coincident':'d-Leading'}"></span><span class="sev-${v}" style="padding:0;background:none">${v}</span></div><div class="leg2">${legends[f]}</div>`));});
    grid.appendChild(row);
  });
  // View Details button row
  const vd=el('div','mvd');vd.style.cssText=cols;
  vd.appendChild(el('div',''));
  M.forEach(r=>{const b=el('button','vdbtn','View Details →');b.onclick=()=>openTheme(r.theme);vd.appendChild(b);});
  grid.appendChild(vd);
  wrap.appendChild(grid);m.appendChild(wrap);
}

// ---------------- MIND-MAP (global) ----------------
function pMind(m){
  m.appendChild(el('div','pg',`<div class="eyebrow">Mind-map</div><h1>Theme framework</h1>
    <p>Radial map of themes sized by activity. Hover a node for detail; click to open the theme.</p>`));
  const box=el('div','viz');box.innerHTML=`<div class="vhead"><h3>Emerging Risk — Control Framework</h3><p>Themes and their weight across the corpus</p></div><div id="mm"></div>`;
  m.appendChild(box);
  const children=Object.entries(DATA.themes).map(([t,v])=>({name:String(t).split(',')[0],full:t,value:v.controls||v.news+v.regdev}));
  requestAnimationFrame(()=>drawMind($('#mm',box),{name:"Emerging Risk",children}));
}
function drawMind(node,data){
  const W=wOf(node),H=560;
  const svg=d3.select(node).append('svg').attr('width',W).attr('height',H);
  const g=svg.append('g').attr('transform',`translate(150,${H/2})`);
  const root=d3.hierarchy(data);
  d3.tree().size([H-70,W-330])(root);
  g.selectAll('path').data(root.links()).join('path').attr('fill','none').attr('stroke',C.line).attr('stroke-width',1.6)
    .attr('d',d3.linkHorizontal().x(d=>d.y).y(d=>d.x));
  const nd=g.selectAll('g').data(root.descendants()).join('g').attr('transform',d=>`translate(${d.y},${d.x})`);
  nd.append('circle').attr('r',d=>d.depth===0?10:6+Math.min(6,(d.data.value||0)/8))
    .attr('fill',d=>d.depth===0?C.ink:C.red).style('cursor','pointer')
    .on('mousemove',(e,d)=>d.data.value&&showTT(`<b>${esc(d.data.name)}</b><br>${d.data.value} items`,e))
    .on('mouseout',hideTT).on('click',(e,d)=>d.data.full&&openTheme(d.data.full));
  nd.append('text').attr('dy',4).attr('x',d=>d.children?-13:13).style('text-anchor',d=>d.children?'end':'start')
    .style('font-size','12.5px').style('font-weight',d=>d.depth===0?'700':'500').style('font-family','Inter').text(d=>d.data.name);
}

// ---------------- KNOWLEDGE GRAPH (global) ----------------
function pKG(m){
  m.appendChild(el('div','pg',`<div class="eyebrow">Knowledge graph</div><h1>How it all connects</h1>
    <p>Force-directed network of themes, jurisdictions and regulators. Drag any node to explore.</p>`));
  const box=el('div','viz');box.innerHTML=`<div class="vhead"><h3>Knowledge Graph</h3><p>Themes ↔ jurisdictions ↔ regulators — drag to explore</p></div><div id="kg"></div>`;
  m.appendChild(box);
  // build global graph from top themes (ids used verbatim as keys AND in links)
  const nodes={},links=[];
  const add=(id,type)=>{if(!nodes[id])nodes[id]={id,type};};
  Object.entries(DATA.themes).slice(0,8).forEach(([t,v])=>{
    const tn=String(t).split(',')[0];add(tn,'theme');
    (v.kg_nodes||[]).forEach(nn=>{if(nn.type!=='theme'){add(nn.id,nn.type);links.push({source:tn,target:nn.id,value:nn.type==='jurisdiction'?2:1});}});
  });
  requestAnimationFrame(()=>drawKG($('#kg',box),Object.values(nodes),links));
}
function drawKG(node,nodes,links){
  const W=wOf(node),H=600;
  const color={theme:C.red,jurisdiction:'#2D6BE0',regulator:C.coin};
  const svg=d3.select(node).append('svg').attr('width',W).attr('height',H);
  const sim=d3.forceSimulation(nodes)
    .force('link',d3.forceLink(links).id(d=>d.id).distance(78))
    .force('charge',d3.forceManyBody().strength(-180))
    .force('center',d3.forceCenter(W/2,H/2)).force('collide',d3.forceCollide(20));
  const link=svg.append('g').selectAll('line').data(links).join('line').attr('stroke',C.line).attr('stroke-width',d=>Math.sqrt(d.value||1)*1.4);
  const nd=svg.append('g').selectAll('circle').data(nodes).join('circle')
    .attr('r',d=>d.type==='theme'?12:7).attr('fill',d=>color[d.type]).attr('stroke','#fff').attr('stroke-width',2).style('cursor','grab')
    .call(d3.drag().on('start',(e,d)=>{if(!e.active)sim.alphaTarget(.3).restart();d.fx=d.x;d.fy=d.y})
      .on('drag',(e,d)=>{d.fx=e.x;d.fy=e.y}).on('end',(e,d)=>{if(!e.active)sim.alphaTarget(0);d.fx=null;d.fy=null}))
    .on('mousemove',(e,d)=>showTT(`<b>${esc(d.id)}</b><br>${d.type}`,e)).on('mouseout',hideTT);
  const lab=svg.append('g').selectAll('text').data(nodes.filter(n=>n.type==='theme')).join('text')
    .text(d=>d.id).style('font-size','10.5px').style('font-weight','600').style('font-family','Inter').attr('dx',14).attr('dy',4);
  // legend
  const lg=svg.append('g').attr('transform','translate(18,18)');
  [['Theme',C.red],['Jurisdiction','#2D6BE0'],['Regulator',C.coin]].forEach((d,i)=>{
    lg.append('circle').attr('cx',6).attr('cy',i*21+6).attr('r',6).attr('fill',d[1]);
    lg.append('text').attr('x',18).attr('y',i*21+10).text(d[0]).style('font-size','11px').style('fill',C.muted).style('font-family','Inter');});
  sim.on('tick',()=>{link.attr('x1',d=>d.source.x).attr('y1',d=>d.source.y).attr('x2',d=>d.target.x).attr('y2',d=>d.target.y);
    nd.attr('cx',d=>d.x).attr('cy',d=>d.y);lab.attr('x',d=>d.x).attr('y',d=>d.y);});
}

// ---------------- TIMELINE ----------------
function pTime(m){
  m.appendChild(el('div','pg',`<div class="eyebrow">Timeline</div><h1>The regulatory story over time</h1>
    <p>Key records across time, coloured by signal type. Leading events (green) precede the rules that follow.</p>`));
  m.insertAdjacentHTML('beforeend',`<div class="leg">
    <span><span class="dot" style="background:${C.lead}"></span>Leading</span>
    <span><span class="dot" style="background:${C.coin}"></span>Coincident</span>
    <span><span class="dot" style="background:${C.lag}"></span>Lagging</span></div>`);
  if(!DATA.events.length){m.insertAdjacentHTML('beforeend','<div class="panel">No dated records available (need REC_START_DT).</div>');return;}
  const box=el('div','viz');box.innerHTML=`<div class="vhead"><h3>Regulatory Story Timeline</h3><p>Hover a node for detail</p></div><div id="tl"></div>`;
  m.appendChild(box);
  requestAnimationFrame(()=>drawTimeline($('#tl',box),DATA.events));
}
function drawTimeline(node,ev){
  const W=wOf(node),H=440,Mg=60;
  ev=ev.map(d=>({...d,d:new Date(d.date)}));
  const color={Leading:C.lead,Coincident:C.coin,Lagging:C.lag};
  const svg=d3.select(node).append('svg').attr('width',W).attr('height',H);
  const x=d3.scaleTime().domain(d3.extent(ev,d=>d.d)).range([Mg,W-Mg]);
  svg.append('line').attr('x1',Mg).attr('x2',W-Mg).attr('y1',H/2).attr('y2',H/2).attr('stroke',C.line).attr('stroke-width',2);
  svg.append('g').attr('transform',`translate(0,${H-28})`).call(d3.axisBottom(x).ticks(8)).selectAll('text').style('font-size','11px').style('fill',C.muted);
  const j=i=>i%2===0?-1:1;
  const g=svg.selectAll('g.e').data(ev).join('g').attr('transform',(d,i)=>`translate(${x(d.d)},${H/2+j(i)*46})`);
  g.append('line').attr('y1',0).attr('y2',(d,i)=>-j(i)*46).attr('stroke',C.line);
  g.append('circle').attr('r',9).attr('fill',d=>color[d.type]||C.muted).attr('stroke','#fff').attr('stroke-width',2).style('cursor','pointer')
    .on('mousemove',(e,d)=>showTT(`<b>${esc(d.label)}</b><br>${d.date}<br>${esc(d.note||'')}`,e)).on('mouseout',hideTT);
  g.append('text').attr('y',(d,i)=>j(i)>0?24:-15).attr('text-anchor','middle').style('font-size','10px').style('font-weight','600').style('font-family','Inter').text(d=>d.label.slice(0,20));
}

// ---------------- CONTAGION ----------------
function pCont(m){
  m.appendChild(el('div','pg',`<div class="eyebrow">Cross-jurisdiction contagion</div><h1>Which markets move first — and who follows</h1>
    <p>Directional flows from likely-follower jurisdictions. A strong A→B flow means a theme in A tends to reach B next.</p>`));
  const g=el('div','grid g2b');
  const l=el('div','panel');l.innerHTML='<div class="ph"><div><h3>Most proactive markets</h3><small>leading-signal ratio</small></div></div><div id="lead"></div>';
  const r=el('div','panel');r.innerHTML='<div class="ph"><div><h3>Contagion flows</h3><small>origin ▸ follower · by frequency</small></div></div><div class="scroll" id="flows" style="max-height:520px"></div>';
  g.appendChild(l);g.appendChild(r);m.appendChild(g);
  const jm=DATA.jm.filter(j=>j.record_count>=3).sort((a,b)=>(b.leading_ratio||0)-(a.leading_ratio||0)).slice(0,12);
  const mx=Math.max(...jm.map(j=>j.leading_ratio||0),.01);
  const ld=$('#lead',l);
  jm.forEach(j=>{const row=el('div');row.style.cssText='display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--line)';
    row.innerHTML=`<div style="width:150px;font-size:12.5px;font-weight:500">${esc(j.jurisdiction)}</div>
    <div style="flex:1;height:8px;background:var(--line);border-radius:4px;overflow:hidden"><div style="height:100%;width:${(j.leading_ratio/mx*100).toFixed(0)}%;background:${C.lead};border-radius:4px"></div></div>
    <b style="width:38px;text-align:right;font-family:Newsreader,serif">${(j.leading_ratio||0).toFixed(2)}</b>`;ld.appendChild(row);});
  const fl=$('#flows',r);
  if(!DATA.edges.length){fl.innerHTML='<p style="padding:16px;color:var(--muted)">No follower jurisdictions tagged.</p>';return;}
  DATA.edges.forEach(e=>{const row=el('div');row.style.cssText='display:flex;align-items:center;gap:10px;padding:10px 12px;border-bottom:1px solid var(--line)';
    row.innerHTML=`<span class="pill" style="background:var(--ink);color:#fff;border:0">${esc(e.source)}</span>
    <span style="flex:1;height:2px;background:linear-gradient(90deg,var(--red),transparent);position:relative"><span style="position:absolute;right:-2px;top:-8px;color:var(--red)">▸</span></span>
    <span class="pill">${esc(e.target)}</span><b style="font-family:Newsreader,serif;color:var(--muted)">×${e.weight}</b>`;fl.appendChild(row);});
}

// ---------------- CONTROLS ----------------
function pCtrl(m){
  const k=DATA.kpi;
  m.appendChild(el('div','pg',`<div class="eyebrow">Control impact & gap assessment</div><h1>Which controls each signal touches</h1>
    <p>Synthetic HSBC-style controls mapped to records, with probable gaps and recommendations.</p>`));
  m.insertAdjacentHTML('beforeend',`<div class="kpis">
    <div class="kpi"><div class="lab">Controls mapped</div><div class="val">${num(k.controls)}</div><div class="sub">across all records</div></div>
    <div class="kpi"><div class="lab">Probable gaps</div><div class="val">${num(k.gaps)}</div><div class="sub">with recommendations</div></div>
    <div class="kpi hot"><div class="lab">High-severity gaps</div><div class="val">${num(k.hi_gaps)}</div><div class="sub">priority remediation</div><div class="spark">!</div></div>
    <div class="kpi"><div class="lab">Jurisdictions</div><div class="val">${num(k.jurisdictions)}</div><div class="sub">in scope</div></div></div>`);
  const p=el('div','panel');
  p.innerHTML=`<div style="display:flex;gap:10px;margin-bottom:14px;flex-wrap:wrap">
    <input id="cq" placeholder="Search control, obligation, record…" style="flex:1;min-width:220px;padding:9px 12px;border:1px solid var(--line);border-radius:9px;font-family:inherit">
    <select id="cth" style="padding:9px 12px;border:1px solid var(--line);border-radius:9px;font-family:inherit"><option value="">All themes</option></select>
    <select id="csv" style="padding:9px 12px;border:1px solid var(--line);border-radius:9px;font-family:inherit"><option value="">All severities</option><option>High</option><option>Medium</option><option>Low</option></select></div>
    <div class="scroll"><table><thead><tr><th>Control</th><th>Steward</th><th>Theme</th><th>Type</th><th>Effectiveness</th><th>Gaps</th></tr></thead><tbody id="cbody"></tbody></table></div>`;
  m.appendChild(p);
  const themes=[...new Set(DATA.controls.map(c=>c.primary_theme).filter(Boolean))].sort();
  themes.forEach(t=>$('#cth',p).appendChild(el('option',null,esc(t))));
  const gapBy={};DATA.gaps.forEach(g=>{(gapBy[g.control_id]=gapBy[g.control_id]||[]).push(g);});
  function draw(){
    const q=($('#cq',p).value||'').toLowerCase(),th=$('#cth',p).value,sv=$('#csv',p).value;
    const tb=$('#cbody',p);tb.innerHTML='';
    DATA.controls.filter(c=>{
      if(th&&c.primary_theme!==th)return false;
      if(sv&&!(gapBy[c.control_id]||[]).some(g=>g.gap_severity===sv))return false;
      if(q&&!`${c.control_id} ${c.control_title} ${c.obligation_addressed} ${c.Message_ID}`.toLowerCase().includes(q))return false;
      return true;}).slice(0,120).forEach(c=>{
      const gaps=gapBy[c.control_id]||[];
      const worst=gaps.some(g=>g.gap_severity==='High')?'High':gaps.some(g=>g.gap_severity==='Medium')?'Medium':gaps.length?'Low':null;
      const tr=el('tr');tr.innerHTML=`<td><span class="pill">${esc(c.control_id)}</span><div style="font-weight:600;margin-top:3px">${esc(c.control_title)}</div></td>
        <td>${esc(c.risk_steward_name)}</td><td style="color:var(--muted)">${esc(String(c.primary_theme||'').split(',')[0])}</td>
        <td>${esc(c.control_type||'—')}</td><td>${esc(c.control_effectiveness||'—')}</td>
        <td>${worst?sev(worst):''} <small style="color:var(--muted)">${gaps.length}</small></td>`;
      tb.appendChild(tr);});
  }
  $('#cq',p).oninput=draw;$('#cth',p).onchange=draw;$('#csv',p).onchange=draw;draw();
}

// ---------------- REGULATORS ----------------
function pRegs(m){
  m.appendChild(el('div','pg',`<div class="eyebrow">Regulator activity & source validation</div><h1>Who is driving the agenda</h1>
    <p>Regulators ranked by volume, with reach and leading-signal output. The bars prove the engine is grounded.</p>`));
  const g=el('div','grid g2');
  const l=el('div','panel');l.innerHTML='<div class="ph"><div><h3>Regulator league table</h3></div></div><div class="scroll"><table><thead><tr><th>Regulator</th><th>Records</th><th>Juris.</th><th>Leading</th><th>Conf.</th></tr></thead><tbody id="rb"></tbody></table></div>';
  const r=el('div','panel');r.innerHTML='<div class="ph"><div><h3>Source-category validation</h3><small>news skews leading, enforcement lags</small></div></div><div id="scv"></div>';
  g.appendChild(l);g.appendChild(r);m.appendChild(g);
  const rb=$('#rb',l);
  DATA.rm.forEach(x=>{const tr=el('tr');tr.innerHTML=`<td style="font-weight:600">${esc(x.regulator)}</td><td>${num(x.record_count)}</td>
    <td style="color:var(--muted)">${num(x.jurisdiction_count)}</td><td><span class="chip sig-Leading">${num(x.leading_signals)}</span></td>
    <td>${x.avg_confidence!=null?Number(x.avg_confidence).toFixed(2):'—'}</td>`;rb.appendChild(tr);});
  const scv=$('#scv',r);
  DATA.rc.forEach(x=>{const tot=Math.max(x.record_count||1,1),ld=x.leading_signals||0,lg=x.lagging_signals||0;
    scv.insertAdjacentHTML('beforeend',`<div style="margin-bottom:14px"><b>${esc(x.record_cat_code)}</b> — <span style="color:var(--muted)">${esc(x.description||'')}</span>
    <div style="display:flex;height:11px;border-radius:6px;overflow:hidden;margin-top:5px">
    <div style="width:${100*ld/tot}%;background:${C.lead}"></div><div style="width:${100*(tot-ld-lg)/tot}%;background:${C.coin}"></div><div style="width:${100*lg/tot}%;background:${C.lag}"></div></div></div>`);});
}

// ---------------- THEME DETAIL DRAWER (View Details) ----------------
function openTheme(theme){
  const t=DATA.themes[theme];if(!t)return;
  const short=String(theme).split(',')[0];
  const recsHtml=(t.recs||[]).map(g=>`<div class="recgrp"><div class="rt">${esc(g.control_id)} · ${esc(g.title)}</div>
    ${g.items.map(i=>`<div class="recitem">•&nbsp;<span>${esc(i.text)} ${sev(i.sev)}</span></div>`).join('')}</div>`).join('')||'<p style="color:var(--muted)">No recommendations.</p>';
  const gapHtml=(t.gap_controls||[]).map(c=>`<div class="gapcard"><div class="gc-h"><span class="pill">${esc(c.control_id)}</span><span style="color:var(--muted);font-size:12px">${esc(c.steward)} · ${esc(c.eff)}</span></div>
    <b>${esc(c.title)}</b><div style="font-size:12px;color:var(--muted);margin:4px 0">${esc(c.obligation||'')}</div>
    ${c.gaps.map(x=>`<div style="margin-top:8px;font-size:12.5px"><b>Gap</b> ${sev(x.sev)}<br>${esc(x.gap)}<br><span style="color:${C.lead}"><b>→ Recommendation:</b></span> ${esc(x.rec)}</div>`).join('')}</div>`).join('')||'<p style="color:var(--muted)">No controls mapped.</p>';
  $('#drawerBody').innerHTML=`
    <div class="dhead"><button class="dclose" onclick="closeDrawer()">×</button>
      <div class="de">Theme workspace · View Details</div><h2>${esc(short)}</h2></div>
    <div class="dbody">
      <div class="dkpis">
        <div class="dkpi"><div class="v">${num(t.news)}</div><div class="l">News</div></div>
        <div class="dkpi"><div class="v">${num(t.regdev)}</div><div class="l">RegDev</div></div>
        <div class="dkpi"><div class="v" style="color:${C.red}">${num(t.controls)}</div><div class="l">Controls</div></div>
        <div class="dkpi"><div class="v" style="color:${C.lag}">${num(t.hi_gaps)}</div><div class="l">High gaps</div></div>
        <div class="dkpi"><div class="v" style="color:${C.coin}">${num(t.med_gaps)}</div><div class="l">Med gaps</div></div>
      </div>
      <div class="dtabs">
        <button class="dtab active" data-p="p-mind">🧠 Mind-Map</button>
        <button class="dtab" data-p="p-kg">🕸 Knowledge Graph</button>
        <button class="dtab" data-p="p-rec">📋 Recommendations</button>
        <button class="dtab" data-p="p-gap">🧭 Gap Assessment</button>
      </div>
      <div class="dpane active" id="p-mind"><div class="viz"><div class="vhead"><h3>${esc(short)} — sub-topics</h3></div><div id="dmm"></div></div></div>
      <div class="dpane" id="p-kg"><div class="viz"><div class="vhead"><h3>Connections</h3></div><div id="dkg"></div></div></div>
      <div class="dpane" id="p-rec"><div class="dsec"><h3>📋 Recommendations summary</h3>${recsHtml}</div></div>
      <div class="dpane" id="p-gap"><div class="grid" style="grid-template-columns:1fr 1.1fr">
        <div class="dsec"><h3>📄 Regulation content</h3><p style="font-size:13px;line-height:1.6">${esc(t.reg_content||'—')}</p></div>
        <div class="dsec"><h3>🧭 Controls, gaps & recommendations</h3>${gapHtml}</div></div></div>
    </div>`;
  // tabs
  $('#drawerBody').querySelectorAll('.dtab').forEach(b=>b.onclick=()=>{
    $('#drawerBody').querySelectorAll('.dtab').forEach(x=>x.classList.remove('active'));
    $('#drawerBody').querySelectorAll('.dpane').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');$('#'+b.dataset.p).classList.add('active');
    // draw viz lazily when its tab opens (container now visible -> has width)
    if(b.dataset.p==='p-kg'&&!$('#dkg').dataset.drawn){$('#dkg').dataset.drawn=1;
      const nodes=t.kg_nodes.map(n=>({...n})),links=t.kg_links.map(l=>({...l}));drawKG($('#dkg'),nodes,links);}
  });
  $('#drawer').classList.add('open');$('#scrim').classList.add('show');
  // draw the first (visible) viz after the drawer transition
  setTimeout(()=>drawMind($('#dmm'),{name:short,children:(t.mindmap||[]).map(s=>({name:s.name,value:s.value}))}),120);
}
function closeDrawer(){$('#drawer').classList.remove('open');$('#scrim').classList.remove('show');}
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeDrawer();});
