// ============ HSBC RegSight — enhanced UI ============
let DATA, C;
function initApp(data){ DATA=data; C=DATA.colors; buildNav(); render(); }
window.initApp=initApp;

const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>[...r.querySelectorAll(s)];
const el=(t,c,h)=>{const e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e;};
const esc=s=>(s==null?'':String(s)).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const num=n=>(n==null||isNaN(n))?'—':Number(n).toLocaleString();
const sig=s=>`<span class="chip sig-${esc(s)}"><span class="dot d-${esc(s)}"></span>${esc(s)}</span>`;
const sev=s=>`<span class="chip sev-${esc(s)}">${esc(s)}</span>`;
// gradient red→yellow ramp by severity rank (0=highest)
const RAMP=['#C1121F','#E63329','#F26522','#F59E1B','#F7C948','#FBE27A'];
const sevColor=v=>({HIGH:'#C1121F',MEDIUM:'#F59E1B',LOW:'#F7C948'}[v]||'#F59E1B');
function pri(v){const p=Math.max(0,Math.min(100,v||0));const c=p>=70?C.lag:p>=45?C.coin:C.lead;
  return `<div class="pri"><div class="bar"><div class="fill" style="width:${p}%;background:${c}"></div></div><b>${p.toFixed(0)}</b></div>`;}
const tt=$('#tt');
const showTT=(html,e)=>{tt.innerHTML=html;tt.style.opacity=1;tt.style.left=Math.min(e.clientX+14,innerWidth-300)+'px';tt.style.top=(e.clientY-10)+'px';};
const hideTT=()=>tt.style.opacity=0;
const wOf=(node,fb=980)=>{const w=node.getBoundingClientRect().width;return w>40?w:fb;};

// ---- consistent HELP panel ----
const HELP={
 radar:{title:"Alert Radar — how to read it",body:`
   <p><b>What this page is:</b> your early-warning queue. Every regulatory signal we ingested is scored and ranked so you act on the most important first.</p>
   <h4>Priority score (0–100)</h4>
   <p>A transparent, auditable blend — no black box. Higher = act sooner:</p>
   <ul><li><b>Signal type ×40%</b> — Leading (early) scores highest, Lagging (enforcement) lowest</li>
   <li><b>Urgency ×25%</b> — High/Medium/Low from the model</li>
   <li><b>Business impact ×20%</b></li>
   <li><b>Novelty ×15%</b> — how new/unusual the topic is</li></ul>
   <p>All multiplied by model <b>confidence</b>. Every alert shows its own breakdown when expanded.</p>
   <h4>Signal types</h4>
   <p><span style="color:#0B7A57">●</span> <b>Leading</b> — before rules land (news, consultation). <span style="color:#C67A00">●</span> <b>Coincident</b> — the rule itself. <span style="color:#B00020">●</span> <b>Lagging</b> — after the fact (fines).</p>`},
 exec:{title:"Executive Summary — the risk matrix",body:`
   <p><b>What this is:</b> a board-level heatmap. Rows are risk dimensions, columns are themes (ordered most→least severe, left to right). Colour goes red→yellow with severity.</p>
   <h4>The five dimensions</h4>
   <ul>
   <li><b>Severity</b> — mean priority of the theme's records. <b>≥65 HIGH · ≥45 MED · else LOW</b></li>
   <li><b>Theme Velocity</b> — is activity accelerating? recent-3-month rate vs baseline. <b>≥2.5× HIGH · ≥1× MED</b></li>
   <li><b>X-Jurisdiction Overlap</b> — how many markets it spans. <b>&gt;66% HIGH · 33–66% MED</b></li>
   <li><b>News→RegDev Corr</b> — does news reliably precede rules here? monthly correlation. <b>≥.5 HIGH · ≥.2 MED</b></li>
   <li><b>Enforcement Corr</b> — share that's already fines/actions. <b>≥15% HIGH · ≥5% MED</b></li>
   </ul>
   <p>Click any theme's <b>View Details</b> to open its full workspace.</p>`},
 graph:{title:"Risk Network over time",body:`
   <p><b>What this is:</b> a living map of how themes connect to jurisdictions and regulators — and how that web <b>grew over time</b>.</p>
   <p>Drag the <b>time slider</b> (or press Play). Each step adds the quarter's new activity, so you watch the regulatory landscape build up. Early clusters are where risk started; dense late clusters are where it's concentrating now.</p>
   <p><span style="color:#DB0011">●</span> Theme · <span style="color:#2D6BE0">●</span> Jurisdiction · <span style="color:#C67A00">●</span> Regulator. Drag any node; hover for detail.</p>`},
 contagion:{title:"Cross-Jurisdiction — how regulation spreads",body:`
   <p><b>The question this answers:</b> "If a rule appears in market A, who copies it next — and how much lead time do we get?"</p>
   <p><b>Left — Most proactive markets:</b> ranked by leading-signal ratio. High = this market tends to move <i>first</i>, so watching it buys you warning time elsewhere.</p>
   <p><b>Right — Contagion flows:</b> A ▸ B means themes appearing in A have historically shown up in B afterwards. Thicker/more frequent = stronger follow pattern. Use it to pre-position controls in follower markets before the rule lands.</p>`},
 controls:{title:"Controls & Gaps — the response layer",body:`
   <p><b>What this is:</b> the bridge from <i>signal</i> to <i>action</i>. Each regulatory signal is mapped to the internal controls it affects, and each control is assessed for <b>probable gaps</b> with a recommended fix.</p>
   <p><b>How it helps:</b> instead of "here's a regulation," you get "here's the specific control that's now inadequate, here's why, here's what to change." Filter by theme, risk steward, or effectiveness to route work to the right owner.</p>
   <p>Control IDs (<span class="pill">1C-…</span>) are stable identifiers so a control can be referenced across alerts, gap logs and remediation tracking — the same control often appears against several signals.</p>`},
 regs:{title:"Regulators & Source Validation",body:`
   <p><b>Left — league table:</b> which regulators are driving activity, their reach across jurisdictions, and how many <i>leading</i> signals they generate. Tells you whose publications to monitor most closely.</p>
   <p><b>Right — source validation:</b> proof the engine is grounded in reality. It shows that NEWS skews <i>leading</i> and enforcement (FANDE) skews <i>lagging</i> — exactly what you'd expect if the signal-timing model is correct. It's the credibility check for the whole dashboard.</p>`},
 impact:{title:"Impact & Ontology",body:`
   <p><b>Two lenses on the same data:</b></p>
   <p><b>Impact ripple:</b> pick a theme and trace its cascade — how many records, which controls it hits, how many gaps open, which risk stewards own it, and which jurisdictions are likely to follow. Answers "if this theme escalates, what's our exposure?"</p>
   <p><b>Ontology tree:</b> the structured hierarchy — Theme → Risk Steward → Control → Gap. It's the knowledge model behind the numbers: drill from a broad theme down to a specific control weakness.</p>`},
};
function helpBtn(key){return `<button class="help-btn" onclick="openHelp('${key}')" title="How to read this page">?</button>`;}
function openHelp(key){const h=HELP[key];if(!h)return;
  $('#helpBody').innerHTML=`<h2>${esc(h.title)}</h2>${h.body}`;
  $('#helpModal').classList.add('show');}
function closeHelp(){$('#helpModal').classList.remove('show');}
window.openHelp=openHelp;window.closeHelp=closeHelp;

const TABS=[['radar','🛰','Alert Radar'],['exec','🗂','Executive Summary'],['graph','🕸','Risk Network'],
['contagion','🌐','Cross-Jurisdiction'],['controls','🛡','Controls & Gaps'],['regs','🏛','Regulators'],['impact','🧬','Impact & Ontology']];
let current='radar';
function buildNav(){const nav=$('#nav');nav.innerHTML='';
  TABS.forEach(([id,ic,label],i)=>{const b=el('button',i===0?'active':'',`<span class="ic">${ic}</span>${label}`);
    b.onclick=()=>{$$('.nav button').forEach(x=>x.classList.remove('active'));b.classList.add('active');current=id;render();};nav.appendChild(b);});}
function render(){const m=$('#main');m.innerHTML='';
  ({radar:pRadar,exec:pExec,graph:pGraph,contagion:pCont,controls:pCtrl,regs:pRegs,impact:pImpact}[current])(m);}
function head(m,eyebrow,title,lede,helpKey){
  m.appendChild(el('div','pg',`<div class="eyebrow">${eyebrow}</div>
    <div class="pg-title"><h1>${title}</h1>${helpKey?helpBtn(helpKey):''}</div><p>${lede}</p>`));
}

// ================= ALERT RADAR =================
function pRadar(m){
  const k=DATA.kpi;
  head(m,'Early-warning queue','Alert Radar',
    'Every signal scored and ranked so you act on what matters first. Leading signals surface <b>before</b> rules land — that spread is your lead time.','radar');
  m.insertAdjacentHTML('beforeend',`<div class="kpis">
    <div class="kpi hot"><div class="lab">Leading signals</div><div class="val">${num(k.leading)}</div>
      <div class="sub">${k.leading_pct}% of ${num(k.total)} — early warning</div><div class="spark">◗</div></div>
    <div class="kpi"><div class="lab">Near-term horizon</div><div class="val">${num(k.near)}</div><div class="sub">Immediate / near-term action</div></div>
    <div class="kpi"><div class="lab">Emerging themes</div><div class="val">${num(k.emerging)}</div><div class="sub">Beyond the core taxonomy</div></div>
    <div class="kpi"><div class="lab">Contagion watch</div><div class="val">${num(k.contagion)}</div><div class="sub">Likely to spread markets</div></div></div>`);
  const g=el('div','grid g2');
  const left=el('div','panel');
  left.innerHTML=`<div class="ph"><div><h3>Priority queue</h3><small>ranked by priority score · click any alert for the brief</small></div></div>
    <div class="toggles">
      <div class="tgroup" id="tg-sig"><span class="tglab">Signal</span>
        <button class="tg active" data-sig="all">All</button><button class="tg" data-sig="Leading">Leading</button>
        <button class="tg" data-sig="Coincident">Coincident</button><button class="tg" data-sig="Lagging">Lagging</button></div>
      <div class="tgroup" id="tg-hz"><span class="tglab">Horizon</span>
        <button class="tg active" data-hz="all">All</button><button class="tg" data-hz="Immediate">Immediate</button>
        <button class="tg" data-hz="Near-Term">Near-Term</button><button class="tg" data-hz="Medium-Term">Medium</button><button class="tg" data-hz="Long-Term">Long</button></div>
    </div>
    <div class="filters2">
      <select id="fJur"><option value="">All jurisdictions</option></select>
      <select id="fReg"><option value="">All regulators</option></select>
    </div>
    <div id="queue"></div>`;
  const right=el('div','panel');
  right.innerHTML=`<div class="ph"><div><h3>Signal mix by source</h3><small>news breaks first, enforcement lags</small></div></div>
    <canvas id="mixChart" height="200"></canvas>
    <div class="mix-note">The gap between <b style="color:${C.lead}">leading</b> news and <b style="color:${C.lag}">lagging</b> enforcement is your early-warning window.</div>`;
  g.appendChild(left);g.appendChild(right);m.appendChild(g);
  // populate filters
  const jurs=[...new Set(DATA.radar.map(r=>r.JURISDICTION).filter(Boolean))].sort();
  const regs=[...new Set(DATA.radar.map(r=>r.REGULATOR).filter(Boolean))].sort();
  jurs.forEach(j=>$('#fJur',left).appendChild(el('option',null,esc(j))));
  regs.forEach(r=>$('#fReg',left).appendChild(el('option',null,esc(r))));
  const state={sig:'all',hz:'all',jur:'',reg:''};
  function draw(){
    const q=$('#queue',left);q.innerHTML='';
    let rows=DATA.radar.filter(r=>
      (state.sig==='all'||r.signal_type===state.sig)&&
      (state.hz==='all'||r.expected_action_horizon===state.hz)&&
      (!state.jur||r.JURISDICTION===state.jur)&&(!state.reg||r.REGULATOR===state.reg));
    if(!rows.length){q.innerHTML='<div class="empty">No alerts match these filters.</div>';return;}
    rows.slice(0,30).forEach(r=>{
      const em=r.is_emerging?` <span class="emerging">NEW</span>`:'';
      const bd=r.breakdown||{};
      const row=el('div','qrow');
      row.innerHTML=`<div class="qhead">${pri(r.priority_score)}
        <div class="qmid"><div class="qt">${esc(String(r.primary_theme).split(',')[0])}${em}</div>
        <div class="qs"><span class="pill">${esc(r.Message_ID)}</span> · ${esc(r.JURISDICTION||'—')} · ${esc(r.REGULATOR||'—')}</div></div>
        ${sig(r.signal_type)}<span class="qcaret">▾</span></div>
        <div class="qbody"><div class="inner">
          <div class="brief">
            <div class="brief-block"><div class="brief-h">📍 What happened</div><div>${esc(r.so_what_summary||'—')}</div></div>
            <div class="brief-block do"><div class="brief-h">✅ Recommended action</div><div>${esc(r.recommended_action||'Review with the risk steward.')}</div></div>
          </div>
          <div class="meta">
            <div class="meta-row"><span>Signal</span>${sig(r.signal_type)}</div>
            <div class="meta-row"><span>Urgency</span><b>${esc(r.urgency||'—')}</b></div>
            <div class="meta-row"><span>Horizon</span><b>${esc(r.expected_action_horizon||'—')}</b></div>
            <div class="meta-row"><span>Direction</span><b>${esc(r.regulatory_direction||'—')}</b></div>
            <div class="score-explain"><div class="se-h">Why score ${Math.round(r.priority_score)}?</div>
              ${bar('Signal',bd.signal,40)}${bar('Urgency',bd.urgency,25)}${bar('Impact',bd.impact,20)}${bar('Novelty',bd.novelty,15)}
              <div class="se-conf">× ${bd.confidence||90}% confidence</div></div>
          </div>
        </div></div>`;
      row.querySelector('.qhead').onclick=()=>row.classList.toggle('open');
      q.appendChild(row);
    });
  }
  function bar(lab,val,max){const pct=Math.min(100,(val||0)/max*100);
    return `<div class="se-bar"><span>${lab}</span><div class="se-track"><div class="se-fill" style="width:${pct}%"></div></div><i>${val||0}</i></div>`;}
  left.querySelectorAll('#tg-sig .tg').forEach(b=>b.onclick=()=>{left.querySelectorAll('#tg-sig .tg').forEach(x=>x.classList.remove('active'));b.classList.add('active');state.sig=b.dataset.sig;draw();});
  left.querySelectorAll('#tg-hz .tg').forEach(b=>b.onclick=()=>{left.querySelectorAll('#tg-hz .tg').forEach(x=>x.classList.remove('active'));b.classList.add('active');state.hz=b.dataset.hz;draw();});
  $('#fJur',left).onchange=e=>{state.jur=e.target.value;draw();};
  $('#fReg',left).onchange=e=>{state.reg=e.target.value;draw();};
  draw();
  // premium chart
  const rc=DATA.rc;
  const grad=(ctx,base)=>{const g=ctx.createLinearGradient(0,0,0,220);g.addColorStop(0,base);g.addColorStop(1,base+'55');return g;};
  const cx=$('#mixChart').getContext('2d');
  new Chart(cx,{type:'bar',data:{labels:rc.map(x=>x.record_cat_code),
    datasets:[{label:'Leading',data:rc.map(x=>x.leading_signals),backgroundColor:grad(cx,C.lead),borderRadius:6,stack:'s'},
    {label:'Coincident',data:rc.map(x=>x.coincident_signals),backgroundColor:grad(cx,C.coin),borderRadius:6,stack:'s'},
    {label:'Lagging',data:rc.map(x=>x.lagging_signals),backgroundColor:grad(cx,C.lag),borderRadius:6,stack:'s'}]},
    options:{plugins:{legend:{position:'bottom',labels:{usePointStyle:true,pointStyle:'circle',padding:16,font:{family:'Inter'}}}},
      scales:{x:{stacked:true,grid:{display:false},ticks:{font:{family:'Inter'}}},y:{stacked:true,grid:{color:'#eef0f3'},ticks:{font:{family:'Inter'}}}}}});
}

// ================= EXECUTIVE SUMMARY =================
function pExec(m){
  head(m,'Board-level heatmap','Theme × feature risk matrix',
    'Themes ordered most→least severe (left→right), colour graded red→yellow. Every cell is computed live from the data.','exec');
  // order themes by severity rank (HIGH>MED>LOW then record count)
  const rank={HIGH:0,MEDIUM:1,LOW:2};
  const M=[...DATA.matrix].sort((a,b)=>(rank[a.Severity]-rank[b.Severity])||(b.records-a.records));
  const feats=["Severity","Theme Velocity","X-Jurisdiction Overlap","News-RegDev Corr","Enforcement Corr"];
  const n=M.length,cols=`grid-template-columns:210px repeat(${n},minmax(148px,1fr))`;
  const wrap=el('div','matrix');const grid=el('div','mgrid');
  const hd=el('div','mhead');hd.style.cssText=cols;
  hd.appendChild(el('div','corner','Features'));
  M.forEach((r,i)=>{const c=el('div','thcard',r.theme);
    const col=RAMP[Math.min(i,RAMP.length-1)];
    c.style.background=`linear-gradient(135deg,${col},${col}dd)`;
    c.onclick=()=>openTheme(r.full||r.theme);hd.appendChild(c);});
  grid.appendChild(hd);
  feats.forEach(f=>{const row=el('div','mrow');row.style.cssText=cols;
    row.appendChild(el('div','mrlab',`<b>${f}</b>`));
    M.forEach(r=>{const v=r[f]||'MEDIUM';
      row.appendChild(el('div','mcell',`<div class="badge"><span class="dot ${v==='HIGH'?'d-Lagging':v==='MEDIUM'?'d-Coincident':'d-Leading'}"></span><span class="sev-${v}" style="padding:0;background:none">${v}</span></div>`));});
    grid.appendChild(row);});
  const vd=el('div','mvd');vd.style.cssText=cols;vd.appendChild(el('div',''));
  M.forEach(r=>{const b=el('button','vdbtn','View Details →');b.onclick=()=>openTheme(r.full||r.theme);vd.appendChild(b);});
  grid.appendChild(vd);wrap.appendChild(grid);m.appendChild(wrap);
}

// ================= RISK NETWORK (KG + timeline merged, growing) =================
function pGraph(m){
  head(m,'Living risk map','Risk Network over time',
    'Watch the regulatory web build up quarter by quarter. Drag the slider or press Play — each step adds that period\'s new activity.','graph');
  const tg=DATA.tgraph;
  if(!tg.periods||!tg.periods.length){
    m.insertAdjacentHTML('beforeend','<div class="panel">Timeline needs dated records (REC_START_DT) to animate the network.</div>');return;}
  const box=el('div','viz');
  box.innerHTML=`<div class="slider-bar">
      <button class="play" id="playBtn">▶ Play</button>
      <input type="range" id="tSlider" min="0" max="${tg.periods.length-1}" value="${tg.periods.length-1}" step="1">
      <div class="slider-lab"><b id="sPeriod">${tg.periods[tg.periods.length-1]}</b> · <span id="sCount"></span></div>
    </div><div id="rnet"></div>`;
  m.appendChild(box);
  let sim=null;
  function frameAt(i){
    const p=tg.periods[i],fr=tg.frames[p];
    $('#sPeriod',box).textContent=p;$('#sCount',box).textContent=fr.count+' records';
    drawNet($('#rnet',box),fr,s=>sim=s);
  }
  requestAnimationFrame(()=>frameAt(tg.periods.length-1));
  $('#tSlider',box).oninput=e=>frameAt(+e.target.value);
  let playing=false,timer=null;
  $('#playBtn',box).onclick=()=>{
    const btn=$('#playBtn',box);
    if(playing){clearInterval(timer);playing=false;btn.textContent='▶ Play';return;}
    playing=true;btn.textContent='⏸ Pause';let i=0;$('#tSlider',box).value=0;frameAt(0);
    timer=setInterval(()=>{i++;if(i>=tg.periods.length){clearInterval(timer);playing=false;btn.textContent='▶ Play';return;}
      $('#tSlider',box).value=i;frameAt(i);},1100);
  };
}
let _netState={};
function drawNet(node,fr,onSim){
  const W=wOf(node),H=560;
  const color={theme:C.red,jurisdiction:'#2D6BE0',regulator:C.coin};
  d3.select(node).selectAll('*').remove();
  const svg=d3.select(node).append('svg').attr('width',W).attr('height',H);
  // preserve positions across frames for smooth growth
  const nodes=fr.nodes.map(n=>({...n,x:_netState[n.id]?.x,y:_netState[n.id]?.y}));
  const links=fr.links.map(l=>({...l}));
  const sim=d3.forceSimulation(nodes)
    .force('link',d3.forceLink(links).id(d=>d.id).distance(80))
    .force('charge',d3.forceManyBody().strength(-190))
    .force('center',d3.forceCenter(W/2,H/2)).force('collide',d3.forceCollide(20));
  const link=svg.append('g').selectAll('line').data(links).join('line').attr('stroke',C.line).attr('stroke-width',d=>Math.sqrt(d.value||1)*1.3);
  const nd=svg.append('g').selectAll('circle').data(nodes).join('circle')
    .attr('r',d=>d.type==='theme'?12:7).attr('fill',d=>color[d.type]).attr('stroke','#fff').attr('stroke-width',2).style('cursor','grab')
    .call(d3.drag().on('start',(e,d)=>{if(!e.active)sim.alphaTarget(.3).restart();d.fx=d.x;d.fy=d.y})
      .on('drag',(e,d)=>{d.fx=e.x;d.fy=e.y}).on('end',(e,d)=>{if(!e.active)sim.alphaTarget(0);d.fx=null;d.fy=null}))
    .on('mousemove',(e,d)=>showTT(`<b>${esc(d.id)}</b><br>${d.type}`,e)).on('mouseout',hideTT);
  nd.append('title').text(d=>d.id);
  const lab=svg.append('g').selectAll('text').data(nodes.filter(n=>n.type==='theme')).join('text')
    .text(d=>d.id).style('font-size','10.5px').style('font-weight','600').style('font-family','Inter').attr('dx',14).attr('dy',4);
  const lg=svg.append('g').attr('transform','translate(18,18)');
  [['Theme',C.red],['Jurisdiction','#2D6BE0'],['Regulator',C.coin]].forEach((d,i)=>{
    lg.append('circle').attr('cx',6).attr('cy',i*21+6).attr('r',6).attr('fill',d[1]);
    lg.append('text').attr('x',18).attr('y',i*21+10).text(d[0]).style('font-size','11px').style('fill',C.muted).style('font-family','Inter');});
  sim.on('tick',()=>{
    link.attr('x1',d=>d.source.x).attr('y1',d=>d.source.y).attr('x2',d=>d.target.x).attr('y2',d=>d.target.y);
    nd.attr('cx',d=>d.x).attr('cy',d=>d.y);lab.attr('x',d=>d.x).attr('y',d=>d.y);
    nodes.forEach(n=>_netState[n.id]={x:n.x,y:n.y});
  });
  onSim&&onSim(sim);
}

// ================= CROSS-JURISDICTION =================
function pCont(m){
  head(m,'How regulation spreads','Which markets move first — and who follows',
    'Watching markets that move first buys you lead time before the same rule reaches follower markets.','contagion');
  const g=el('div','grid g2b');
  const l=el('div','panel');l.innerHTML='<div class="ph"><div><h3>Most proactive markets</h3><small>leading-signal ratio — higher = moves first</small></div></div><div id="lead"></div>';
  const r=el('div','panel');r.innerHTML='<div class="ph"><div><h3>Contagion flows</h3><small>origin ▸ likely follower · hover to trace</small></div></div><div class="scroll" id="flows" style="max-height:520px"></div>';
  g.appendChild(l);g.appendChild(r);m.appendChild(g);
  const jm=DATA.jm.filter(j=>j.record_count>=3).sort((a,b)=>(b.leading_ratio||0)-(a.leading_ratio||0)).slice(0,12);
  const mx=Math.max(...jm.map(j=>j.leading_ratio||0),.01);
  const ld=$('#lead',l);
  jm.forEach((j,i)=>{const row=el('div','lead-row');
    row.innerHTML=`<div class="lead-rank">${i+1}</div><div class="lead-name">${esc(j.jurisdiction)}</div>
    <div class="lead-track"><div class="lead-fill" style="width:0%"></div></div><b class="lead-val">${(j.leading_ratio||0).toFixed(2)}</b>`;
    ld.appendChild(row);
    setTimeout(()=>row.querySelector('.lead-fill').style.width=(j.leading_ratio/mx*100).toFixed(0)+'%',60+i*50);});
  const fl=$('#flows',r);
  if(!DATA.edges.length){fl.innerHTML='<div class="empty">No follower-jurisdiction tags in this dataset.</div>';return;}
  DATA.edges.forEach(e=>{const row=el('div','flow-row');
    row.innerHTML=`<span class="node-o">${esc(e.source)}</span><span class="flow-arrow"><span class="flow-dot"></span></span><span class="node-f">${esc(e.target)}</span><b class="flow-w">×${e.weight}</b>`;
    fl.appendChild(row);});
}

// ================= CONTROLS & GAPS =================
function pCtrl(m){
  const k=DATA.kpi;
  head(m,'Signal → action','Controls & Gaps',
    'Each signal is mapped to the internal controls it affects, with probable gaps and a recommended fix. This is where regulatory noise becomes an actionable work list.','controls');
  m.insertAdjacentHTML('beforeend',`<div class="kpis">
    <div class="kpi"><div class="lab">Controls mapped</div><div class="val">${num(k.controls)}</div><div class="sub">across all signals</div></div>
    <div class="kpi"><div class="lab">Probable gaps</div><div class="val">${num(k.gaps)}</div><div class="sub">each with a recommendation</div></div>
    <div class="kpi hot"><div class="lab">High-severity gaps</div><div class="val">${num(k.hi_gaps)}</div><div class="sub">priority remediation</div><div class="spark">!</div></div>
    <div class="kpi"><div class="lab">Jurisdictions</div><div class="val">${num(k.jurisdictions)}</div><div class="sub">in scope</div></div></div>`);
  const p=el('div','panel');
  p.innerHTML=`<div class="filters2 wide">
      <input id="cq" placeholder="Search control, obligation or record…">
      <select id="cth"><option value="">All themes</option></select>
      <select id="csv"><option value="">All gap severities</option><option>High</option><option>Medium</option><option>Low</option></select></div>
    <div class="caption" id="ccount"></div>
    <div class="scroll"><table><thead><tr><th>Control</th><th>Steward</th><th>Theme</th><th>Type</th><th>Effectiveness</th><th>Worst gap</th></tr></thead><tbody id="cbody"></tbody></table></div>`;
  m.appendChild(p);
  const themes=[...new Set(DATA.controls.map(c=>c.primary_theme).filter(Boolean))].sort();
  themes.forEach(t=>$('#cth',p).appendChild(el('option',null,esc(t))));
  const gapBy={};DATA.gaps.forEach(g=>{(gapBy[g.control_id]=gapBy[g.control_id]||[]).push(g);});
  function draw(){const q=($('#cq',p).value||'').toLowerCase(),th=$('#cth',p).value,sv=$('#csv',p).value;
    const tb=$('#cbody',p);tb.innerHTML='';let shown=0;
    DATA.controls.filter(c=>{
      if(th&&c.primary_theme!==th)return false;
      if(sv&&!(gapBy[c.control_id]||[]).some(g=>g.gap_severity===sv))return false;
      if(q&&!`${c.control_id} ${c.control_title} ${c.obligation_addressed} ${c.Message_ID}`.toLowerCase().includes(q))return false;
      return true;}).slice(0,120).forEach(c=>{shown++;
      const gaps=gapBy[c.control_id]||[];
      const worst=gaps.some(g=>g.gap_severity==='High')?'High':gaps.some(g=>g.gap_severity==='Medium')?'Medium':gaps.length?'Low':null;
      const tr=el('tr');tr.innerHTML=`<td><span class="pill">${esc(c.control_id)}</span><div style="font-weight:600;margin-top:3px">${esc(c.control_title)}</div></td>
        <td>${esc(c.risk_steward_name)}</td><td style="color:var(--muted)">${esc(String(c.primary_theme||'').split(',')[0])}</td>
        <td>${esc(c.control_type||'—')}</td><td>${esc(c.control_effectiveness||'—')}</td>
        <td>${worst?sev(worst):'—'} <small style="color:var(--muted)">${gaps.length} gap${gaps.length!==1?'s':''}</small></td>`;
      tb.appendChild(tr);});
    $('#ccount',p).textContent=`${shown} control${shown!==1?'s':''} shown`;}
  $('#cq',p).oninput=draw;$('#cth',p).onchange=draw;$('#csv',p).onchange=draw;draw();
}

// ================= REGULATORS =================
function pRegs(m){
  head(m,'Who drives the agenda','Regulators & source validation',
    'Which regulators to watch, and proof the signal-timing engine is grounded in reality.','regs');
  const g=el('div','grid g2');
  const l=el('div','panel');l.innerHTML='<div class="ph"><div><h3>Regulator league table</h3></div></div><div class="scroll"><table><thead><tr><th>Regulator</th><th>Records</th><th>Juris.</th><th>Leading</th><th>Conf.</th></tr></thead><tbody id="rb"></tbody></table></div>';
  const r=el('div','panel');r.innerHTML='<div class="ph"><div><h3>Source-category validation</h3><small>news skews leading · enforcement lags</small></div></div><div id="scv"></div>';
  g.appendChild(l);g.appendChild(r);m.appendChild(g);
  const rb=$('#rb',l);
  DATA.rm.forEach(x=>{const tr=el('tr');tr.innerHTML=`<td style="font-weight:600">${esc(x.regulator)}</td><td>${num(x.record_count)}</td>
    <td style="color:var(--muted)">${num(x.jurisdiction_count)}</td><td><span class="chip sig-Leading">${num(x.leading_signals)}</span></td>
    <td>${x.avg_confidence!=null?Number(x.avg_confidence).toFixed(2):'—'}</td>`;rb.appendChild(tr);});
  const scv=$('#scv',r);
  DATA.rc.forEach(x=>{const tot=Math.max(x.record_count||1,1),ld=x.leading_signals||0,lg=x.lagging_signals||0;
    scv.insertAdjacentHTML('beforeend',`<div class="scv-row"><div class="scv-lab"><b>${esc(x.record_cat_code)}</b> <span>${esc(x.description||'')}</span></div>
    <div class="scv-bar"><div style="width:${100*ld/tot}%;background:${C.lead}"></div><div style="width:${100*(tot-ld-lg)/tot}%;background:${C.coin}"></div><div style="width:${100*lg/tot}%;background:${C.lag}"></div></div></div>`);});
}

// ================= IMPACT & ONTOLOGY =================
function pImpact(m){
  head(m,'Exposure & structure','Impact & Ontology',
    'Two lenses: trace a theme\'s cascade (impact ripple), or drill the structured knowledge hierarchy (ontology).','impact');
  const tabs=el('div','sub-tabs');
  tabs.innerHTML=`<button class="stab active" data-p="imp-ripple">🌊 Impact ripple</button><button class="stab" data-p="imp-onto">🧬 Ontology tree</button>`;
  m.appendChild(tabs);
  const ripple=el('div','sub-pane active');ripple.id='imp-ripple';
  const themes=Object.keys(DATA.impact);
  ripple.innerHTML=`<div class="panel"><div class="ph"><div><h3>Pick a theme to trace its cascade</h3><small>records → controls → gaps → who's affected → who follows</small></div>
    <select id="impTheme">${themes.map(t=>`<option value="${esc(t)}">${esc(String(t).split(',')[0])}</option>`).join('')}</select></div>
    <div id="rippleView"></div></div>`;
  m.appendChild(ripple);
  const onto=el('div','sub-pane');onto.id='imp-onto';
  onto.innerHTML=`<div class="panel"><div class="ph"><div><h3>Ontology — Theme → Steward → Control → Gap</h3><small>click to expand each layer</small></div></div><div id="ontoTree"></div></div>`;
  m.appendChild(onto);
  tabs.querySelectorAll('.stab').forEach(b=>b.onclick=()=>{
    tabs.querySelectorAll('.stab').forEach(x=>x.classList.remove('active'));
    m.querySelectorAll('.sub-pane').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');$('#'+b.dataset.p).classList.add('active');
    if(b.dataset.p==='imp-onto'&&!$('#ontoTree').dataset.built){$('#ontoTree').dataset.built=1;buildOnto();}
  });
  function drawRipple(theme){
    const d=DATA.impact[theme];const v=$('#rippleView');
    v.innerHTML=`<div class="ripple">
      <div class="rp-stage"><div class="rp-node rp-theme">${esc(String(theme).split(',')[0])}<small>${d.records} records</small></div></div>
      <div class="rp-arrow">→</div>
      <div class="rp-stage"><div class="rp-node rp-ctrl">${d.controls}<small>controls hit</small></div></div>
      <div class="rp-arrow">→</div>
      <div class="rp-stage"><div class="rp-node rp-gap hi">${d.hi_gaps}<small>high gaps</small></div><div class="rp-node rp-gap med">${d.med_gaps}<small>med gaps</small></div></div>
      <div class="rp-arrow">→</div>
      <div class="rp-stage"><div class="rp-node rp-jur">${d.jurisdictions}<small>jurisdictions</small></div></div>
    </div>
    <div class="ripple-detail">
      <div class="rd-col"><h4>👤 Risk stewards owning this</h4>${d.stewards.length?d.stewards.map(s=>`<span class="tag">${esc(s)}</span>`).join(''):'<span class="muted">none mapped</span>'}</div>
      <div class="rd-col"><h4>🏢 Business lines affected</h4>${d.business_lines.length?d.business_lines.map(b=>`<span class="tag">${esc(b)}</span>`).join(''):'<span class="muted">—</span>'}</div>
      <div class="rd-col"><h4>🌐 Likely to follow next</h4>${d.followers.length?d.followers.map(([f,w])=>`<span class="tag">${esc(f)} <i>×${w}</i></span>`).join(''):'<span class="muted">—</span>'}</div>
    </div>`;
  }
  $('#impTheme',ripple).onchange=e=>drawRipple(e.target.value);
  drawRipple(themes[0]);
  function buildOnto(){
    const tree=$('#ontoTree');
    DATA.ontology.forEach(t=>{
      const node=el('div','onto-theme');
      node.innerHTML=`<div class="onto-h theme"><span class="tw">▸</span> ${esc(t.theme)} <small>${t.count} controls · ${t.stewards.length} stewards</small></div><div class="onto-kids"></div>`;
      const kids=node.querySelector('.onto-kids');
      t.stewards.forEach(s=>{
        const sn=el('div','onto-steward');
        sn.innerHTML=`<div class="onto-h steward"><span class="tw">▸</span> 👤 ${esc(s.steward)} <small>${s.count}</small></div><div class="onto-kids"></div>`;
        const ck=sn.querySelector('.onto-kids');
        s.controls.forEach(c=>{
          const cn=el('div','onto-ctrl');
          const gaps=c.gaps.map(g=>`<div class="onto-gap">${sev(g.sev)} ${esc(g.desc)}</div>`).join('')||'<div class="onto-gap muted">no gaps</div>';
          cn.innerHTML=`<div class="onto-h ctrl"><span class="tw">▸</span> <span class="pill">${esc(c.id)}</span> ${esc(c.title)} <small>${esc(c.eff)}</small></div><div class="onto-kids">${gaps}</div>`;
          cn.querySelector('.onto-h').onclick=e=>{e.stopPropagation();cn.classList.toggle('open');};
          ck.appendChild(cn);
        });
        sn.querySelector('.onto-h').onclick=e=>{e.stopPropagation();sn.classList.toggle('open');};
        kids.appendChild(sn);
      });
      node.querySelector('.onto-h').onclick=()=>node.classList.toggle('open');
      tree.appendChild(node);
    });
  }
}

// ================= THEME DRAWER (View Details) =================
function openTheme(theme){
  const t=DATA.themes[theme];if(!t)return;
  const short=String(theme).split(',')[0];
  // recommendations: cleaner, grouped, explained
  const recsHtml=(t.recs||[]).length?(t.recs||[]).map(g=>`<div class="rec-card">
    <div class="rec-head"><span class="pill">${esc(g.control_id)}</span> <b>${esc(g.title)}</b></div>
    <ul class="rec-list">${g.items.map(i=>`<li>${sevDot(i.sev)} ${esc(i.text)}</li>`).join('')}</ul></div>`).join(''):'<p class="muted">No recommendations for this theme.</p>';
  const gapHtml=(t.gap_controls||[]).length?(t.gap_controls||[]).map((c,i)=>`<div class="gap-ctrl" data-i="${i}">
    <div class="gc-head"><span class="tw">▸</span><span class="pill">${esc(c.control_id)}</span> <b>${esc(c.title)}</b>
      <span class="gc-meta">${esc(c.steward)} · ${esc(c.eff)}</span></div>
    <div class="gc-body"><div class="gc-obl"><b>Obligation:</b> ${esc(c.obligation||'—')}</div>
      ${c.gaps.length?c.gaps.map(x=>`<div class="gc-gap">${sev(x.sev)}<div><div class="gg-desc">${esc(x.gap)}</div><div class="gg-rec"><b>→ Fix:</b> ${esc(x.rec)}</div></div></div>`).join(''):'<div class="muted">No gaps recorded.</div>'}</div></div>`).join(''):'<p class="muted">No controls mapped.</p>';
  $('#drawerBody').innerHTML=`
    <div class="dhead"><button class="dclose" onclick="closeDrawer()">×</button>
      <div class="de">Theme workspace</div><h2>${esc(short)}</h2>
      <div class="dhead-kpis">
        <span title="Open-source news signals">📰 ${num(t.news)} news</span>
        <span title="Regulatory developments (rules/guidance)">📋 ${num(t.regdev)} rules</span>
        <span title="Controls mapped to this theme">🛡 ${num(t.controls)} controls</span>
        <span title="High-severity gaps needing priority fixes">⚠️ ${num(t.hi_gaps)} high gaps</span></div></div>
    <div class="dbody">
      <div class="dtabs">
        <button class="dtab active" data-p="d-mind">🧠 Mind-Map</button>
        <button class="dtab" data-p="d-rec">📋 Recommendations</button>
        <button class="dtab" data-p="d-gap">🧭 Gap Assessment</button></div>
      <div class="dpane active" id="d-mind"><div class="viz big"><div class="vhead"><h3>${esc(short)} — sub-topics</h3><p>scroll to zoom · drag to pan · drag nodes to rearrange</p></div><div id="dmm"></div></div></div>
      <div class="dpane" id="d-rec"><div class="rec-intro">Grouped by control. Each <span class="pill">1C-…</span> is the specific internal control the recommendation applies to — the same ID is used across alerts and remediation tracking so work can be traced end-to-end.</div>${recsHtml}</div>
      <div class="dpane" id="d-gap"><div class="gap-layout">
        <div class="gap-reg"><h3>📄 Regulation content</h3><div class="reg-text">${esc(t.reg_content||'—')}</div></div>
        <div class="gap-ctrls"><h3>🧭 Impacted controls <small>click a control to expand its gaps</small></h3>${gapHtml}</div>
      </div></div>
    </div>`;
  $('#drawerBody').querySelectorAll('.dtab').forEach(b=>b.onclick=()=>{
    $('#drawerBody').querySelectorAll('.dtab').forEach(x=>x.classList.remove('active'));
    $('#drawerBody').querySelectorAll('.dpane').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');$('#'+b.dataset.p).classList.add('active');});
  // expandable gap controls
  $('#drawerBody').querySelectorAll('.gap-ctrl .gc-head').forEach(h=>h.onclick=()=>h.parentElement.classList.toggle('open'));
  $('#drawer').classList.add('open');$('#scrim').classList.add('show');
  setTimeout(()=>drawMindZoom($('#dmm'),short,t),140);
}
function sevDot(s){const c=s==='High'?C.lag:s==='Medium'?C.coin:C.lead;return `<span class="dot" style="background:${c};display:inline-block"></span>`;}
function closeDrawer(){$('#drawer').classList.remove('open');$('#scrim').classList.remove('show');}
window.closeDrawer=closeDrawer;
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeDrawer();closeHelp();}});

// bigger, zoomable, 2-layer mind-map for the drawer
function drawMindZoom(node,short,t){
  const W=wOf(node,820),H=520;
  d3.select(node).selectAll('*').remove();
  const svg=d3.select(node).append('svg').attr('width',W).attr('height',H);
  const g=svg.append('g');
  svg.call(d3.zoom().scaleExtent([0.4,3]).on('zoom',e=>g.attr('transform',e.transform)));
  // 2 layers: theme -> subtopics -> (jurisdiction leaves for depth)
  const kids=(t.mindmap||[]).slice(0,8).map(s=>({name:s.name,value:s.value,
    children:(t.kg_nodes||[]).filter(n=>n.type==='jurisdiction').slice(0,3).map(n=>({name:n.id,leaf:true}))}));
  const data={name:short,children:kids};
  const root=d3.hierarchy(data);
  const tree=d3.tree().size([H-60,W-260]);tree(root);
  g.attr('transform','translate(120,30)');
  g.selectAll('path').data(root.links()).join('path').attr('fill','none').attr('stroke',C.line).attr('stroke-width',1.5)
    .attr('d',d3.linkHorizontal().x(d=>d.y).y(d=>d.x));
  const nd=g.selectAll('g').data(root.descendants()).join('g').attr('transform',d=>`translate(${d.y},${d.x})`);
  nd.append('circle').attr('r',d=>d.depth===0?11:d.depth===1?7:4)
    .attr('fill',d=>d.depth===0?C.ink:d.depth===1?C.red:'#2D6BE0').style('cursor','pointer')
    .on('mousemove',(e,d)=>d.data.value&&showTT(`<b>${esc(d.data.name)}</b><br>${d.data.value} items`,e)).on('mouseout',hideTT);
  nd.append('text').attr('dy',4).attr('x',d=>d.children?-13:13).style('text-anchor',d=>d.children?'end':'start')
    .style('font-size',d=>d.depth===2?'10px':'12px').style('font-weight',d=>d.depth===0?'700':'500').style('font-family','Inter')
    .style('fill',d=>d.depth===2?C.muted:C.ink).text(d=>d.data.name);
}
