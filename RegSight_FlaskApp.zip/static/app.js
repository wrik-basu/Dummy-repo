// ============ HSBC RegSight — v3 enhanced ============
let DATA, C;
let PREFS={hidden:[],accent:null};
function initApp(data){ DATA=data; C=DATA.colors;
  try{const p=JSON.parse(localStorage.getItem('regsight_prefs'));if(p)PREFS=p;}catch(e){}
  if(PREFS.accent)document.documentElement.style.setProperty('--red',PREFS.accent);
  buildNav(); render(); }
window.initApp=initApp;
function savePrefs(){try{localStorage.setItem('regsight_prefs',JSON.stringify(PREFS));}catch(e){}}

const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>[...r.querySelectorAll(s)];
const el=(t,c,h)=>{const e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e;};
const esc=s=>(s==null?'':String(s)).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const num=n=>(n==null||isNaN(n))?'—':Number(n).toLocaleString();
const sig=s=>`<span class="chip sig-${esc(s)}"><span class="dot d-${esc(s)}"></span>${esc(s)}</span>`;
const sev=s=>`<span class="chip sev-${esc(s)}">${esc(s)}</span>`;
const RAMP=['#C1121F','#E63329','#F26522','#F59E1B','#F7C948','#FBE27A'];
const sevColor=v=>({HIGH:'#C1121F',MEDIUM:'#F59E1B',LOW:'#F7C948'}[v]||'#F59E1B');
function pri(v){const p=Math.max(0,Math.min(100,v||0));const c=p>=70?C.lag:p>=45?C.coin:C.lead;
  return `<div class="pri"><div class="bar"><div class="fill" style="width:${p}%;background:${c}"></div></div><b>${p.toFixed(0)}</b></div>`;}
const tt=$('#tt');
const showTT=(html,e)=>{tt.innerHTML=html;tt.style.opacity=1;tt.style.left=Math.min(e.clientX+14,innerWidth-320)+'px';tt.style.top=(e.clientY-10)+'px';};
const hideTT=()=>tt.style.opacity=0;
const wOf=(node,fb=980)=>{const w=node.getBoundingClientRect().width;return w>40?w:fb;};

const HELP={
 radar:{title:"Alert Radar — how to read it",body:`
   <p><b>What this page is:</b> your early-warning queue. Every signal is scored and ranked so you act on the most important first.</p>
   <h4>Priority score (0–100)</h4>
   <p>Transparent, auditable — no black box. <b>Signal ×40%</b> (Leading highest), <b>Urgency ×25%</b>, <b>Impact ×20%</b>, <b>Novelty ×15%</b>, all × model <b>confidence</b>. Every alert shows its own breakdown.</p>
   <h4>The (i) next to Urgency</h4>
   <p>Hover it to see <i>why</i> — a real deadline countdown if the record has a target date, otherwise a plain-English reason derived from horizon, signal and direction.</p>
   <p><span style="color:#0B7A57">●</span> Leading (before rules) · <span style="color:#C67A00">●</span> Coincident (the rule) · <span style="color:#B00020">●</span> Lagging (after — fines).</p>`},
 exec:{title:"Executive Summary — the risk matrix",body:`
   <p><b>What this is:</b> a board heatmap. Rows = risk dimensions, columns = themes (most→least severe, left→right), colour graded red→yellow.</p>
   <p><b>Click any cell</b> to see its exact numbers and why it's HIGH/MEDIUM/LOW.</p>
   <h4>Dimensions & cutoffs</h4>
   <ul><li><b>Severity</b> — mean priority. ≥65 HIGH · ≥45 MED</li>
   <li><b>Theme Velocity</b> — recent vs baseline activity. ≥2.5× HIGH · ≥1× MED</li>
   <li><b>X-Jurisdiction Overlap</b> — markets spanned. &gt;66% HIGH · 33–66% MED</li>
   <li><b>News→RegDev Corr</b> — does news precede rules. ≥.5 HIGH · ≥.2 MED</li>
   <li><b>Enforcement Corr</b> — share already fined. ≥15% HIGH · ≥5% MED</li></ul>`},
 graph:{title:"Risk Network — the story over time",body:`
   <p><b>What this is:</b> the regulatory landscape building up over time. Press <b>Play</b> (or drag the slider). Each quarter adds that period's new activity, and the <b>story panel</b> narrates what changed — which regulators started acting, which themes emerged, which markets it spread to.</p>
   <p>New nodes are highlighted as they arrive. Relationship labels (issues guidance on / active in) explain each edge. Drag nodes; hover for detail.</p>`},
 trends:{title:"Trends — activity over time",body:`
   <p><b>What this is:</b> a Google-Trends-style view. Pick an object type (theme, regulator, jurisdiction) and one or more values to compare their signal volume month by month.</p>
   <p>Use it to spot momentum: a line climbing fast is a topic gaining regulatory attention. Add several lines to compare, or split to see divergence.</p>`},
 contagion:{title:"Cross-Jurisdiction — how regulation spreads",body:`
   <p><b>The question:</b> "If a rule appears in market A, who copies it next?"</p>
   <p><b>Left:</b> markets ranked by leading-signal ratio — high means they move first, buying you lead time. <b>Right:</b> A ▸ B flows show themes in A historically reaching B afterwards. Pre-position controls in follower markets before the rule lands.</p>`},
 controls:{title:"Controls & Gaps — the response layer",body:`
   <p><b>What this is:</b> the bridge from signal to action. Each signal maps to the internal controls it affects; each control is assessed for <b>probable gaps</b> with a recommended fix. Click any control to open the gap → fix detail.</p>
   <p>Control IDs (<span class="pill">1C-…</span>) are stable identifiers so a control can be tracked across alerts and remediation.</p>`},
 regs:{title:"Regulators & Source Validation",body:`
   <p><b>Left:</b> which regulators drive activity and generate leading signals — who to monitor. <b>Right:</b> proof the engine is grounded — NEWS skews leading, enforcement skews lagging, exactly as the timing model predicts.</p>`},
 impact:{title:"Impact & Ontology",body:`
   <p><b>Impact ripple:</b> pick a theme, trace its cascade — records → controls → gaps → who's affected → who follows. <b>Ontology tree:</b> the structured hierarchy Theme → Steward → Control → Action, ordered by severity.</p>`},
 options:{title:"Options",body:`<p>Hide pages you don't need, reorder nothing (nav order is fixed), and change the accent colour. Preferences are saved in your browser.</p>`},
};
function helpBtn(key){return `<button class="help-btn" onclick="openHelp('${key}')" title="How to read this page">?</button>`;}
function openHelp(key){const h=HELP[key];if(!h)return;$('#helpBody').innerHTML=`<h2>${esc(h.title)}</h2>${h.body}`;$('#helpModal').classList.add('show');}
function closeHelp(){$('#helpModal').classList.remove('show');}
window.openHelp=openHelp;window.closeHelp=closeHelp;

const TABS=[['radar','🛰','Alert Radar'],['exec','🗂','Executive Summary'],['graph','🕸','Risk Network'],
['trends','📈','Trends'],['contagion','🌐','Cross-Jurisdiction'],['controls','🛡','Controls & Gaps'],
['regs','🏛','Regulators'],['impact','🧬','Impact & Ontology'],['options','⚙️','Options']];
let current='radar';
function buildNav(){const nav=$('#nav');nav.innerHTML='';
  TABS.forEach(([id,ic,label],i)=>{
    if(PREFS.hidden.includes(id)&&id!=='options')return;
    const b=el('button',id===current?'active':'',`<span class="ic">${ic}</span>${label}`);
    b.onclick=()=>{current=id;buildNav();render();};nav.appendChild(b);});}
function render(){const m=$('#main');m.innerHTML='';
  ({radar:pRadar,exec:pExec,graph:pGraph,trends:pTrends,contagion:pCont,controls:pCtrl,regs:pRegs,impact:pImpact,options:pOptions}[current])(m);}
function head(m,eyebrow,title,lede,helpKey){
  m.appendChild(el('div','pg',`<div class="eyebrow">${eyebrow}</div>
    <div class="pg-title"><h1>${title}</h1>${helpKey?helpBtn(helpKey):''}</div><p>${lede}</p>`));}

// ================= ALERT RADAR =================
function pRadar(m){
  const k=DATA.kpi;
  head(m,'Early-warning queue','Alert Radar',
    'Every signal scored and ranked so you act on what matters first. Leading signals surface <b>before</b> rules land — that spread is your lead time.','radar');
  m.insertAdjacentHTML('beforeend',`<div class="kpis">
    <div class="kpi hot"><div class="lab">Leading signals</div><div class="val">${num(k.leading)}</div><div class="sub">${k.leading_pct}% of ${num(k.total)} — early warning</div><div class="spark">◗</div></div>
    <div class="kpi"><div class="lab">Near-term horizon</div><div class="val">${num(k.near)}</div><div class="sub">Immediate / near-term action</div></div>
    <div class="kpi"><div class="lab">Emerging themes</div><div class="val">${num(k.emerging)}</div><div class="sub">Beyond the core taxonomy</div></div>
    <div class="kpi"><div class="lab">Contagion watch</div><div class="val">${num(k.contagion)}</div><div class="sub">Likely to spread markets</div></div></div>`);
  const g=el('div','grid g2');
  const left=el('div','panel');
  left.innerHTML=`<div class="ph"><div><h3>Priority queue</h3><small>ranked by priority score · click any alert for the brief</small></div></div>
    <div class="toggles">
      <div class="tgroup" id="tg-sig"><span class="tglab">Signal</span>
        <button class="tg active" data-sig="all">All</button><button class="tg" data-sig="Leading">Leading</button>
        <button class="tg" data-sig="Coincident">Coincident</button><button class="tg" data-sig="Lagging">Lagging</button></div>
      <div class="tgroup" id="tg-hz"><span class="tglab">Horizon</span>
        <button class="tg active" data-hz="all">All</button><button class="tg" data-hz="Immediate">Immediate</button>
        <button class="tg" data-hz="Near-Term">Near</button><button class="tg" data-hz="Medium-Term">Medium</button><button class="tg" data-hz="Long-Term">Long</button></div></div>
    <div class="filters2"><select id="fJur"><option value="">All jurisdictions</option></select><select id="fReg"><option value="">All regulators</option></select></div>
    <div id="queue"></div>`;
  const right=el('div','panel');
  right.innerHTML=`<div class="ph"><div><h3>Signal mix by source</h3><small>news breaks first, enforcement lags</small></div></div>
    <canvas id="mixChart" height="200"></canvas>
    <div class="mix-note">The gap between <b style="color:${C.lead}">leading</b> news and <b style="color:${C.lag}">lagging</b> enforcement is your early-warning window.</div>`;
  g.appendChild(left);g.appendChild(right);m.appendChild(g);
  const jurs=[...new Set(DATA.radar.map(r=>r.JURISDICTION).filter(Boolean))].sort();
  const regs=[...new Set(DATA.radar.map(r=>r.REGULATOR).filter(Boolean))].sort();
  jurs.forEach(j=>$('#fJur',left).appendChild(el('option',null,esc(j))));
  regs.forEach(r=>$('#fReg',left).appendChild(el('option',null,esc(r))));
  const state={sig:'all',hz:'all',jur:'',reg:''};
  function draw(){
    const q=$('#queue',left);q.innerHTML='';
    let rows=DATA.radar.filter(r=>(state.sig==='all'||r.signal_type===state.sig)&&(state.hz==='all'||r.expected_action_horizon===state.hz)&&(!state.jur||r.JURISDICTION===state.jur)&&(!state.reg||r.REGULATOR===state.reg));
    if(!rows.length){q.innerHTML='<div class="empty">No alerts match these filters.</div>';return;}
    rows.slice(0,30).forEach(r=>{
      const em=r.is_emerging?` <span class="emerging">NEW</span>`:'';const bd=r.breakdown||{};
      const ur=r.urgency_reason||{};const urIcon=ur.text?`<span class="i-info" data-ur="${esc(ur.text)}" data-basis="${esc(ur.basis||'')}">i</span>`:'';
      const row=el('div','qrow');
      row.innerHTML=`<div class="qhead">${pri(r.priority_score)}
        <div class="qmid"><div class="qt">${esc(String(r.primary_theme).split(',')[0])}${em}</div>
        <div class="qs"><span class="pill">${esc(r.Message_ID)}</span> · ${esc(r.JURISDICTION||'—')} · ${esc(r.REGULATOR||'—')}</div></div>
        ${sig(r.signal_type)}<span class="qcaret">▾</span></div>
        <div class="qbody"><div class="inner">
          <div class="brief">
            <div class="brief-block"><div class="brief-h">📍 What happened</div><div>${esc(r.so_what_summary||'—')}</div></div>
            <div class="brief-block do"><div class="brief-h">✅ Recommended action</div><div>${esc(r.recommended_action||'Review with the risk steward.')}</div></div>
          </div>
          <div class="meta">
            <div class="meta-row"><span>Signal</span>${sig(r.signal_type)}</div>
            <div class="meta-row"><span>Urgency</span><b>${esc(r.urgency||'—')} ${urIcon}</b></div>
            <div class="meta-row"><span>Horizon</span><b>${esc(r.expected_action_horizon||'—')}</b></div>
            <div class="meta-row"><span>Direction</span><b>${esc(r.regulatory_direction||'—')}</b></div>
            <div class="score-explain"><div class="se-h">Why score ${Math.round(r.priority_score)}?</div>
              ${bar('Signal',bd.signal,40)}${bar('Urgency',bd.urgency,25)}${bar('Impact',bd.impact,20)}${bar('Novelty',bd.novelty,15)}
              <div class="se-conf">× ${bd.confidence||90}% confidence</div></div>
          </div>
        </div></div>`;
      row.querySelector('.qhead').onclick=()=>row.classList.toggle('open');
      q.appendChild(row);
    });
    // wire info icons
    q.querySelectorAll('.i-info').forEach(ic=>{
      ic.onmouseenter=e=>{const basis=ic.dataset.basis==='deadline'?'⏱ Deadline-based':'≈ Derived';showTT(`<b>Why this urgency?</b><br>${esc(ic.dataset.ur)}<br><span style="color:${C.muted};font-size:11px">${basis}</span>`,e);};
      ic.onmousemove=e=>showTT(`<b>Why this urgency?</b><br>${esc(ic.dataset.ur)}<br><span style="color:${C.muted};font-size:11px">${ic.dataset.basis==='deadline'?'⏱ Deadline-based':'≈ Derived'}</span>`,e);
      ic.onmouseleave=hideTT;ic.onclick=e=>e.stopPropagation();});
  }
  function bar(lab,val,max){const pct=Math.min(100,(val||0)/max*100);
    return `<div class="se-bar"><span>${lab}</span><div class="se-track"><div class="se-fill" style="width:${pct}%"></div></div><i>${val||0}</i></div>`;}
  left.querySelectorAll('#tg-sig .tg').forEach(b=>b.onclick=()=>{left.querySelectorAll('#tg-sig .tg').forEach(x=>x.classList.remove('active'));b.classList.add('active');state.sig=b.dataset.sig;draw();});
  left.querySelectorAll('#tg-hz .tg').forEach(b=>b.onclick=()=>{left.querySelectorAll('#tg-hz .tg').forEach(x=>x.classList.remove('active'));b.classList.add('active');state.hz=b.dataset.hz;draw();});
  $('#fJur',left).onchange=e=>{state.jur=e.target.value;draw();};$('#fReg',left).onchange=e=>{state.reg=e.target.value;draw();};
  draw();
  const rc=DATA.rc;const cx=$('#mixChart').getContext('2d');
  const grad=(base)=>{const g=cx.createLinearGradient(0,0,0,220);g.addColorStop(0,base);g.addColorStop(1,base+'55');return g;};
  new Chart(cx,{type:'bar',data:{labels:rc.map(x=>x.record_cat_code),
    datasets:[{label:'Leading',data:rc.map(x=>x.leading_signals),backgroundColor:grad(C.lead),borderRadius:6,stack:'s'},
    {label:'Coincident',data:rc.map(x=>x.coincident_signals),backgroundColor:grad(C.coin),borderRadius:6,stack:'s'},
    {label:'Lagging',data:rc.map(x=>x.lagging_signals),backgroundColor:grad(C.lag),borderRadius:6,stack:'s'}]},
    options:{plugins:{legend:{position:'bottom',labels:{usePointStyle:true,pointStyle:'circle',padding:16,font:{family:'Inter'}}}},
      scales:{x:{stacked:true,grid:{display:false}},y:{stacked:true,grid:{color:'#eef0f3'}}}}});
}

// ================= EXECUTIVE SUMMARY (clickable cells) =================
function pExec(m){
  head(m,'Board-level heatmap','Theme × feature risk matrix',
    'Themes ordered most→least severe (left→right), colour graded red→yellow. <b>Click any cell</b> to see the numbers behind it.','exec');
  const rank={HIGH:0,MEDIUM:1,LOW:2};
  const M=[...DATA.matrix].sort((a,b)=>(rank[a.Severity]-rank[b.Severity])||(b.records-a.records));
  const feats=["Severity","Theme Velocity","X-Jurisdiction Overlap","News-RegDev Corr","Enforcement Corr"];
  const n=M.length,cols=`grid-template-columns:210px repeat(${n},minmax(150px,1fr))`;
  const wrap=el('div','matrix');const grid=el('div','mgrid');
  const hd=el('div','mhead');hd.style.cssText=cols;hd.appendChild(el('div','corner','Features'));
  M.forEach((r,i)=>{const c=el('div','thcard',r.theme);const col=RAMP[Math.min(i,RAMP.length-1)];
    c.style.background=`linear-gradient(135deg,${col},${col}dd)`;c.onclick=()=>openTheme(r.theme);hd.appendChild(c);});
  grid.appendChild(hd);
  feats.forEach(f=>{const row=el('div','mrow');row.style.cssText=cols;
    row.appendChild(el('div','mrlab',`<b>${f}</b>`));
    M.forEach(r=>{const v=r[f]||'MEDIUM';const cell=el('div','mcell',`<div class="badge"><span class="dot ${v==='HIGH'?'d-Lagging':v==='MEDIUM'?'d-Coincident':'d-Leading'}"></span><span class="sev-${v}" style="padding:0;background:none">${v}</span></div><span class="cell-more">click ⓘ</span>`);
      const reason=(r.reasons||{})[f]||'';
      cell.onclick=()=>openCellDetail(r.theme,f,v,reason);
      row.appendChild(cell);});
    grid.appendChild(row);});
  const vd=el('div','mvd');vd.style.cssText=cols;vd.appendChild(el('div',''));
  M.forEach(r=>{const b=el('button','vdbtn','View Details →');b.onclick=()=>openTheme(r.theme);vd.appendChild(b);});
  grid.appendChild(vd);wrap.appendChild(grid);m.appendChild(wrap);
}
function openCellDetail(theme,feat,val,reason){
  $('#helpBody').innerHTML=`<div class="cell-detail">
    <div class="cd-badge sev-${val}">${val}</div>
    <h2>${esc(String(theme).split(',')[0])}</h2>
    <div class="cd-feat">${esc(feat)}</div>
    <p class="cd-reason">${esc(reason)}</p></div>`;
  $('#helpModal').classList.add('show');
}
window.openCellDetail=openCellDetail;

// ================= RISK NETWORK (story-driven, growing right) =================
function pGraph(m){
  head(m,'Living risk map','Risk Network over time',
    'Watch the regulatory web build quarter by quarter. Press Play — new entities arrive and the story panel narrates what changed.','graph');
  const tg=DATA.tgraph;
  if(!tg.periods||!tg.periods.length){m.insertAdjacentHTML('beforeend','<div class="panel">Timeline needs dated records (REC_START_DT) to animate.</div>');return;}
  const wrap=el('div','grid g2');
  const box=el('div','viz');
  box.innerHTML=`<div class="slider-bar"><button class="play" id="playBtn">▶ Play</button>
      <input type="range" id="tSlider" min="0" max="${tg.periods.length-1}" value="0" step="1">
      <div class="slider-lab"><b id="sPeriod"></b> · <span id="sCount"></span></div></div><div id="rnet"></div>`;
  const story=el('div','panel story-panel');
  story.innerHTML=`<div class="ph"><div><h3>📖 The story so far</h3><small>what each quarter added</small></div></div><div id="storyLog"></div>`;
  wrap.appendChild(box);wrap.appendChild(story);m.appendChild(wrap);
  let sim=null,maxSeen=0;
  function frameAt(i){
    const p=tg.periods[i],fr=tg.frames[p];
    $('#sPeriod',box).textContent=p;$('#sCount',box).textContent=fr.count+' records total';
    $('#tSlider',box).value=i;
    drawNet($('#rnet',box),fr,p);
    // story log cumulative up to i
    const log=$('#storyLog',story);log.innerHTML='';
    for(let j=0;j<=i;j++){const pp=tg.periods[j],st=tg.story[pp];
      const item=el('div','story-item'+(j===i?' current':''));
      item.innerHTML=`<div class="st-period">${pp}</div><div class="st-body"><div class="st-head">${st.headline}</div>
        <ul>${st.parts.map(x=>`<li>${x}</li>`).join('')}</ul><div class="st-total">${st.total} records cumulatively</div></div>`;
      log.appendChild(item);}
    log.scrollTop=log.scrollHeight;
  }
  requestAnimationFrame(()=>frameAt(0));
  $('#tSlider',box).oninput=e=>frameAt(+e.target.value);
  let playing=false,timer=null;
  $('#playBtn',box).onclick=()=>{const btn=$('#playBtn',box);
    if(playing){clearInterval(timer);playing=false;btn.textContent='▶ Play';return;}
    playing=true;btn.textContent='⏸ Pause';let i=0;frameAt(0);
    timer=setInterval(()=>{i++;if(i>=tg.periods.length){clearInterval(timer);playing=false;btn.textContent='▶ Play';return;}frameAt(i);},1400);};
}
let _netPos={};
function drawNet(node,fr,period){
  const W=wOf(node,760),H=520;
  const color={theme:C.red,jurisdiction:'#2D6BE0',regulator:C.coin};
  d3.select(node).selectAll('*').remove();
  const svg=d3.select(node).append('svg').attr('width',W).attr('height',H);
  const nodes=fr.nodes.map(n=>({...n,x:_netPos[n.id]?.x??(n.born===period?W-60:W/2),y:_netPos[n.id]?.y??(Math.random()*H)}));
  const links=fr.links.map(l=>({...l}));
  const sim=d3.forceSimulation(nodes)
    .force('link',d3.forceLink(links).id(d=>d.id).distance(85))
    .force('charge',d3.forceManyBody().strength(-200))
    .force('center',d3.forceCenter(W/2,H/2)).force('collide',d3.forceCollide(22));
  const link=svg.append('g').selectAll('g').data(links).join('g');
  link.append('line').attr('stroke',C.line).attr('stroke-width',d=>Math.sqrt(d.value||1)*1.2);
  const nd=svg.append('g').selectAll('circle').data(nodes).join('circle')
    .attr('r',d=>d.type==='theme'?12:7).attr('fill',d=>color[d.type]).attr('stroke',d=>d.born===period?'#111':'#fff').attr('stroke-width',d=>d.born===period?3:2).style('cursor','grab')
    .call(d3.drag().on('start',(e,d)=>{if(!e.active)sim.alphaTarget(.3).restart();d.fx=d.x;d.fy=d.y}).on('drag',(e,d)=>{d.fx=e.x;d.fy=e.y}).on('end',(e,d)=>{if(!e.active)sim.alphaTarget(0);d.fx=null;d.fy=null}))
    .on('mousemove',(e,d)=>showTT(`<b>${esc(d.id)}</b><br>${d.type}${d.born===period?' · <span style="color:'+C.red+'">new this quarter</span>':''}`,e)).on('mouseout',hideTT);
  // pulse new nodes
  nd.filter(d=>d.born===period).append('title').text('new');
  svg.selectAll('circle').filter(d=>d.born===period).attr('r',d=>d.type==='theme'?14:9)
    .transition().duration(700).attr('r',d=>d.type==='theme'?12:7);
  const lab=svg.append('g').selectAll('text').data(nodes.filter(n=>n.type==='theme'||n.born===period)).join('text')
    .text(d=>d.id).style('font-size','10.5px').style('font-weight',d=>d.born===period?'700':'600').style('font-family','Inter').attr('dx',14).attr('dy',4);
  const lg=svg.append('g').attr('transform','translate(16,16)');
  [['Theme',C.red],['Jurisdiction','#2D6BE0'],['Regulator',C.coin],['New this quarter','#111']].forEach((d,i)=>{
    lg.append('circle').attr('cx',6).attr('cy',i*20+6).attr('r',5).attr('fill',d[1]);
    lg.append('text').attr('x',16).attr('y',i*20+10).text(d[0]).style('font-size','10.5px').style('fill',C.muted).style('font-family','Inter');});
  sim.on('tick',()=>{link.select('line').attr('x1',d=>d.source.x).attr('y1',d=>d.source.y).attr('x2',d=>d.target.x).attr('y2',d=>d.target.y);
    nd.attr('cx',d=>d.x).attr('cy',d=>d.y);lab.attr('x',d=>d.x).attr('y',d=>d.y);
    nodes.forEach(n=>_netPos[n.id]={x:n.x,y:n.y});});
}

// ================= TRENDS =================
function pTrends(m){
  head(m,'Activity over time','Trends',
    'Google-Trends-style view. Pick an object type and values to compare their signal volume month by month.','trends');
  const tr=DATA.trends;
  if(!tr.months||!tr.months.length){m.insertAdjacentHTML('beforeend','<div class="panel">Trends need dated records (REC_START_DT).</div>');return;}
  const panel=el('div','panel');
  panel.innerHTML=`<div class="trend-controls">
    <div><label>Object type</label><select id="trType">${Object.keys(tr.objects).map(k=>`<option>${k}</option>`).join('')}</select></div>
    <div style="flex:1"><label>Compare (pick up to 6)</label><div id="trPick" class="tr-pick"></div></div></div>
    <canvas id="trChart" height="110"></canvas>`;
  m.appendChild(panel);
  let chart=null;
  const palette=['#DB0011','#2D6BE0','#0B7A57','#C67A00','#7C3AED','#0891B2','#DC2626','#65A30D'];
  function objList(){return tr.objects[$('#trType',panel).value]||{};}
  function renderPicks(){
    const obj=objList();const keys=Object.keys(obj);const pick=$('#trPick',panel);pick.innerHTML='';
    keys.forEach((kk,i)=>{const b=el('button','tr-tag'+(i<3?' on':''),esc(kk));b.dataset.k=kk;b.onclick=()=>{b.classList.toggle('on');draw();};pick.appendChild(b);});
  }
  function draw(){
    const obj=objList();const picked=$$('.tr-tag.on',panel).map(b=>b.dataset.k).slice(0,6);
    const ds=picked.map((kk,i)=>({label:kk,data:obj[kk],borderColor:palette[i%palette.length],backgroundColor:palette[i%palette.length]+'22',tension:.35,fill:false,pointRadius:2,borderWidth:2.5}));
    if(chart)chart.destroy();
    chart=new Chart($('#trChart',panel).getContext('2d'),{type:'line',
      data:{labels:tr.months,datasets:ds},
      options:{plugins:{legend:{position:'bottom',labels:{usePointStyle:true,pointStyle:'circle',font:{family:'Inter'}}}},
        interaction:{mode:'index',intersect:false},
        scales:{x:{grid:{display:false},ticks:{font:{family:'Inter'},maxRotation:0,autoSkip:true,maxTicksLimit:12}},y:{beginAtZero:true,grid:{color:'#eef0f3'},title:{display:true,text:'signals / month'}}}}});
  }
  $('#trType',panel).onchange=()=>{renderPicks();draw();};
  renderPicks();draw();
}

// ================= CROSS-JURISDICTION =================
function pCont(m){
  head(m,'How regulation spreads','Which markets move first — and who follows',
    'Watching markets that move first buys lead time before the same rule reaches follower markets.','contagion');
  const g=el('div','grid g2b');
  const l=el('div','panel');l.innerHTML='<div class="ph"><div><h3>Most proactive markets</h3><small>leading-signal ratio — higher = moves first</small></div></div><div id="lead"></div>';
  const r=el('div','panel');r.innerHTML='<div class="ph"><div><h3>Contagion flows</h3><small>origin ▸ likely follower</small></div></div><div class="scroll" id="flows" style="max-height:520px"></div>';
  g.appendChild(l);g.appendChild(r);m.appendChild(g);
  const jm=DATA.jm.filter(j=>j.record_count>=3).sort((a,b)=>(b.leading_ratio||0)-(a.leading_ratio||0)).slice(0,12);
  const mx=Math.max(...jm.map(j=>j.leading_ratio||0),.01);const ld=$('#lead',l);
  jm.forEach((j,i)=>{const row=el('div','lead-row');
    row.innerHTML=`<div class="lead-rank">${i+1}</div><div class="lead-name">${esc(j.jurisdiction)}</div><div class="lead-track"><div class="lead-fill" style="width:0%"></div></div><b class="lead-val">${(j.leading_ratio||0).toFixed(2)}</b>`;
    ld.appendChild(row);setTimeout(()=>row.querySelector('.lead-fill').style.width=(j.leading_ratio/mx*100).toFixed(0)+'%',60+i*50);});
  const fl=$('#flows',r);
  if(!DATA.edges.length){fl.innerHTML='<div class="empty">No follower-jurisdiction tags in this dataset.</div>';return;}
  DATA.edges.forEach(e=>{const row=el('div','flow-row');
    row.innerHTML=`<span class="node-o">${esc(e.source)}</span><span class="flow-arrow"><span class="flow-dot"></span></span><span class="node-f">${esc(e.target)}</span><b class="flow-w">×${e.weight}</b>`;
    fl.appendChild(row);});
}

// ================= CONTROLS & GAPS (gap detail popup) =================
function pCtrl(m){
  const k=DATA.kpi;
  head(m,'Signal → action','Controls & Gaps',
    'Each signal maps to the controls it affects, with probable gaps and a recommended fix. <b>Click a gap</b> to open its full remediation detail.','controls');
  m.insertAdjacentHTML('beforeend',`<div class="kpis">
    <div class="kpi"><div class="lab">Controls mapped</div><div class="val">${num(k.controls)}</div><div class="sub">across all signals</div></div>
    <div class="kpi"><div class="lab">Probable gaps</div><div class="val">${num(k.gaps)}</div><div class="sub">each with a fix</div></div>
    <div class="kpi hot"><div class="lab">High-severity gaps</div><div class="val">${num(k.hi_gaps)}</div><div class="sub">priority remediation</div><div class="spark">!</div></div>
    <div class="kpi"><div class="lab">Jurisdictions</div><div class="val">${num(k.jurisdictions)}</div><div class="sub">in scope</div></div></div>`);
  const p=el('div','panel');
  p.innerHTML=`<div class="filters2 wide"><input id="cq" placeholder="Search control, obligation or record…">
    <select id="cth"><option value="">All themes</option></select>
    <select id="csv"><option value="">All gap severities</option><option>High</option><option>Medium</option><option>Low</option></select></div>
    <div class="caption" id="ccount"></div>
    <div class="scroll"><table><thead><tr><th>Control</th><th>Steward</th><th>Theme</th><th>Type</th><th>Effectiveness</th><th>Gaps (click)</th></tr></thead><tbody id="cbody"></tbody></table></div>`;
  m.appendChild(p);
  const themes=[...new Set(DATA.controls.map(c=>c.primary_theme).filter(Boolean))].sort();
  themes.forEach(t=>$('#cth',p).appendChild(el('option',null,esc(t))));
  const gapBy={};DATA.gaps.forEach(g=>{(gapBy[g.control_id]=gapBy[g.control_id]||[]).push(g);});
  function draw(){const q=($('#cq',p).value||'').toLowerCase(),th=$('#cth',p).value,sv=$('#csv',p).value;
    const tb=$('#cbody',p);tb.innerHTML='';let shown=0;
    DATA.controls.filter(c=>{if(th&&c.primary_theme!==th)return false;if(sv&&!(gapBy[c.control_id]||[]).some(g=>g.gap_severity===sv))return false;
      if(q&&!`${c.control_id} ${c.control_title} ${c.obligation_addressed} ${c.Message_ID}`.toLowerCase().includes(q))return false;return true;})
      .slice(0,120).forEach(c=>{shown++;const gaps=gapBy[c.control_id]||[];
      const worst=gaps.some(g=>g.gap_severity==='High')?'High':gaps.some(g=>g.gap_severity==='Medium')?'Medium':gaps.length?'Low':null;
      const chips=gaps.slice(0,4).map((g,gi)=>`<span class="gap-chip sev-${g.gap_severity}" data-cid="${esc(c.control_id)}" data-gi="${gi}">${g.gap_severity||'—'}</span>`).join(' ');
      const tr=el('tr');tr.innerHTML=`<td><span class="pill">${esc(c.control_id)}</span><div style="font-weight:600;margin-top:3px">${esc(c.control_title)}</div></td>
        <td>${esc(c.risk_steward_name)}</td><td style="color:var(--muted)">${esc(String(c.primary_theme||'').split(',')[0])}</td>
        <td>${esc(c.control_type||'—')}</td><td>${esc(c.control_effectiveness||'—')}</td><td>${chips||'—'}</td>`;
      tb.appendChild(tr);});
    $('#ccount',p).textContent=`${shown} control${shown!==1?'s':''} shown`;
    tb.querySelectorAll('.gap-chip').forEach(ch=>ch.onclick=()=>{const g=(gapBy[ch.dataset.cid]||[])[+ch.dataset.gi];const c=DATA.controls.find(x=>x.control_id===ch.dataset.cid);openGapDetail(c,g);});}
  $('#cq',p).oninput=draw;$('#cth',p).onchange=draw;$('#csv',p).onchange=draw;draw();
}
function openGapDetail(c,g){
  const sevc=g.gap_severity==='High'?C.lag:g.gap_severity==='Medium'?C.coin:C.lead;
  $('#drawerBody').innerHTML=`<div class="dhead" style="background:linear-gradient(135deg,${sevc},${sevc}cc)">
      <button class="dclose" onclick="closeDrawer()">×</button><div class="de">Gap remediation detail</div>
      <h2>${esc(c.control_title||'')}</h2><div class="dhead-kpis"><span>${esc(c.control_id)}</span><span>${esc(c.risk_steward_name||'')}</span><span>Severity: ${esc(g.gap_severity||'—')}</span></div></div>
    <div class="dbody">
      <div class="gd-sec"><h3>🔎 The gap</h3><p>${esc(g.gap_description||'—')}</p></div>
      <div class="gd-sec fix"><h3>✅ Recommended remediation</h3><p>${esc(g.recommendation||'—')}</p></div>
      <div class="gd-grid">
        <div class="gd-kv"><span>Control</span><b>${esc(c.control_title||'—')}</b></div>
        <div class="gd-kv"><span>Obligation addressed</span><b>${esc(c.obligation_addressed||'—')}</b></div>
        <div class="gd-kv"><span>Risk steward (owner)</span><b>${esc(c.risk_steward_name||'—')}</b></div>
        <div class="gd-kv"><span>Current effectiveness</span><b>${esc(c.control_effectiveness||'—')}</b></div>
        <div class="gd-kv"><span>Control type / level</span><b>${esc(c.control_type||'—')} · ${esc(c.control_level||'—')}</b></div>
        <div class="gd-kv"><span>Linked signal</span><b>${esc(c.Message_ID||'—')}</b></div>
      </div></div>`;
  $('#drawer').classList.add('open');$('#scrim').classList.add('show');
}
window.openGapDetail=openGapDetail;

// ================= REGULATORS =================
function pRegs(m){
  head(m,'Who drives the agenda','Regulators & source validation',
    'Which regulators to watch, and proof the signal-timing engine is grounded.','regs');
  const g=el('div','grid g2');
  const l=el('div','panel');l.innerHTML='<div class="ph"><div><h3>Regulator league table</h3></div></div><div class="scroll"><table><thead><tr><th>Regulator</th><th>Records</th><th>Juris.</th><th>Leading</th><th>Conf.</th></tr></thead><tbody id="rb"></tbody></table></div>';
  const r=el('div','panel');r.innerHTML='<div class="ph"><div><h3>Source-category validation</h3><small>news skews leading · enforcement lags</small></div></div><div id="scv"></div>';
  g.appendChild(l);g.appendChild(r);m.appendChild(g);
  const rb=$('#rb',l);
  DATA.rm.forEach(x=>{const tr=el('tr');tr.innerHTML=`<td style="font-weight:600">${esc(x.regulator)}</td><td>${num(x.record_count)}</td><td style="color:var(--muted)">${num(x.jurisdiction_count)}</td><td><span class="chip sig-Leading">${num(x.leading_signals)}</span></td><td>${x.avg_confidence!=null?Number(x.avg_confidence).toFixed(2):'—'}</td>`;rb.appendChild(tr);});
  const scv=$('#scv',r);
  DATA.rc.forEach(x=>{const tot=Math.max(x.record_count||1,1),ld=x.leading_signals||0,lg=x.lagging_signals||0;
    scv.insertAdjacentHTML('beforeend',`<div class="scv-row"><div class="scv-lab"><b>${esc(x.record_cat_code)}</b> <span>${esc(x.description||'')}</span></div><div class="scv-bar"><div style="width:${100*ld/tot}%;background:${C.lead}"></div><div style="width:${100*(tot-ld-lg)/tot}%;background:${C.coin}"></div><div style="width:${100*lg/tot}%;background:${C.lag}"></div></div></div>`);});
}

// ================= IMPACT & ONTOLOGY =================
function pImpact(m){
  head(m,'Exposure & structure','Impact & Ontology',
    'Two lenses: trace a theme\'s cascade (impact ripple), or drill the structured hierarchy (ontology).','impact');
  const tabs=el('div','sub-tabs');
  tabs.innerHTML=`<button class="stab active" data-p="imp-ripple">🌊 Impact ripple</button><button class="stab" data-p="imp-onto">🧬 Ontology tree</button>`;
  m.appendChild(tabs);
  const ripple=el('div','sub-pane active');ripple.id='imp-ripple';
  const themes=Object.keys(DATA.impact);
  ripple.innerHTML=`<div class="panel"><div class="ph"><div><h3>Pick a theme to trace its cascade</h3><small>records → controls → gaps → who's affected → who follows</small></div>
    <select id="impTheme">${themes.map(t=>`<option value="${esc(t)}">${esc(String(t).split(',')[0])}</option>`).join('')}</select></div><div id="rippleView"></div></div>`;
  m.appendChild(ripple);
  const onto=el('div','sub-pane');onto.id='imp-onto';
  onto.innerHTML=`<div class="panel"><div class="ph"><div><h3>Ontology — Theme → Steward → Control → Action</h3><small>actions ordered High → Medium → Low · click to expand</small></div></div><div id="ontoTree"></div></div>`;
  m.appendChild(onto);
  tabs.querySelectorAll('.stab').forEach(b=>b.onclick=()=>{tabs.querySelectorAll('.stab').forEach(x=>x.classList.remove('active'));m.querySelectorAll('.sub-pane').forEach(x=>x.classList.remove('active'));b.classList.add('active');$('#'+b.dataset.p).classList.add('active');
    if(b.dataset.p==='imp-onto'&&!$('#ontoTree').dataset.built){$('#ontoTree').dataset.built=1;buildOnto();}});
  function drawRipple(theme){const d=DATA.impact[theme];const v=$('#rippleView');
    v.innerHTML=`<div class="ripple">
      <div class="rp-stage"><div class="rp-node rp-theme pop" style="animation-delay:0s">${esc(String(theme).split(',')[0])}<small>${d.records} records</small></div></div>
      <div class="rp-arrow">→</div>
      <div class="rp-stage"><div class="rp-node rp-ctrl pop" style="animation-delay:.1s">${d.controls}<small>controls hit</small></div></div>
      <div class="rp-arrow">→</div>
      <div class="rp-stage"><div class="rp-node rp-gap hi pop" style="animation-delay:.2s">${d.hi_gaps}<small>high gaps</small></div><div class="rp-node rp-gap med pop" style="animation-delay:.28s">${d.med_gaps}<small>med gaps</small></div></div>
      <div class="rp-arrow">→</div>
      <div class="rp-stage"><div class="rp-node rp-jur pop" style="animation-delay:.36s">${d.jurisdictions}<small>jurisdictions</small></div></div></div>
      <div class="ripple-detail">
        <div class="rd-col"><h4>👤 Risk stewards owning this</h4>${d.stewards.length?d.stewards.map(s=>`<span class="tag">${esc(s)}</span>`).join(''):'<span class="muted">none mapped</span>'}</div>
        <div class="rd-col"><h4>🏢 Business lines affected</h4>${d.business_lines.length?d.business_lines.map(b=>`<span class="tag">${esc(b)}</span>`).join(''):'<span class="muted">—</span>'}</div>
        <div class="rd-col"><h4>🌐 Likely to follow next</h4>${d.followers.length?d.followers.map(([f,w])=>`<span class="tag">${esc(f)} <i>×${w}</i></span>`).join(''):'<span class="muted">—</span>'}</div></div>`;}
  $('#impTheme',ripple).onchange=e=>drawRipple(e.target.value);drawRipple(themes[0]);
  function buildOnto(){const tree=$('#ontoTree');
    DATA.ontology.forEach(t=>{const node=el('div','onto-theme');
      node.innerHTML=`<div class="onto-h theme"><span class="tw">▸</span> ${esc(t.theme)} <small>${t.count} controls · ${t.stewards.length} stewards</small></div><div class="onto-kids"></div>`;
      const kids=node.querySelector('.onto-kids');
      t.stewards.forEach(s=>{const sn=el('div','onto-steward');
        sn.innerHTML=`<div class="onto-h steward"><span class="tw">▸</span> 👤 ${esc(s.steward)} <small>${s.count} controls</small></div><div class="onto-kids"></div>`;
        const ck=sn.querySelector('.onto-kids');
        s.controls.forEach(c=>{const cn=el('div','onto-ctrl');
          // order gaps High->Med->Low, label as Actions
          const rank={High:0,Medium:1,Low:2};const sorted=[...c.gaps].sort((a,b)=>(rank[a.sev]??3)-(rank[b.sev]??3));
          const acts=sorted.map(gp=>`<div class="onto-action"><span class="act-badge sev-${gp.sev}">ACTION · ${gp.sev||'—'}</span> <span>${esc(gp.desc)}</span></div>`).join('')||'<div class="onto-action muted">no actions</div>';
          cn.innerHTML=`<div class="onto-h ctrl"><span class="tw">▸</span> <span class="pill">${esc(c.id)}</span> ${esc(c.title)} <small>${esc(c.eff)}</small></div><div class="onto-kids">${acts}</div>`;
          cn.querySelector('.onto-h').onclick=e=>{e.stopPropagation();cn.classList.toggle('open');};ck.appendChild(cn);});
        sn.querySelector('.onto-h').onclick=e=>{e.stopPropagation();sn.classList.toggle('open');};kids.appendChild(sn);});
      node.querySelector('.onto-h').onclick=()=>node.classList.toggle('open');tree.appendChild(node);});}
}

// ================= OPTIONS =================
function pOptions(m){
  head(m,'Personalise','Options',
    'Hide pages you don\'t need and change the accent colour. Saved in your browser.','options');
  const p=el('div','panel');
  const toggles=TABS.filter(([id])=>id!=='options').map(([id,ic,label])=>
    `<label class="opt-row"><span>${ic} ${label}</span><input type="checkbox" data-hide="${id}" ${PREFS.hidden.includes(id)?'':'checked'}></label>`).join('');
  const swatches=['#DB0011','#2D6BE0','#0B7A57','#7C3AED','#C67A00','#111827'].map(c=>
    `<button class="sw" style="background:${c}" data-c="${c}"></button>`).join('');
  p.innerHTML=`<div class="opt-sec"><h3>Visible pages</h3><div class="opt-list">${toggles}</div></div>
    <div class="opt-sec"><h3>Accent colour</h3><div class="sw-row">${swatches}</div></div>
    <div class="opt-sec"><button class="reset-btn" id="optReset">Reset to defaults</button></div>`;
  m.appendChild(p);
  p.querySelectorAll('[data-hide]').forEach(cb=>cb.onchange=()=>{
    const id=cb.dataset.hide;if(cb.checked)PREFS.hidden=PREFS.hidden.filter(x=>x!==id);else if(!PREFS.hidden.includes(id))PREFS.hidden.push(id);
    savePrefs();buildNav();});
  p.querySelectorAll('.sw').forEach(b=>b.onclick=()=>{PREFS.accent=b.dataset.c;document.documentElement.style.setProperty('--red',b.dataset.c);savePrefs();});
  $('#optReset',p).onclick=()=>{PREFS={hidden:[],accent:null};savePrefs();document.documentElement.style.setProperty('--red','#DB0011');buildNav();render();};
}

// ================= THEME DRAWER (View Details) =================
function openTheme(theme){
  const t=DATA.themes[theme];if(!t)return;const short=String(theme).split(',')[0];
  // recommendations: clearly labelled ACTIONS that fix GAPS on CONTROLS
  const recsHtml=(t.recs||[]).length?(t.recs||[]).map(g=>`<div class="rec-card">
    <div class="rec-head"><span class="pill">${esc(g.control_id)}</span> <b>${esc(g.title)}</b> <span class="rec-tag">control</span></div>
    <table class="rec-table"><thead><tr><th>Priority</th><th>Action to take</th><th>Fixes this gap</th></tr></thead><tbody>
    ${g.items.map(i=>`<tr><td>${sev(i.sev)}</td><td><b>${esc(i.action)}</b></td><td class="muted">${esc(i.addresses)}</td></tr>`).join('')}</tbody></table></div>`).join(''):'<p class="muted">No recommendations for this theme.</p>';
  const gapHtml=(t.gap_controls||[]).length?(t.gap_controls||[]).map((c,i)=>{
    const worstSev=c.gaps.length?c.gaps[0].sev:'—';
    return `<div class="gap-ctrl" data-i="${i}">
      <div class="gc-head"><span class="tw">▸</span><span class="worst sev-${worstSev}">${worstSev}</span><span class="pill">${esc(c.control_id)}</span> <b>${esc(c.title)}</b><span class="gc-meta">${esc(c.steward)} · ${esc(c.eff)}</span></div>
      <div class="gc-body"><div class="gc-obl"><b>Obligation:</b> ${esc(c.obligation||'—')}</div>
        ${c.gaps.length?`<table class="gap-table"><thead><tr><th>Sev</th><th>Gap (issue)</th><th>Fix (action)</th></tr></thead><tbody>
          ${c.gaps.map(x=>`<tr><td>${sev(x.sev)}</td><td>${esc(x.gap)}</td><td class="fix-cell">${esc(x.rec)}</td></tr>`).join('')}</tbody></table>`:'<div class="muted">No gaps recorded.</div>'}</div></div>`;}).join(''):'<p class="muted">No controls mapped.</p>';
  $('#drawerBody').innerHTML=`
    <div class="dhead"><button class="dclose" onclick="closeDrawer()">×</button><div class="de">Theme workspace</div><h2>${esc(short)}</h2>
      <div class="dhead-kpis">
        <span title="Open-source news signals">📰 ${num(t.news)} news</span>
        <span title="Regulatory developments">📋 ${num(t.regdev)} rules</span>
        <span title="Controls mapped to this theme">🛡 ${num(t.controls)} controls</span>
        <span title="High-severity gaps">⚠️ ${num(t.hi_gaps)} high gaps</span></div></div>
    <div class="dbody">
      <div class="dtabs"><button class="dtab active" data-p="d-mind">🧠 Mind-Map</button><button class="dtab" data-p="d-rec">📋 Recommendations</button><button class="dtab" data-p="d-gap">🧭 Gap Assessment</button></div>
      <div class="dpane active" id="d-mind">
        <div class="mind-legend">Flow: <b>Theme</b> → <b style="color:${C.coin}">Risk Steward</b> (owner) → <b style="color:${C.red}">Control</b> → <b style="color:#2D6BE0">Gap</b> (severity). This shows, from an action view, <i>who owns what</i> and <i>which specific weakness</i> to fix.</div>
        <div class="viz big"><div class="vhead"><h3>${esc(short)} — control ownership map</h3><p>scroll to zoom · drag to pan · click a node</p></div><div id="dmm"></div></div></div>
      <div class="dpane" id="d-rec"><div class="rec-intro">These are <b>actions</b> (recommendations). Each row is an action that fixes a specific <b>gap</b> on a named <b>control</b> (<span class="pill">1C-…</span>). Ordered High→Low priority. The control ID lets the same fix be tracked across alerts and remediation.</div>${recsHtml}</div>
      <div class="dpane" id="d-gap"><div class="gap-layout">
        <div class="gap-reg"><h3>📄 Regulation content</h3><div class="reg-text">${esc(t.reg_content||'—')}</div></div>
        <div class="gap-ctrls"><h3>🧭 Impacted controls <small>ordered by worst gap · click to expand</small></h3>${gapHtml}</div>
      </div></div></div>`;
  $('#drawerBody').querySelectorAll('.dtab').forEach(b=>b.onclick=()=>{$('#drawerBody').querySelectorAll('.dtab').forEach(x=>x.classList.remove('active'));$('#drawerBody').querySelectorAll('.dpane').forEach(x=>x.classList.remove('active'));b.classList.add('active');$('#'+b.dataset.p).classList.add('active');});
  $('#drawerBody').querySelectorAll('.gap-ctrl .gc-head').forEach(h=>h.onclick=()=>h.parentElement.classList.toggle('open'));
  $('#drawer').classList.add('open');$('#scrim').classList.add('show');
  setTimeout(()=>drawMindHier($('#dmm'),short,t),160);
}
function closeDrawer(){$('#drawer').classList.remove('open');$('#scrim').classList.remove('show');}
window.closeDrawer=closeDrawer;
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeDrawer();closeHelp();}});

// hierarchical zoomable mind-map: theme -> steward -> control -> gap
function drawMindHier(node,short,t){
  const W=wOf(node,860),H=560;
  d3.select(node).selectAll('*').remove();
  const svg=d3.select(node).append('svg').attr('width',W).attr('height',H);
  const g=svg.append('g');
  svg.call(d3.zoom().scaleExtent([0.3,3]).on('zoom',e=>g.attr('transform',e.transform)));
  const data={name:short,kind:'theme',children:(t.mm_children||[])};
  const root=d3.hierarchy(data);
  const dx=18,dy=W/(root.height+1);
  d3.tree().nodeSize([dx,dy])(root);
  let x0=Infinity,x1=-Infinity;root.each(d=>{if(d.x>x1)x1=d.x;if(d.x<x0)x0=d.x;});
  g.attr('transform',`translate(90,${H/2-(x0+x1)/2})`);
  const color=d=>d.depth===0?C.ink:d.depth===1?C.coin:d.depth===2?C.red:'#2D6BE0';
  g.selectAll('path').data(root.links()).join('path').attr('fill','none').attr('stroke',C.line).attr('stroke-width',1.4)
    .attr('d',d3.linkHorizontal().x(d=>d.y).y(d=>d.x));
  const nd=g.selectAll('g').data(root.descendants()).join('g').attr('transform',d=>`translate(${d.y},${d.x})`);
  nd.append('circle').attr('r',d=>[9,7,6,4][d.depth]||4).attr('fill',color).style('cursor','pointer')
    .on('mousemove',(e,d)=>{const kind=d.data.kind||(d.depth===3?'gap':'');showTT(`<b>${esc(d.data.name)}</b>${kind?'<br>'+kind:''}`,e);}).on('mouseout',hideTT);
  nd.append('text').attr('dy',3).attr('x',d=>d.children?-11:11).style('text-anchor',d=>d.children?'end':'start')
    .style('font-size',d=>d.depth>=3?'9.5px':d.depth===0?'13px':'11px').style('font-weight',d=>d.depth<=1?'700':'500')
    .style('font-family','Inter').style('fill',d=>d.depth>=3?C.muted:C.ink).text(d=>d.data.name);
}
