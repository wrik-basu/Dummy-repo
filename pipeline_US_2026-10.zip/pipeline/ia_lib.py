# ==============================================================================
# ia_lib.py  -  shared helpers for the ontology / impact-assessment pipeline
# ------------------------------------------------------------------------------
# Imported by notebooks 03-06 (01 and 02 carry their own build helpers).
# No LLM calls here; no hidden state: everything is built from files on disk.
#
#   read_any, cid, txt                     readers / cleaning (same rules as the build)
#   load_gpps, doc_sections, render        GPPS documents, VISIBLE sections only
#   load_docs(SOURCES)                     {POL-<id> / PROC-<id>: title, sections, text}
#   Context(OUT_DIR, SOURCES)              graph + documents + alert text / metadata,
#                                          build_payload(row) for the LLM / judge
#   clean_words, quote_found               verbatim quote check (same as every audit)
#   section_labels                         'S4' -> 'S4 | 3.2 <GPPS title>'
#   wilson                                 95% confidence interval
# ==============================================================================
import re
import json
import html
import math
import hashlib

import numpy as np
import pandas as pd
import pyarrow.parquet as pq


# ------------------------------------------------------------------------------
# Readers / cleaning
# ------------------------------------------------------------------------------
def read_any(path):
    """parquet (dbdate-safe), xlsx/xls or csv. Full text, nothing truncated."""
    if path.endswith(".parquet"):
        return pq.read_table(path).replace_schema_metadata(None).to_pandas(date_as_object=True)
    if path.endswith((".xlsx", ".xls")):
        return pd.read_excel(path)
    return pd.read_csv(path)


def is_blank(v):
    return v is None or (isinstance(v, float) and pd.isna(v))


def cid(v):
    """Clean an ID: hidden characters / spaces removed, 123.0 -> 123, '-' -> ''."""
    if is_blank(v):
        return ""
    s = re.sub(r"[​ ﻿]", "", str(v)).strip()
    if s.endswith(".0") and s[:-2].isdigit():
        s = s[:-2]
    return "" if s.lower() in ("nan", "none", "", "-") else s


def txt(v):
    """Clean text: HTML stripped, entities unescaped, spaces squashed. Full length."""
    if is_blank(v):
        return ""
    s = re.sub(r"(?s)<[^>]+>", " ", str(v))
    return re.sub(r"\s+", " ", html.unescape(s)).strip()


# ------------------------------------------------------------------------------
# GPPS documents (visible sections only)
# ------------------------------------------------------------------------------
def _parse_json(v):
    if isinstance(v, dict):
        return v
    if isinstance(v, str) and v.strip():
        return json.loads(v)
    return {}


def load_gpps(paths, id_col):
    """Latest version per document (highest version_num), json_data parsed."""
    df = pd.concat([read_any(p) for p in paths], ignore_index=True)
    df = df.sort_values("version_num", ascending=False).drop_duplicates(id_col)
    df["doc"] = df["json_data"].map(_parse_json)
    return df


def _first(d, keys):
    return next((d.get(k) for k in keys if d.get(k) not in (None, "")), None)


def doc_sections(d, kind):
    """[(gpps_number, title, text)] for the sections the GPPS UI shows, in order."""
    out = []
    if kind == "policy":
        for title, block in (("Policy Statement", d.get("policyText")), ("Purpose", d.get("policyPurpose"))):
            if isinstance(block, dict) and txt(block.get("sgmntText")):
                out.append(("", txt(block.get("sgmntTitlText")) or title, txt(block.get("sgmntText"))))
        segments = (d.get("policyApplication") or {}).get("segment") or []
        title_keys, text_keys = ["sgmntTitlText"], ["sgmntText"]
        hide_keys, num_keys = ["sgmntDispInd"], ["dispSortOrdrNum", "sortOrdrNum"]
    else:
        block = d.get("procedurePurpose")
        if isinstance(block, dict) and txt(block.get("procSgmntText")):
            out.append(("", "Purpose", txt(block.get("procSgmntText"))))
        segments = (d.get("procedureApplication") or {}).get("segment") or []
        title_keys, text_keys = ["procSgmntTitlText", "sgmntTitlText"], ["procSgmntText", "sgmntText"]
        hide_keys = ["procSgmntDispInd", "sgmntDispInd"]
        num_keys = ["procDispSortOrdrNum", "dispSortOrdrNum", "procSortOrdrNum", "sortOrdrNum"]

    for seg in segments:
        if any(str(seg.get(k) or "").strip().upper() == "N" for k in hide_keys):
            continue                                            # hidden in the GPPS UI
        text = txt(_first(seg, text_keys))
        if text:
            out.append((cid(_first(seg, num_keys)), txt(_first(seg, title_keys)), text))

    seen, result = set(), []                                    # statement / purpose repeated as segments
    for num, title, text in out:
        key = hashlib.md5(text.encode("utf-8")).hexdigest()
        if key not in seen:
            seen.add(key)
            result.append((num, title, text))
    return result


def render(sections):
    return "\n\n".join(f"[S{i} | {(num + ' ' if num else '')}{title}]\n{text}"
                       for i, (num, title, text) in enumerate(sections, start=1))


def load_docs(sources):
    """{doc id: dict(type, title, sections, text, source_chars)} for every GPPS document."""
    pol = load_gpps([sources["gpps_pol_us"], sources["gpps_pol_glob"]], "policy_core_id")
    proc = load_gpps([sources["gpps_proc"]], "procedure_core_id")
    docs = {}
    for kind, df, id_col, title_key, prefix in (("policy", pol, "policy_core_id", "policyTitle", "POL-"),
                                                ("procedure", proc, "procedure_core_id", "procedureTitle", "PROC-")):
        for r in df.itertuples():
            secs = doc_sections(r.doc, kind)
            docs[f"{prefix}{cid(getattr(r, id_col))}"] = dict(
                type=kind, title=txt(r.doc.get(title_key)), sections=secs,
                text=render(secs), source_chars=sum(len(t) for _, _, t in secs))
    return docs


# ------------------------------------------------------------------------------
# Context: graph + documents + payload builder (used by 03, 04, 05)
# ------------------------------------------------------------------------------
class Context:
    def __init__(self, out_dir, sources, load_documents=True):
        self.nodes = pd.read_parquet(f"{out_dir}/nodes.parquet")
        self.edges = pd.read_parquet(f"{out_dir}/edges.parquet")
        self.node = self.nodes.set_index("id")[["title", "text"]].to_dict("index")
        self.docs = load_docs(sources) if load_documents else {}
        names = dict(zip(self.nodes["id"], self.nodes["title"]))
        self.alert_meta = {}
        intake = self.edges[self.edges["layer"] == "INTAKE"]
        for aid, g in intake.groupby("source"):
            by = {p: [names.get(t, t) for t in gg["target"]] for p, gg in g.groupby("property")}
            self.alert_meta[aid] = (f"jurisdiction: {', '.join(by.get('inJurisdiction', [])) or 'n/a'} | "
                                    f"regulator: {', '.join(by.get('issuedByRegulator', [])) or 'n/a'} | "
                                    f"taxonomy tag: {', '.join(by.get('taggedRisk', [])) or 'n/a'}")

    def node_text(self, nid):
        n = self.node.get(nid, {})
        return (n.get("title") or ""), (n.get("text") or "")

    def alert_text(self, aid):
        title, text = self.node_text(aid)
        return f"{title}\n{text}".strip()

    def build_payload(self, row):
        """Same field names as the Helios run: alert_text, alert_metadata, doc id/text, context."""
        d = self.docs[row.doc]
        robs = [r for r in str(row.via_robs or "").split(" | ") if r]
        return {
            "alert_text": self.alert_text(row.alert),
            "alert_metadata": self.alert_meta.get(row.alert, ""),
            "doc_id": row.doc,
            "document_title": d["title"],
            "document_text": d["text"],
            "bridge_context": [{"obligation_id": r, "title": self.node_text(r)[0], "text": self.node_text(r)[1]}
                               for r in robs],
        }

    def section_labels(self, doc_id, s_ids):
        """['S4'] -> ['S4 | 3.2 <title>'] using the real GPPS number + title."""
        secs, out = self.docs[doc_id]["sections"], []
        for s in s_ids or []:
            m = re.search(r"\d+", str(s))
            if m and 1 <= int(m.group()) <= len(secs):
                num, title, _ = secs[int(m.group()) - 1]
                out.append(f"S{m.group()} | {(num + ' ' if num else '')}{title}")
        return out


# ------------------------------------------------------------------------------
# Checks and statistics (same as every audit in the project)
# ------------------------------------------------------------------------------
def clean_words(s):
    return re.sub(r"[^a-z0-9]+", " ", str(s or "").lower()).strip()


def quote_found(quote, text):
    """Verbatim (case / punctuation-insensitive); long quotes may match on 8-word ends."""
    q = clean_words(quote)
    if len(q) < 12 or q in ("null", "none"):
        return False
    t = clean_words(text)
    if q in t:
        return True
    words = q.split()
    return len(words) >= 6 and (" ".join(words[:8]) in t or " ".join(words[-8:]) in t)


def wilson(k, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0, c - h), min(1, c + h))
