# Regulatory Compliance Ontology + Impact Assessment pipeline

Builds the ontology graph (alert → regulation → summary → obligation; library risk → library control → control instance; policies and procedures) from the systems of record and the IA linkage outputs. It then adds **alert → policy / procedure impact**, found by an LLM and confirmed by an independent LLM judge.

Every step reads files written by the previous step, so any notebook can be run in a fresh session.

## Files

| File | What it is |
|---|---|
| `pipeline_config.py` | **The only file to edit.** Country, run ID, all source paths, options, LLM settings and prices. |
| `ia_lib.py` | Shared helpers for 03–06: readers, the GPPS visible-section parser, the payload builder, the quote check and Wilson intervals. |
| `01_ontology_build.txt` | Phase 1 (facts) + phase 2 (existing AI links) → `nodes.parquet` and `edges.parquet`. Cost: $0. |
| `02_taxonomy_alignment.txt` | Finds risk-type names used by only one system → `taxonomy_alignment.xlsx` (editable `map_to`). Cost: $0. |
| `03_impact_candidates.txt` | Alert → policy / procedure candidate pairs (obligation route + fallback) and a cost estimate. Cost: $0. |
| `04_impact_llm.txt` | LLM decision per pair, using the final v1 prompts. US run: about $12. |
| `05_impact_audit.txt` | Independent judge: all LINKED pairs, a rejection sample and planted wrong links. US run: about $4. |
| `06_load_impacts.txt` | Pre-load checks, then all pairs are loaded into the graph and confirmed impacts are flagged. Cost: $0. |
| `diagnostics/` | Not part of the run. The ID-join diagnosis cell and the archived procedure prompt v2 / v2.1 (rejected at the A/B gate). |

Each `.txt` notebook goes one `# ====== CELL n` block per notebook cell. Keep `pipeline_config.py` and `ia_lib.py` in the same folder as the notebooks.

## Run order

```
01_ontology_build      (first build)
02_taxonomy_alignment  -> optionally have an SME fill / correct map_to
01_ontology_build      (again: its CELL 7b merges the mapped names)
03_impact_candidates
04_impact_llm          (paste your gateway cells as CELL 0; test 10 pairs before CELL 6)
05_impact_audit        (paste gateway cells as CELL 0)
06_load_impacts
```

| Notebook | Reads | Writes |
|---|---|---|
| 01 | SOURCES (Rapid2, RegMap ×7, Helios ×3, GPPS ×3, IA outputs) + `taxonomy_alignment.xlsx` if present | `OUT_DIR/nodes.parquet`, `edges.parquet`, `manifest.json`, `build_checks.xlsx` |
| 02 | nodes, edges | `OUT_DIR/taxonomy_alignment.xlsx` |
| 03 | nodes, edges, GPPS | `P3_DIR/candidates_alert_{policy,procedure}.parquet`, `phase3_candidates_and_cost.xlsx` |
| 04 | candidates, nodes, edges, GPPS | `P3_DIR/alert_impact_{policy,procedure}.parquet` (+ checkpoints), `alert_impact_results.xlsx` |
| 05 | impact results, nodes, edges, GPPS | `AUDIT_DIR/audit_labelled.parquet` (+ checkpoint), `phase3_audit_results.xlsx` |
| 06 | nodes, edges, impact results, audit labels | `OUT_DIR/edges.parquet` (backup `edges_before_impacts.parquet`), `manifest.json` |

Notebooks 04 and 05 are checkpointed: if a run stops, re-run the same cell and it resumes. Failed (ERROR) calls are retried.

## For another country

1. Copy the folder.
2. In `pipeline_config.py`, set `COUNTRY`, `JURISDICTION` and `RUN_ID`, and point `SOURCES` at that country's Rapid2, RegMap, Helios and IA outputs. GPPS stays global.
3. Check `COLS` if that country's Helios extract names columns differently. `build_checks.xlsx → columns_used` shows which candidate was picked.
4. Run the order above. In 01's DONE block, every AI link should show target found ≈ 100%. If a join is low, run `diagnostics/diag_id_joins.txt` before anything else.

## Method decisions (US build, Oct 2026)

**ID rules**
- **Helios control instances:** the 1C ID is in `name`, not `resource_id`.
- **RegMap blanks:** RegMap writes `-` for "none".
- **GPPS objRel target field per type:** CNTRL → `cntlId`, PLCY / REG → `objId`. RISK has no ID, only taxonomy text.
- **Hidden GPPS segments:** segments with `sgmntDispInd = N` are hidden in the GPPS UI and are excluded everywhere.

**Impact assessment**
- **Find + confirm:** impacts are *found* by the LLM (v1 prompts, the same house structure and fields as the RSM / ROB / Helios runs) and *confirmed* by an independent judge. Only `impact_confirmed = True` links count as impacts. Everything else stays in the graph as a labelled assertion.
- **Obligation route = run B:** every model-LINKED alert → obligation link is used, flagged by its judge verdict (`run_set` A / DISPUTED_SAMPLE / B_rest). Disputed obligation links still led to confirmed impacts at similar rates, so they are not dropped.
- **Fallback:** alerts impacted at summary level with no obligation route get a direct TF-IDF top-10 search.
- **Rejected procedure prompts:** a stricter procedure prompt (v2 / v2.1) removed the disputed links but also 50–67% of the confirmed ones at the A/B gate. Find + confirm was kept instead.

**US results**

| | LINKED | Judge-confirmed |
|---|---|---|
| Policy | 530 | **448** (84%) |
| Procedure | 1,098 | **634** (58%) |

- **Judge reliability:** the judge caught 97–100% of planted wrong links.
- **Misses:** possible misses were 0–3% of the rejected pairs.
