# Regulatory Compliance Ontology + Impact Assessment pipeline

Builds the ontology graph (alert → regulation → summary → obligation; library risk → library control → control instance; policies and procedures) from the systems of record and the IA linkage outputs. It then adds **alert → policy / procedure impact**, found by an LLM and confirmed by an independent LLM judge.

Every step reads files written by the previous step, so any notebook can be run in a fresh session.

## Files

**Full run guide:** `PIPELINE_GUIDE.md`. It covers set-up, input data and required columns, configuration, the run order, what each notebook writes, the acceptance numbers, running for another country, and troubleshooting.

| File | What it is |
|---|---|
| `00_preflight_checks.txt` | **Run first, and before every resume.** It checks the environment, config placeholders, every source file and its required columns, ID patterns, disk space, the outputs of earlier steps, the graph links the step needs, double-load risk, and optionally the gateway. It stops on any FAIL and writes `preflight_report.xlsx`. Cost: $0. |
| `pipeline_config.py` | **The only file to edit.** Country, run ID, all source paths, options, LLM settings and prices. |
| `ia_lib.py` | Shared helpers for 03–06: readers, the GPPS visible-section parser, the payload builder, the quote check and Wilson intervals. |
| `01_ontology_build.txt` | Phase 1 (facts) + phase 2 (existing AI links) → `nodes.parquet` and `edges.parquet`. Cost: $0. |
| `02_taxonomy_alignment.txt` | Finds risk-type names used by only one system → `taxonomy_alignment.xlsx` (editable `map_to`). Cost: $0. |
| `03_impact_candidates.txt` | Alert → policy / procedure candidate pairs (obligation route + fallback) and a cost estimate. Cost: $0. |
| `04_impact_llm.txt` | LLM decision per pair, using the final v1 prompts. US run: about $12. |
| `05_impact_audit.txt` | Independent judge: all LINKED pairs, a rejection sample and planted wrong links. US run: about $4. |
| `06_load_impacts.txt` | Pre-load checks, then all pairs are loaded into the graph and confirmed impacts are flagged. Cost: $0. |
| `07_control_candidates.txt` | Phase 3b: control status (live / retired), obligation → library control candidates from 7 routes, cost of levels 1 and 2. Cost: $0. |
| `08_control_llm_level1.txt` | Phase 3b level 1: obligation → library control, LLM (10 controls per call) + judge, precision per route; CELL 6c rebuilds results from the checkpoint after a disconnect. US run: about $41. |
| `09_control_load_and_instances.txt` | Loads level 1 into the graph (`satisfiedByControl`), then level 2: obligation → live control instance, LLM + judge, then loads level 2 (`satisfiedByControlInstance`, CELL 11). Built to run unattended (cost gate, automatic test gate). US run: $28. |
| `10_control_gap_findings.txt` | Classifies every live obligation (NO_CONTROL / DESIGN_ONLY / NOT_OPERATED / PARTIAL_ONLY / COVERED) from confirmed links; alerts hitting gaps; closest-candidate hints. Cost: $0. |
| `11_policy_via_control_scope.txt` | Phase 3c: for every obligation, (obligation, policy / procedure) pairs implied by a judge-confirmed control and the GPPS control mapping, split into ALREADY_LINKED / PREV_REJECTED / NEW. Cost: $0. |
| `12_policy_via_control_llm.txt` | Phase 3c: LLM + judge on the NEW pairs (all policy pairs + gap-fill procedure pairs), a calibration check against the original run, then a load into the graph. Self-contained (helpers included). Has cost and test gates. US run: $14.6. |
| `13_demo_export.txt` | Demo stories (5 alerts) → explorer JSON parts + `demo_story_review.xlsx`. Each story is built on its own with complete chains. Cost: $0. |
| `diagnostics/` | Not part of the run. The ID-join diagnosis cell and the archived procedure prompt v2 / v2.1 (rejected at the A/B gate). |

Each `.txt` notebook goes one `# ====== CELL n` block per notebook cell. Keep `pipeline_config.py` and `ia_lib.py` in the same folder as the notebooks.

## Run order

```
00_preflight_checks    (START_STEP = 1; and again with START_STEP = n before resuming at step n)
01_ontology_build      (first build)
02_taxonomy_alignment  -> optionally have an SME fill / correct map_to
01_ontology_build      (again: its CELL 7b merges the mapped names)
03_impact_candidates
04_impact_llm          (paste your gateway cells as CELL 0; test 10 pairs before CELL 6)
05_impact_audit        (paste gateway cells as CELL 0)
06_load_impacts
07_control_candidates
08_control_llm_level1  (paste gateway cells as CELL 0)
09_control_load_and_instances (paste gateway cells as CELL 0; Run All - stops itself on the gates)
10_control_gap_findings
11_policy_via_control_scope
12_policy_via_control_llm   (paste gateway cells as CELL 0; set the 3 GPPS paths in CELL 1)
13_demo_export              (optional: explorer data for the demo)
```
03-06 (alert impact) and 07-09 (control structure) are independent of each other; both need 01.

| Notebook | Reads | Writes |
|---|---|---|
| 01 | SOURCES (Rapid2, RegMap ×7, Helios ×3, GPPS ×3, IA outputs) + `taxonomy_alignment.xlsx` if present | `OUT_DIR/nodes.parquet`, `edges.parquet`, `manifest.json`, `build_checks.xlsx` |
| 02 | nodes, edges | `OUT_DIR/taxonomy_alignment.xlsx` |
| 03 | nodes, edges, GPPS | `P3_DIR/candidates_alert_{policy,procedure}.parquet`, `phase3_candidates_and_cost.xlsx` |
| 04 | candidates, nodes, edges, GPPS | `P3_DIR/alert_impact_{policy,procedure}.parquet` (+ checkpoints), `alert_impact_results.xlsx` |
| 05 | impact results, nodes, edges, GPPS | `AUDIT_DIR/audit_labelled.parquet` (+ checkpoint), `phase3_audit_results.xlsx` |
| 06 | nodes, edges, impact results, audit labels | `OUT_DIR/edges.parquet` (backup `edges_before_impacts.parquet`), `manifest.json` |
| 07 | nodes, edges | `P3B_DIR/l1c_candidates.parquet`, `instance_pool.parquet`, `phase3b_candidates_and_cost.xlsx` |
| 08 | l1c candidates, instance pool, nodes | `P3B_DIR/l1c_results.parquet`, `l1c_audit_labelled.parquet` (+ checkpoints), `l1c_results.xlsx`, `l1c_precision_per_route.xlsx` |
| 09 | level 1 results + audit, instance pool, nodes, edges | `OUT_DIR/edges.parquet` (+ `satisfiedByControl` and `satisfiedByControlInstance`, backups first), `P3B_DIR/ic_candidates.parquet`, `ic_results.parquet`, `ic_audit_labelled.parquet`, `ic_results.xlsx` |
| 10 | nodes, edges, instance pool | `P3B_DIR/control_gap_findings.xlsx` |
| 11 | nodes, edges | `OUT_DIR/phase3c/via_control_candidates.parquet`, `phase3c_scope.xlsx` |
| 12 | candidates, nodes, edges, GPPS | `phase3c/vc_results.parquet`, `vc_audit_labelled.parquet`, `vc_results.xlsx`; `OUT_DIR/edges.parquet` (backup `edges_before_via_control.parquet`) |
| 13 | nodes, edges, gap findings | `OUT_DIR/demo/ontology_demo_data_partNN.json`, `demo_story_review.xlsx` |

Notebooks 04, 05, 08 and 09 are checkpointed: if a run stops, re-run the same cell and it resumes. Failed (ERROR) calls are retried.

## For another country

1. Copy the folder.
2. In `pipeline_config.py`, set `COUNTRY`, `JURISDICTION` and `RUN_ID`, and point `SOURCES` at that country's Rapid2, RegMap, Helios and IA outputs. GPPS stays global.
3. Check `COLS` if that country's Helios extract names columns differently. `build_checks.xlsx → columns_used` shows which candidate was picked.
4. Run the order above. In 01's DONE block, every AI link should show target found ≈ 100%. If a join is low, run `diagnostics/diag_id_joins.txt` before anything else.

## Method decisions (US build, Oct 2026)

**ID rules**
- **Helios control instances:** the 1C ID is in `name`, not `resource_id`.
- **RegMap blanks:** RegMap writes `-` for "none".
- **GPPS objRel target field per type:** CNTRL → `cntlId`, PLCY / REG → `objId`. RISK has no ID, only taxonomy text.
- **Hidden GPPS segments:** segments with `sgmntDispInd = N` are hidden in the GPPS UI and are excluded everywhere.

**Impact assessment**
- **Find + confirm:** impacts are *found* by the LLM (v1 prompts, the same house structure and fields as the RSM / ROB / Helios runs) and *confirmed* by an independent judge. Only `impact_confirmed = True` links count as impacts. Everything else stays in the graph as a labelled assertion.
- **Obligation route = run B:** every model-LINKED alert → obligation link is used, flagged by its judge verdict (`run_set` A / DISPUTED_SAMPLE / B_rest). Disputed obligation links still led to confirmed impacts at similar rates, so they are not dropped.
- **Fallback:** alerts impacted at summary level with no obligation route get a direct TF-IDF top-10 search.
- **Rejected procedure prompts:** a stricter procedure prompt (v2 / v2.1) removed the disputed links but also 50–67% of the confirmed ones at the A/B gate. Find + confirm was kept instead.

**US results**

| | LINKED | Judge-confirmed |
|---|---|---|
| Policy | 530 | **448** (84%) |
| Procedure | 1,098 | **634** (58%) |

- **Judge reliability:** the judge caught 97–100% of planted wrong links.
- **Misses:** possible misses were 0–3% of the rejected pairs.

## Phase 3b: which control satisfies which obligation (US, Oct 2026)

**Data rules found**
- **Instance status:** Retired 1,787, Assessed 1,673, Cancelled 241, Pending Assessment 57, Draft 5. Live = Assessed + Pending Assessment, excluding text saying "demised", giving 1,706. Library controls: Retired 57 dropped, 647 kept.
- **Instances are not copies of their library control:** 91% add ≥ 40% new words (local steps, specific reports). So instances get their own decision (level 2) rather than inheriting.
- **Bug fixed in 01:** the Helios audit names its levels `risk` / `control` / `instance`. Before the fix, alert → LR / L1C / 1C links had no judge verdict joined.

**Level 1 (library control):** 102,114 candidate pairs from 7 routes → 9,437 LINKED → **5,327 judge-confirmed (56%)**. 1,568 obligations are covered and 1,629 have no confirmed control. 95 confirmed controls have no live instance. The judge caught 100% of planted wrong links; possible misses were 2/300.

**Routes** (precision / found alone / yield)

| Route | Precision | Found alone | Yield |
|---|---|---|---|
| GPPS policy → control | 60% | 2,510 | 11% |
| Same alert | 60% | small | 11–19% |
| RegMap summary-level | 55% | ~300 | ~5% |
| RegMap obligation → risk | 52% | 5 | 10% |
| Taxonomy | 50% | 0 | 10% |

- **GPPS is the backbone:** about 29% of confirmed links come only via GPPS.
- **No route is precise alone,** so the judge is always needed.
- **Scaling lever:** drop pairs found only by summary-level routes. That halves the calls for a 2–5% loss of confirmed links (08 CELL 11 measures it). The US run kept everything.

**Level 2 (instance):**
- **Candidates:** live instances of confirmed controls, with RegMap extract 5 'N' pairs dropped: 66,842 pairs, minus 17,938 'N', leaving 48,904.
- **Results:** 13,866 LINKED → **7,908 judge-confirmed (57%)**, covering 761 obligations and 1,096 live instances. Score 7–10 confirms at 77%, 5–6 at 40%.
- **RegMap 'applicable' flag:** 'Y' pairs confirm at 63% vs 57%, so it's a hint, not a filter.
- **Judge reliability:** it caught 97% of planted wrong links; possible misses were 1/300.
- **Cost:** $28.

**Gap findings** (notebook 10; 3,180 live obligations, judge-confirmed links only)

| Category | All live | Alert-linked |
|---|---|---|
| NO_CONTROL | 52% | 46% |
| DESIGN_ONLY | 2% | 2% |
| NOT_OPERATED | 23% | 25% |
| PARTIAL_ONLY | 7% | 7% |
| COVERED | 16% | 20% |

- **Read these as an upper bound for SME validation.** They're limited by the US-only Helios extract, judge strictness, and obligations that need no control.

## Phase 3c: obligation → policy / procedure via a confirmed control (US, Oct 2026)

**Why:** the third-party risk (TPRM) story showed the original obligation → policy run missed links that the control structure makes obvious. The pattern: an obligation is satisfied by a judge-confirmed control, and GPPS maps that same control to a policy. 12 of the 13 TPRM obligations had never been proposed for POL-47.

**Scope (notebook 11):** 45,943 implied (obligation, document) pairs.
- **Prior precision:** where the original run had already judged these pairs, 57% of policy pairs were LINKED, but only 33% of procedure pairs. So the structure is a hint, not proof, and every pair goes to the LLM + judge.
- **Run set:** all 2,276 NEW policy pairs, plus 5,139 NEW procedure pairs for the 260 obligations with no linked procedure (gap-fill).
- **Not run:** the other ~19k procedure pairs, which would only add procedures to obligations that already have one.

**Results (notebook 12)**

| | Value |
|---|---|
| Model LINKED | 449 policy, 542 procedure |
| **Judge-confirmed** | **243 policy, 294 procedure (54% each, 95% CI about 49–59%)** |
| Planted wrong links caught | 100% |
| Possible misses | 2 of 400 rejected pairs |
| Disputed links, by cause | thematic 273, wrong scope 142, shared-control-only 33 |
| **Gain** | 32 obligations get their first confirmed policy; 70 of the 260 gap obligations get a confirmed procedure |
| **TPRM** | 11 of the 12 rule-only links to POL-47 are now LLM + judge-confirmed (1 disputed) |
| Cost | $14.6 |

**Calibration:** 100 pairs per type that the original run had already decided were re-judged with this prompt.
- **Agreement:** 78% for policies, 79% for procedures.
- **Direction:** where they differ, this prompt is mostly stricter (14–15 pairs the original run linked are now NOT_LINKED, against 6–8 the other way).
