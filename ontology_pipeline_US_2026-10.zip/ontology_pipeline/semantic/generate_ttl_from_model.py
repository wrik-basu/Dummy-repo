"""Generate the published semantic files from the ontology model (D block of the explorer HTML)."""
import json, re, sys
from rdflib import Graph, Namespace, URIRef, Literal, BNode
from rdflib.namespace import RDF, RDFS, OWL, XSD, SKOS, DCTERMS
from rdflib.collection import Collection

D = json.load(open(sys.argv[1]))
OUT = sys.argv[2]
BASE = "https://ontology.hsbc.internal/regcomp/"      # placeholder IRI root: confirm with architecture
RC = Namespace(BASE + "def#")       # model terms
VC = Namespace(BASE + "vocab/")     # controlled vocabularies
SH = Namespace("http://www.w3.org/ns/shacl#")
PROV = Namespace("http://www.w3.org/ns/prov#")
FIBO_LE = Namespace("https://spec.edmcouncil.org/fibo/ontology/BE/LegalEntities/LegalPersons/")
FIBO_GOV = Namespace("https://spec.edmcouncil.org/fibo/ontology/FBC/FunctionalEntities/RegulatoryAgencies/")
FIBO_LAW = Namespace("https://spec.edmcouncil.org/fibo/ontology/FND/Law/LegalCapacity/")
FIBO_JUR = Namespace("https://spec.edmcouncil.org/fibo/ontology/FND/Law/Jurisdiction/")
ORG = Namespace("http://www.w3.org/ns/org#")
ELI = Namespace("http://data.europa.eu/eli/ontology#")
VERSION = "2.5"
MODULE = {k: v["n"] for k, v in D["modules"].items()}


def bind(g):
    for p, n in [("rc", RC), ("vc", VC), ("owl", OWL), ("rdfs", RDFS), ("xsd", XSD), ("skos", SKOS), ("sh", SH),
                 ("prov", PROV), ("dcterms", DCTERMS), ("fibo-be-le-lp", FIBO_LE), ("fibo-fbc-fct-rga", FIBO_GOV),
                 ("fibo-fnd-law-lcap", FIBO_LAW), ("fibo-fnd-law-jur", FIBO_JUR), ("org", ORG), ("eli", ELI)]:
        g.bind(p, n)
    return g


# ------------------------------------------------------------------ v2.5 additions (as built)
NEW_CLASSES = [
    dict(id="RegulationAssessment", m="IMP", l="Regulation Assessment", parent="Entity", status="AVAILABLE",
         src="RegMap extract 7",
         d="A business's assessment of a regulation: which obligations are in scope for that business."),
]
# (domain, property, range, inverse, comment, graph property as built, superproperty)
NEW_PROPS = [
    ("Policy", "policyMapsToControl", "LibraryControl", None, "GPPS policy section maps a Helios control standard (GPPS objRel CNTRL).", "policyMapsToControl", None),
    ("Procedure", "procedureMapsToControl", "LibraryControl", None, "GPPS procedure section maps a Helios control standard (GPPS objRel CNTRL).", "procedureMapsToControl", None),
    ("Policy", "policyMapsToRegulation", "Regulation", None, "GPPS policy maps a RegMap regulation (GPPS objRel REG).", "policyMapsToRegulation", None),
    ("Policy", "relatedPolicy", "Policy", None, "GPPS policy references another policy (GPPS objRel PLCY).", "relatedPolicy", None),
    ("Procedure", "addressesRiskType", "RiskTaxonomyNode", None, "GPPS procedure addresses a risk taxonomy node (GPPS objRel RISK, text only).", "addressesRiskType", None),
    ("RegulatoryObligation", "satisfiedByControlInstance", "Control", None, "Obligation is performed by a live control instance (phase 3b level 2; confirmed = LLM + judge).", "satisfiedByControlInstance", "satisfiedBy"),
    ("RegulatoryObligation", "implementedByPolicyViaControl", "Policy", None, "Derived by rule (no AI): obligation -> its confirmed control standard -> the same control mapped in GPPS to the policy. Superseded by LLM + judge links where they exist.", "implementedByPolicyViaControl", "implementedByPolicy"),
    ("Requirement", "hasGap", "Gap", "onRequirement", "A gap finding on a requirement (derived from confirmed links).", "hasGap", None),
    ("RegulationAssessment", "assessesRegulation", "Regulation", None, "The regulation the assessment covers.", "assessesRegulation", None),
    ("RegulationAssessment", "assessedFor", "BusinessUnit", None, "The business the assessment is for.", "assessedFor", None),
    ("RegulationAssessment", "evaluatesObligation", "RegulatoryObligation", None, "An obligation evaluated (in scope or not) by the assessment.", "evaluatesObligation", None),
]
# graph property as built -> ontology property (for the RDF export and documentation)
GRAPH_TO_ONTO = {
    "partOfRegulation": "partOfRegulation", "derivedFromSummary": "derivedFromSummary", "mitigatedBy": "mitigatedBy",
    "instanceOf": "instanceOf", "implementsPolicy": "implementsPolicy", "implementedByPolicy": "implementedByPolicy",
    "governsActivity": "governsActivity", "satisfiedByControl": "satisfiedBy", "givesRiseTo": "givesRiseTo",
    "inJurisdiction": "inJurisdiction", "issuedByRegulator": "issuedByRegulator", "taggedRisk": "taggedRisk",
    "taggedSteward": "taggedSteward", "hasTheme": "hasTheme", "taggedBusiness": "taggedBusiness",
    "taggedLegalEntity": "taggedLegalEntity", "broaderRisk": "broaderRisk",
}
EXTRA_VOCABS = {
    "GapCategory": {"d": "Control gap category of an obligation (from judge-confirmed links only)",
                    "m": ["NO_CONTROL", "DESIGN_ONLY", "NOT_OPERATED", "PARTIAL_ONLY", "COVERED"]},
    "JudgeVerdict": {"d": "Independent judge verdict on a model decision",
                     "m": ["AGREE", "DISAGREE", "UNCERTAIN", "NOT_AUDITED"]},
    "ImpactType": {"d": "What an impact means for the document owner",
                   "m": ["CHANGE_REQUIRED", "REVIEW_REQUIRED", "NONE"]},
    "GroundingFlag": {"d": "Whether the model's verbatim quotes were found in both texts by code",
                      "m": ["GROUNDED", "PARTIAL", "UNGROUNDED"]},
    "AuditLabel": {"d": "Label from the judge audit",
                   "m": ["CONFIRMED", "NEEDS_SME", "DISPUTED", "CORRECT_REJECTION", "POSSIBLE_MISS",
                         "PROBE_CAUGHT", "PROBE_PARTLY_CAUGHT", "PROBE_MISSED"]},
}
GAP_DEF = {"NO_CONTROL": "No control standard confirmed for the obligation.",
           "DESIGN_ONLY": "A control standard is confirmed but none of them has a live instance.",
           "NOT_OPERATED": "Confirmed standard(s) with live instances, but no live instance confirmed to perform the obligation.",
           "PARTIAL_ONLY": "Live instance(s) confirmed, but only with PARTIAL coverage.",
           "COVERED": "A confirmed live instance with FULL coverage somewhere, or two or more confirmed instances."}

XSD_OF = {"string": XSD.string, "date": XSD.date, "datetime": XSD.dateTime, "dateTime": XSD.dateTime,
          "float": XSD.decimal, "decimal": XSD.decimal, "int": XSD.integer, "integer": XSD.integer,
          "boolean": XSD.boolean, "bool": XSD.boolean}


def iri(local):
    return RC[re.sub(r"[^A-Za-z0-9_]", "_", local)]


# ================================================================== 1. ontology (OWL)
g = bind(Graph())
ont = URIRef(BASE + "def")
g.add((ont, RDF.type, OWL.Ontology))
g.add((ont, OWL.versionInfo, Literal(VERSION)))
g.add((ont, DCTERMS.title, Literal("HSBC Regulatory Compliance Ontology", lang="en")))
g.add((ont, DCTERMS.description, Literal(
    "Regulatory alert -> regulation / summary / obligation -> policy / procedure -> risk / control standard / live "
    "control, with AI link assertions (provenance, judge verdict, SME status) and gap findings. Generated from the "
    "explorer model block; working store is a property graph.", lang="en")))
g.add((ont, DCTERMS.created, Literal("2026-10-30", datatype=XSD.date)))
g.add((RC.module, RDF.type, OWL.AnnotationProperty))
g.add((RC.sourceSystem, RDF.type, OWL.AnnotationProperty))
g.add((RC.dataStatus, RDF.type, OWL.AnnotationProperty))
g.add((RC.graphProperty, RDF.type, OWL.AnnotationProperty))
g.add((RC.graphProperty, RDFS.comment, Literal("Name of the edge property in the working property graph (edges.parquet).", lang="en")))

classes = D["classes"] + NEW_CLASSES
for c in classes:
    u = iri(c["id"])
    g.add((u, RDF.type, OWL.Class))
    g.add((u, RDFS.label, Literal(c.get("l") or c["id"], lang="en")))
    if c.get("d"):
        g.add((u, SKOS.definition, Literal(c["d"], lang="en")))
    if c.get("parent"):
        g.add((u, RDFS.subClassOf, iri(c["parent"])))
    g.add((u, RC.module, Literal(MODULE.get(c["m"], c["m"]))))
    if c.get("src") and c["src"] != "—":
        g.add((u, RC.sourceSystem, Literal(c["src"])))
    if c.get("status"):
        g.add((u, RC.dataStatus, Literal(c["status"])))
    g.add((u, RDFS.isDefinedBy, ont))

# object properties (one per name; several domain/range pairs -> union)
by_name = {}
for r in D["rels"]:
    if r["t"].startswith("Vocab:"):
        continue
    by_name.setdefault(r["r"], []).append(r)
for (f, p, t, inv, cmt, gp, sup) in NEW_PROPS:
    by_name.setdefault(p, []).append(dict(f=f, r=p, t=t, inv=inv or "", n=cmt, card="0..*", _gp=gp, _sup=sup))


def union(classes_):
    classes_ = sorted(set(classes_))
    if len(classes_) == 1:
        return iri(classes_[0])
    b = BNode()
    g.add((b, RDF.type, OWL.Class))
    lst = BNode()
    Collection(g, lst, [iri(x) for x in classes_])
    g.add((b, OWL.unionOf, lst))
    return b


for p, rs in by_name.items():
    u = iri(p)
    g.add((u, RDF.type, OWL.ObjectProperty))
    g.add((u, RDFS.label, Literal(re.sub(r"([A-Z])", r" \1", p).lower(), lang="en")))
    g.add((u, RDFS.domain, union([r["f"] for r in rs])))
    g.add((u, RDFS.range, union([r["t"] for r in rs])))
    notes = sorted({r.get("n") for r in rs if r.get("n")})
    if notes:
        g.add((u, RDFS.comment, Literal(" | ".join(notes), lang="en")))
    inv = next((r.get("inv") for r in rs if r.get("inv")), None)
    if inv:
        iu = iri(inv)
        g.add((iu, RDF.type, OWL.ObjectProperty))
        g.add((iu, OWL.inverseOf, u))
        g.add((iu, RDFS.label, Literal(re.sub(r"([A-Z])", r" \1", inv).lower(), lang="en")))
    for r in rs:
        if r.get("_gp"):
            g.add((u, RC.graphProperty, Literal(r["_gp"])))
        if r.get("_sup"):
            g.add((u, RDFS.subPropertyOf, iri(r["_sup"])))
    if p in GRAPH_TO_ONTO.values():
        for gp_, op in GRAPH_TO_ONTO.items():
            if op == p:
                g.add((u, RC.graphProperty, Literal(gp_)))
# satisfiedBy is the inverse name used by the graph for obligation -> control standard
g.add((RC.satisfiedBy, RC.graphProperty, Literal("satisfiedByControl")))

# vocabulary-valued relations -> object properties ranging over SKOS concepts
for r in D["rels"]:
    if r["t"].startswith("Vocab:"):
        u = iri(r["r"])
        g.add((u, RDF.type, OWL.ObjectProperty))
        g.add((u, RDFS.domain, iri(r["f"])))
        g.add((u, RDFS.range, SKOS.Concept))
        g.add((u, RDFS.comment, Literal(f"Value from the {r['t'][6:]} concept scheme.", lang="en")))
for p, f in [("hasGapCategory", "Gap"), ("hasJudgeVerdict", "LinkAssertion"), ("hasImpactType", "LinkAssertion"),
             ("hasGrounding", "LinkAssertion"), ("hasAuditLabel", "LinkAssertion")]:
    u = iri(p); g.add((u, RDF.type, OWL.ObjectProperty)); g.add((u, RDFS.domain, iri(f))); g.add((u, RDFS.range, SKOS.Concept))

# datatype properties
for d in D["dprops"]:
    u = iri(d["n"])
    g.add((u, RDF.type, OWL.DatatypeProperty))
    g.add((u, RDFS.domain, iri(d["dom"])))
    g.add((u, RDFS.range, XSD_OF.get(str(d.get("x", "string")).lower(), XSD.string)))
    if d.get("d"):
        g.add((u, RDFS.comment, Literal(d["d"], lang="en")))
for n, dom, x, cmt in [("linkScore", "LinkAssertion", XSD.integer, "Model link score 0-10."),
                       ("confirmed", "LinkAssertion", XSD.boolean, "LINKED + judge AGREE with verified quotes: the only links that count."),
                       ("changeNeeded", "LinkAssertion", XSD.string, "What the document owner should look at (impact links)."),
                       ("linkedSections", "LinkAssertion", XSD.string, "GPPS sections the link rests on, e.g. 'S5 | 4 Third Party Agreements'."),
                       ("runId", "ModelRun", XSD.string, "Run identifier written on every edge (run_id)."),
                       ("referenceOnly", "Entity", XSD.boolean, "True = stub: the ID is cited by another system but the record is not in its own system's extract.")]:
    u = iri(n); g.add((u, RDF.type, OWL.DatatypeProperty)); g.add((u, RDFS.domain, iri(dom)))
    g.add((u, RDFS.range, x)); g.add((u, RDFS.comment, Literal(cmt, lang="en")))
g.serialize(f"{OUT}/ontology_v2_5.ttl", format="turtle")
n_cls = len(classes); n_op = len(set(g.subjects(RDF.type, OWL.ObjectProperty))); n_dp = len(set(g.subjects(RDF.type, OWL.DatatypeProperty)))
print(f"ontology_v2_5.ttl: {len(g):,} triples | classes {n_cls} | object properties {n_op} | datatype properties {n_dp}")

# ================================================================== 2. vocabularies (SKOS)
v = bind(Graph())
for name, spec in {**D["vocabs"], **EXTRA_VOCABS}.items():
    cs = VC[name]
    v.add((cs, RDF.type, SKOS.ConceptScheme))
    v.add((cs, SKOS.prefLabel, Literal(re.sub(r"([A-Z])", r" \1", name).strip(), lang="en")))
    v.add((cs, SKOS.definition, Literal(spec.get("d", ""), lang="en")))
    for m in spec["m"]:
        c = VC[f"{name}/{re.sub(r'[^A-Za-z0-9_]', '_', m)}"]
        v.add((c, RDF.type, SKOS.Concept))
        v.add((c, SKOS.inScheme, cs))
        v.add((c, SKOS.topConceptOf, cs))
        v.add((c, SKOS.notation, Literal(m)))
        v.add((c, SKOS.prefLabel, Literal(m.replace("_", " ").title(), lang="en")))
        if name == "GapCategory":
            v.add((c, SKOS.definition, Literal(GAP_DEF[m], lang="en")))
v.serialize(f"{OUT}/vocabularies_skos.ttl", format="turtle")
print(f"vocabularies_skos.ttl: {len(v):,} triples | schemes {len(D['vocabs']) + len(EXTRA_VOCABS)}")

# ================================================================== 3. alignment
a = bind(Graph())
A = URIRef(BASE + "alignment")
a.add((A, RDF.type, OWL.Ontology)); a.add((A, OWL.imports, ont))
a.add((A, DCTERMS.description, Literal(
    "Alignment of the HSBC Regulatory Compliance Ontology to FIBO, W3C PROV-O, W3C ORG, W3C SKOS and ELI. "
    "Mappings are conservative (subClassOf / subPropertyOf) unless the meaning is identical.", lang="en")))
for ours, rel, theirs in [
    ("LegalEntity", RDFS.subClassOf, FIBO_LE.LegalPerson),
    ("Regulator", RDFS.subClassOf, FIBO_GOV.RegulatoryAgency),
    ("Jurisdiction", RDFS.subClassOf, FIBO_JUR.Jurisdiction),
    ("Regulation", RDFS.subClassOf, ELI.LegalResource),
    ("Provision", RDFS.subClassOf, ELI.LegalResourceSubdivision),
    ("BusinessUnit", RDFS.subClassOf, ORG.OrganizationalUnit),
    ("Role", RDFS.subClassOf, ORG.Role),
    ("Person", RDFS.subClassOf, PROV.Person),
    ("LinkAssertion", RDFS.subClassOf, PROV.Entity),
    ("EvidenceOccurrence", RDFS.subClassOf, PROV.Entity),
    ("ModelRun", RDFS.subClassOf, PROV.Activity),
    ("SMEValidation", RDFS.subClassOf, PROV.Activity),
    ("RiskTaxonomyNode", RDFS.subClassOf, SKOS.Concept),
]:
    a.add((iri(ours), rel, theirs))
for ours, rel, theirs in [
    ("producedBy", RDFS.subPropertyOf, PROV.wasGeneratedBy),
    ("validatedBy", RDFS.subPropertyOf, PROV.wasInfluencedBy),
    ("performedBy", RDFS.subPropertyOf, PROV.wasAssociatedWith),
    ("extractedFrom", RDFS.subPropertyOf, PROV.wasDerivedFrom),
    ("broaderRisk", RDFS.subPropertyOf, SKOS.broader),
    ("broaderJurisdiction", RDFS.subPropertyOf, SKOS.broader),
]:
    a.add((iri(ours), rel, theirs))
a.serialize(f"{OUT}/alignment.ttl", format="turtle")
print(f"alignment.ttl: {len(a):,} triples")

# ================================================================== 4. SHACL shapes (rules that run on the graph export)
s = bind(Graph())


def shape(name, target_class, msg, props, severity=SH.Violation):
    sh = RC[name]
    s.add((sh, RDF.type, SH.NodeShape)); s.add((sh, SH.targetClass, iri(target_class)))
    s.add((sh, SH.severity, severity)); s.add((sh, RDFS.comment, Literal(msg, lang="en")))
    for p in props:
        b = BNode(); s.add((sh, SH.property, b))
        for k, val in p.items():
            s.add((b, SH[k], val))
    return sh


L = lambda x: Literal(x)
I = lambda x: Literal(x, datatype=XSD.integer)
shape("ObligationShape", "RegulatoryObligation", "Every obligation has an ID, a label and exactly one parent summary.",
      [dict(path=RC.sourceId, minCount=I(1), maxCount=I(1), datatype=XSD.string),
       dict(path=RC.label, minCount=I(1)),
       dict(path=RC.derivedFromSummary, minCount=I(1), maxCount=I(1), **{"class": RC.RegulatorySummary})])
shape("SummaryShape", "RegulatorySummary", "Every summary belongs to exactly one regulation.",
      [dict(path=RC.partOfRegulation, minCount=I(1), maxCount=I(1), **{"class": RC.Regulation})])
shape("ControlInstanceShape", "Control", "A control instance belongs to at most one control standard.",
      [dict(path=RC.instanceOf, maxCount=I(1), **{"class": RC.LibraryControl})])
ci = RC.ControlInstanceStandardShape   # loaded instances (not reference-only stubs) must have their standard
s.add((ci, RDF.type, SH.NodeShape)); s.add((ci, SH.targetClass, RC.Control)); s.add((ci, SH.severity, SH.Violation))
s.add((ci, RDFS.comment, Literal("A control instance loaded from Helios belongs to exactly one control standard. Reference-only stubs (IDs cited by RegMap / IA but absent from the Helios extract) are exempt.", lang="en")))
qc = BNode(); s.add((ci, SH.sparql, qc))
s.add((qc, SH.message, Literal("Loaded control instance has no control standard")))
s.add((qc, SH.select, Literal(f"""PREFIX rc: <{RC}>
SELECT $this WHERE {{
  FILTER NOT EXISTS {{ $this rc:referenceOnly true . }}
  FILTER NOT EXISTS {{ $this rc:instanceOf ?l . }}
}}""")))
shape("LinkAssertionShape", "LinkAssertion",
      "Every AI link has subject, object, decision, score 0-10, judge verdict, SME status and the model run that produced it.",
      [dict(path=RC.assertionSubject, minCount=I(1), maxCount=I(1)),
       dict(path=RC.assertionObject, minCount=I(1), maxCount=I(1)),
       dict(path=RC.hasDecision, minCount=I(1), maxCount=I(1)),
       dict(path=RC.hasJudgeVerdict, minCount=I(1), maxCount=I(1)),
       dict(path=RC.hasSMEStatus, minCount=I(1), maxCount=I(1)),
       dict(path=RC.producedBy, minCount=I(1), **{"class": RC.ModelRun}),
       dict(path=RC.linkScore, maxCount=I(1), minInclusive=I(0), maxInclusive=I(10))])
# confirmed => LINKED + AGREE + GROUNDED (SPARQL constraint)
cs = RC.ConfirmedLinkShape
s.add((cs, RDF.type, SH.NodeShape)); s.add((cs, SH.targetClass, RC.LinkAssertion)); s.add((cs, SH.severity, SH.Violation))
s.add((cs, RDFS.comment, Literal("A link may be marked confirmed only if the model said LINKED, the judge AGREEd and both quotes were verified.", lang="en")))
q = BNode(); s.add((cs, SH.sparql, q))
s.add((q, SH.message, Literal("Confirmed link without LINKED + judge AGREE, or with quotes that failed the check")))
s.add((q, SH.select, Literal(f"""PREFIX rc: <{RC}>
PREFIX vc: <{VC}>
PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
SELECT $this WHERE {{
  $this rc:confirmed true .
  {{ FILTER NOT EXISTS {{ $this rc:hasDecision <{VC}LinkDecision/LINKED> ;
                                rc:hasJudgeVerdict <{VC}JudgeVerdict/AGREE> . }} }}
  UNION
  {{ $this rc:hasGrounding ?gr . FILTER (?gr != <{VC}GroundingFlag/GROUNDED>) }}
}}""")))
# confirmed but the quote check was never recorded (earlier runs) -> warning, not violation;
# regulation-level links are roll-ups of their summaries (no own quotes) -> exempt
lg = RC.ConfirmedWithoutQuoteCheckWarning
s.add((lg, RDF.type, SH.NodeShape)); s.add((lg, SH.targetClass, RC.LinkAssertion)); s.add((lg, SH.severity, SH.Warning))
s.add((lg, RDFS.comment, Literal("Confirmed link from a run that did not record the verbatim-quote check (earlier IA runs). Judge AGREE stands; quotes not machine-verified.", lang="en")))
ql = BNode(); s.add((lg, SH.sparql, ql))
s.add((ql, SH.message, Literal("Confirmed link: quote check not recorded (earlier run)")))
s.add((ql, SH.select, Literal(f"""PREFIX rc: <{RC}>
SELECT $this WHERE {{
  $this rc:confirmed true .
  FILTER NOT EXISTS {{ $this rc:hasGrounding ?gr . }}
  FILTER NOT EXISTS {{ $this rc:hasGranularity <{VC}Granularity/RGL> . }}
}}""")))
# coverage gap warning: an active obligation with neither a confirmed control nor a gap finding
w = RC.UncoveredObligationWarning
s.add((w, RDF.type, SH.NodeShape)); s.add((w, SH.targetClass, RC.RegulatoryObligation)); s.add((w, SH.severity, SH.Warning))
s.add((w, RDFS.comment, Literal("Every ACTIVE (PUBLISHED) obligation should either be satisfied by a control or carry a gap finding.", lang="en")))
q2 = BNode(); s.add((w, SH.sparql, q2))
s.add((q2, SH.message, Literal("Obligation has no confirmed control and no gap finding")))
s.add((q2, SH.select, Literal(f"""PREFIX rc: <{RC}>
SELECT $this WHERE {{
  $this rc:status ?st . FILTER (UCASE(STR(?st)) = "PUBLISHED")
  FILTER NOT EXISTS {{ $this rc:satisfiedBy ?c . }}
  FILTER NOT EXISTS {{ $this rc:hasGap ?g . }}
}}""")))
shape("GapShape", "Gap", "A gap sits on exactly one requirement and has exactly one category.",
      [dict(path=RC.onRequirement, minCount=I(1), maxCount=I(1)),
       dict(path=RC.hasGapCategory, minCount=I(1), maxCount=I(1))])
shape("ModelRunShape", "ModelRun", "Every model run carries its run ID.",
      [dict(path=RC.runId, minCount=I(1), maxCount=I(1))])
s.serialize(f"{OUT}/shapes_shacl.ttl", format="turtle")
print(f"shapes_shacl.ttl: {len(s):,} triples | shapes {len(set(s.subjects(RDF.type, SH.NodeShape)))}")
json.dump({"BASE": BASE, "GRAPH_TO_ONTO": GRAPH_TO_ONTO,
           "NEW_PROPS": {p: gp for (_, p, _, _, _, gp, _) in NEW_PROPS}}, open(f"{OUT}/_mapping.json", "w"), indent=1)
